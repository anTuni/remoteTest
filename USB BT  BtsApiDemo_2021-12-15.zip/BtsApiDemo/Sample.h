#pragma once
#include "BtsApi.h"

class Sample
{
public:
	Sample(btsStandardRecord standard);
	Sample(btsTrialRecord test);
	~Sample();


	bool HasSci() const {return m_flags.flag_struct.sc_mode == btsSCI || m_flags.flag_struct.sc_mode == bstSCI_AND_SCE;}
	
	bool HasSce() const {return m_flags.flag_struct.sc_mode == btsSCE || m_flags.flag_struct.sc_mode == bstSCI_AND_SCE;}
	
	bool IsStandard() const { return m_isStandard; }

	bool HasSpectralData() const {return m_flags.flag_struct.data_type == btsCOLOR_DATA_TYPE_SPECTRUM;}
	// ��ȡ����������
	const float* GetSpectralData(bool isSce)
	{
		if (HasSpectralData()) 
		{
			return isSce ? (HasSce() ? m_sce : NULL) : (HasSci() ? m_sci : NULL);
		}
		return NULL;
	}
	// ��ȡXYZ����
	const float* GetXyzData(bool isSce)
	{
		return isSce ? (HasSce() ? m_sceXyz : NULL) : (HasSci() ? m_sciXyz : NULL);
	}

	const CString& Name() const {return m_name; }

	CString DateTime() const
	{
		CString str;
		str.Format(_T("%02d/%02d/%02d %02d:%02d:%02d"),
			(int)m_dateTime.year, (int)m_dateTime.month, (int)m_dateTime.date,
			(int)m_dateTime.hour, (int)m_dateTime.minute, (int)m_dateTime.second);
		return str;
	}

	// ��ƷID��
	UINT Id() const {return m_id;}
	// ����ID��ֻ�������
	UINT StandardId() const {return m_standardId; }
	// �Ƿ���͸��
	bool IsTransmissive() const {return m_flags.flag_struct.optical_mode == btsOPTICAL_MODE_TRA;}

	template<typename RecordType>
	void SetData(const RecordType &record);
	btsStandardIlluminant Illuminant() const {return m_illuminant; }
	btsStandardObserver Observer() const {return m_observer; }
private:
	bool m_isStandard;
	btsRecordFlags m_flags;
	UINT m_id;
	UINT m_standardId;
	CString m_name;
	float m_temperature;
	float m_sci[btsSPECTRAL_DATA_COUNT];	// SCI�ķ���������
	float m_sce[btsSPECTRAL_DATA_COUNT];	// SCE�ķ���������
	btsStandardIlluminant m_illuminant;		// XYZ���ݵĹ�Դ
	btsStandardObserver m_observer;			// XYZ���ݵĹ۲���
	float m_sciXyz[3];						// SCI��XYZ����
	float m_sceXyz[3];						// SCE��XYZ����
	btsTolerance m_tolerance;				// �������ݲ�������У�
	btsDateTime m_dateTime;					// ����
};

