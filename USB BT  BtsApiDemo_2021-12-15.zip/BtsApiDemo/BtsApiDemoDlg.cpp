﻿// BtsApiDemoDlg.cpp: 实现文件
//

#include "stdafx.h"
#include "BtsApiDemo.h"
#include "BtsApiDemoDlg.h"
#include "afxdialogex.h"
#include <string>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define ID_COLORSPACE_MENU_ITEM_BEGIN	(WM_USER)
#define ID_COLORSPACE_MENU_ITEM_END		(ID_COLORSPACE_MENU_ITEM_BEGIN + btsDIN_LAB99)
#define ID_ILLUMINANT_MENU_ITEM_BEGIN	(ID_COLORSPACE_MENU_ITEM_END + 1)
#define ID_ILLUMINANT_MENU_ITEM_END		(ID_ILLUMINANT_MENU_ITEM_BEGIN + btsF12)
#define ID_OBSERVER_MENU_ITEM_BEGIN		(ID_ILLUMINANT_MENU_ITEM_END + 1)
#define ID_OBSERVER_MENU_ITEM_END		(ID_OBSERVER_MENU_ITEM_BEGIN + btsCIE1964)

#define CHECK_CONNECTION()	\
	if (!IsOpen())	\
	{	\
		AfxMessageBox(IDS_DEVICE_NOT_CONNECTED, MB_OK|MB_ICONEXCLAMATION);	\
		return;	\
	}

// namespace
// {
// 获取错误码描述字符串
CString GetErrDesc(btsErrorCode error)
{
	UINT id = 0;
	switch (error)
	{
	case btsNO_ERROR: id = IDS_NO_ERROR;
		break;
	case btsDEVICE_NOT_FOUND: id = IDS_DEVICE_NOT_FOUND;
		break;
	case btsOPEN_DEVICE_FAILED: id = IDS_OPEN_DEVICE_FAILED;
		break;
	case btsDEVICE_NOT_OPEN: id = IDS_DEVICE_NOT_CONNECTED;
		break;
	case btsNO_SESSION: id = IDS_NO_SESSION;
		break;
	case btsDEVICE_BUSY: id = IDS_DEVICE_BUSY;
		break;
	case btsSEND_TIMEOUT: id = IDS_SEND_TIMEOUT;
		break;
	case btsRECV_TIMEOUT: id = IDS_RECV_TIMEOUT;
		break;
	case btsREMOTE_ERROR: id = IDS_REMOTE_ERROR;
		break;
	case btsDEVICE_ERROR: id = IDS_DEVICE_ERROR;
		break;
	case btsINVALID_PACKET: id = IDS_INVALID_PACKET;
		break;
	case btsUNEXPECT_COMMAND: id = IDS_UNEXPECT_COMMAND;
		break;
	case btsUNCALIBRATED: id = IDS_UNCALIBRATED;
		break;
	case btsSTORAGE_IS_FULL: id = IDS_STORAGE_IS_FULL;
		break;
	case btsCALIBRATION_FAILED: id = IDS_CALIBRATION_FAILED;
		break;
	case btsNOT_ENOUGH_STORAGE: id = IDS_NOT_ENOUGH_STORAGE;
		break;
	case btsINVALID_PARAMETER: id = IDS_INVALID_PARAMETER;
		break;
	case btsINVALID_HANDLE: id = IDS_INVALID_HANDLE;
		break;
	case btsNOT_SUPPORTED: id = IDS_NOT_SUPPORTED;
		break;
	default: id = IDS_UNKNOWN_ERROR_CODE;
		break;
	}

	CString msg;
	msg.LoadString(id);
	return msg;
}

// 显示错误提示
void ShowErrorMessage(btsErrorCode err)
{
	AfxMessageBox(GetErrDesc(err), MB_OK | MB_ICONWARNING);
}

// 加载字符资源ID字符串
CString LoadString(UINT ids)
{
	CString str;
	str.LoadString(ids);
	return str;
}

// 多字节字符转换为CString
CString MstrToStr(const char* lpsz)
{
#ifdef _UNICODE
	CString str;
	int n = MultiByteToWideChar(CP_ACP, 0, lpsz, -1, str.GetBuffer(1024), 1024);
	str.ReleaseBuffer();
	return str;

#else
		return CString(lpsz);
#endif
}

// CString转换为多字节字符串
std::string StrToMstr(CString str)
{
#ifdef _UNICODE
	int n = WideCharToMultiByte(CP_ACP, 0, str, str.GetLength(),
	                            NULL, 0, NULL, NULL);
	char* buf = new char[n + 1];
	memset(buf, 0, n + 1);
	WideCharToMultiByte(CP_ACP, 0, str, str.GetLength(),
	                    buf, n, NULL, NULL);
	auto ret = std::string(buf);
	delete[] buf;
	return ret;
#else
		return std::string((LPCSTR)str);
#endif
}

// 整数转换为字符串
CString ToString(int iVal)
{
	CString str;
	str.Format(_T("%d"), iVal);
	return str;
}

CString ToString(double val, int precision)
{
	CString str;
	str.Format(_T("%.*f"), precision, val);
	return str;
}

// 获取口径名
CString ApertureName(int aperture)
{
	static const LPCTSTR Names[] = {
		_T("Φ4mm"),
		_T("Φ8mm"),
		_T("Φ15mm"),
		_T("Φ25.4mm"),
	};
	return Names[aperture];
}

// 获取透镜位置名
CString LensPosName(int lensPos)
{
	static const LPCTSTR Names[] = {
		_T("Φ4mm"),
		_T("Φ8mm"),
		_T("Φ15mm"),
		_T("Φ25.4mm"),
	};
	return Names[lensPos];
}

// 获取透镜切换模式名
CString LensModeName(int lensMode)
{
	if (lensMode == btsLENS_MODE_AUTO)
		return LoadString(IDS_AUTO);
	return LoadString(IDS_MANUAL);
}

// 镜面光排除/包含
CString ScModeName(int scMode)
{
	static const LPCTSTR Names[] = {
		_T("SCI"),
		_T("SCE"),
		_T("I+E")
	};
	return Names[scMode];
}

// UV名
CString UvModeName(int uvMode)
{
	UINT id = 0;
	switch (uvMode)
	{
	case btsUV_CUT_NONE: id = IDS_UV_CUT_NONE;
		break;
	case btsUV_CUT_400: id = IDS_UV_CUT_400;
		break;
	case btsUV_CUT_420: id = IDS_UV_CUT_420;
		break;
	case btsUV_CUT_460: id = IDS_UV_CUT_460;
		break;
	default: id = AFX_IDS_UNKNOWNTYPE;
		break;
	}
	return LoadString(id);
}

// 观察者名
CString ObserverName(int observer)
{
	const LPCTSTR Names[] = {_T("2°"), _T("10°")};
	return Names[observer];
}

// 光源名
CString IlluminantName(int illuminant)
{
	static const LPCTSTR Names[] = {
		_T("D65"),
		_T("D50"),
		_T("A"),
		_T("C"),
		_T("D55"),
		_T("D75"),
		_T("F1"),
		_T("F2"),
		_T("F3"),
		_T("F4"),
		_T("F5"),
		_T("F6"),
		_T("F7"),
		_T("F8"),
		_T("F9"),
		_T("F10"),
		_T("F11"),
		_T("F12"),
	};
	return Names[illuminant];
}

// 色空间名
CString ColorSpaceName(int colorSpace)
{
	const LPCTSTR Names[] = {
		_T("CIE L*a*b*"),
		_T("CIE XYZ"),
		_T("CIE Yxy"),
		_T("CIE L*C*h°"),
		_T("CIE L*u*v*"),
		_T("Hunter Lab"),
		_T("sRGB"),
		_T("Munsell"),
		_T("βxy"),
		_T("DIN99 Lab"),
	};
	return Names[colorSpace];
}

// 色差公式名
CString ColorDiffFormulaName(int colorDiffFormula)
{
	const LPCTSTR Names[] = {
		_T("CIEDE1976"),
		_T("CIEDE1994"),
		_T("CIEDE2000"),
		_T("CMC(1:1)"),
		_T("CMC(2:1)"),
		_T("DIN99"),
		_T("Hunter DE"),
	};
	return Names[colorDiffFormula];
}

// 颜色指数名
CString ColorIndexName(int colorIndex)
{
	static const int IDs[] = {
		IDS_INVALID,
		IDS_YELLOWNESS,
		IDS_WHITENESS,
		IDS_STRENGTH,
		IDS_METAMERISM_INDIEX,
		IDS_OPACTITY,
		IDS_HUE_CLASSIFY_555,
		IDS_STRENGTH,
		IDS_GARDNER_INDEX,
		IDS_COLOR_FASTNESS,
		IDS_PT_CO_INDEX,
		IDS_GLOSS_8
	};

	return LoadString(IDs[colorIndex]);
}

const LPCTSTR* GetColorSpaceLabels(int colorSpace)
{
	LPCTSTR labels[][3] = {
		{_T("L*"), _T("a*"), _T("b*")},
		{_T("X"), _T("Y"), _T("Z")},
		{_T("Y"), _T("x"), _T("y")},
		{_T("L*"), _T("C*"), _T("h°")},
		{_T("L*"), _T("u*"), _T("v*")},
		{_T("L"), _T("a"), _T("b")},
		{_T("R"), _T("G"), _T("B")},
		{_T("Hue"), _T("Value"), _T("Chroma")},
		{_T("β"), _T("x"), _T("y")},
		{_T("L99"), _T("a99"), _T("b99")},
	};

	return labels[colorSpace];
}

// }


// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

	// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX); // DDX/DDV 支持

	// 实现
protected:
DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)

END_MESSAGE_MAP()


// CBtsApiDemoDlg 对话框


CBtsApiDemoDlg::CBtsApiDemoDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_BTSAPIDEMO_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_instrument = NULL;
	m_colorSpace = btsCIELAB;
	m_illuminant = btsD65;
	m_observer = btsCIE1964;
	m_scMode = btsSCI;

	m_standard = NULL;
	m_test = NULL;
}

void CBtsApiDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_DEV_INFO, m_listDevInfo);
	DDX_Control(pDX, IDC_LIST_DEV_STATUS, m_listDevStatus);
	DDX_Control(pDX, IDC_LIST_MES_RESULT, m_listMesResult);
	DDX_Control(pDX, IDC_LIST_STANDARDS, m_listStandards);
	DDX_Control(pDX, IDC_LIST_TESTS, m_listTests);
	DDX_Control(pDX, IDC_STD_INDEX, m_editStdIndex);
	DDX_Control(pDX, IDC_SPIN_STD_INDEX, m_spinStdIndex);
	DDX_Control(pDX, IDC_UVMODE, m_uvModes);
}

BEGIN_MESSAGE_MAP(CBtsApiDemoDlg, CDialogEx)
		ON_WM_SYSCOMMAND()
		ON_WM_PAINT()
		ON_WM_QUERYDRAGICON()
		ON_BN_CLICKED(IDC_CONNECT, &CBtsApiDemoDlg::OnBnClickedConnect)
		ON_BN_CLICKED(IDC_GET_DEV_INFO, &CBtsApiDemoDlg::OnBnClickedGetDevInfo)
		ON_BN_CLICKED(IDC_GET_DEV_STATUS, &CBtsApiDemoDlg::OnBnClickedGetDevStatus)
		ON_BN_CLICKED(IDC_CAL_BLACK, &CBtsApiDemoDlg::OnBnClickedCalBlack)
		ON_BN_CLICKED(IDC_CAL_WHITE, &CBtsApiDemoDlg::OnBnClickedCalWhite)
		ON_BN_CLICKED(IDC_MES_STD, &CBtsApiDemoDlg::OnBnClickedMesStd)
		ON_BN_CLICKED(IDC_MES_TEST, &CBtsApiDemoDlg::OnBnClickedMesTest)
		ON_NOTIFY(NM_RCLICK, IDC_LIST_MES_RESULT, &CBtsApiDemoDlg::OnRclickListMesResult)
		ON_UPDATE_COMMAND_UI_RANGE(ID_COLORSPACE_MENU_ITEM_BEGIN, ID_COLORSPACE_MENU_ITEM_END, &CBtsApiDemoDlg::
OnUpdateColorSpaceMenuItem)
		ON_UPDATE_COMMAND_UI_RANGE(ID_ILLUMINANT_MENU_ITEM_BEGIN, ID_ILLUMINANT_MENU_ITEM_END, &CBtsApiDemoDlg::
OnUpdateIlluminantMenuItem)
		ON_UPDATE_COMMAND_UI_RANGE(ID_OBSERVER_MENU_ITEM_BEGIN, ID_OBSERVER_MENU_ITEM_END, &CBtsApiDemoDlg::
OnUpdateObserverMenuItem)
		ON_COMMAND_RANGE(ID_COLORSPACE_MENU_ITEM_BEGIN, ID_COLORSPACE_MENU_ITEM_END, &CBtsApiDemoDlg::
OnColorSpaceMenuItemClick)
		ON_COMMAND_RANGE(ID_ILLUMINANT_MENU_ITEM_BEGIN, ID_ILLUMINANT_MENU_ITEM_END, &CBtsApiDemoDlg::
OnIlluminantMenuItemClick)
		ON_COMMAND_RANGE(ID_OBSERVER_MENU_ITEM_BEGIN, ID_OBSERVER_MENU_ITEM_END, &CBtsApiDemoDlg::
OnObserverMenuItemClick)
		ON_WM_INITMENUPOPUP()
		ON_COMMAND(ID_SCMODE_SCI, &CBtsApiDemoDlg::OnScmodeSci)
		ON_UPDATE_COMMAND_UI(ID_SCMODE_SCI, &CBtsApiDemoDlg::OnUpdateScmodeSci)
		ON_COMMAND(ID_SCMODE_SCE, &CBtsApiDemoDlg::OnScmodeSce)
		ON_UPDATE_COMMAND_UI(ID_SCMODE_SCE, &CBtsApiDemoDlg::OnUpdateScmodeSce)
		ON_BN_CLICKED(IDC_UPLOAD_STANDARDS, &CBtsApiDemoDlg::OnBnClickedUploadStandards)
		//	ON_NOTIFY(HDN_ITEMCLICK, 0, &CBtsApiDemoDlg::OnItemclickListStandards)
		//		ON_NOTIFY(HDN_ITEMDBLCLICK, 0, &CBtsApiDemoDlg::OnItemdblclickListStandards)
		ON_NOTIFY(NM_RCLICK, IDC_LIST_STANDARDS, &CBtsApiDemoDlg::OnRclickListStandards)
		ON_NOTIFY(NM_RCLICK, IDC_LIST_TESTS, &CBtsApiDemoDlg::OnRclickListTests)
		ON_NOTIFY(NM_DBLCLK, IDC_LIST_STANDARDS, &CBtsApiDemoDlg::OnNMDblclkListStandards)
		ON_COMMAND(ID_STD_UPLOAD_TESTS, &CBtsApiDemoDlg::OnStdUploadTests)
		ON_UPDATE_COMMAND_UI(ID_STD_UPLOAD_TESTS, &CBtsApiDemoDlg::OnUpdateStdUploadTests)
		ON_COMMAND(ID_STD_DEL_SEL, &CBtsApiDemoDlg::OnStdDelSel)
		ON_UPDATE_COMMAND_UI(ID_STD_DEL_SEL, &CBtsApiDemoDlg::OnUpdateStdDelSel)
		ON_COMMAND(ID_STD_DEL_ALL, &CBtsApiDemoDlg::OnStdDelAll)
		ON_UPDATE_COMMAND_UI(ID_STD_DEL_ALL, &CBtsApiDemoDlg::OnUpdateStdDelAll)
		ON_COMMAND(ID_STD_CLEAR_LIST, &CBtsApiDemoDlg::OnStdClearList)
		ON_UPDATE_COMMAND_UI(ID_STD_CLEAR_LIST, &CBtsApiDemoDlg::OnUpdateStdClearList)
		ON_COMMAND(ID_TST_CLEAR_LIST, &CBtsApiDemoDlg::OnTstClearList)
		ON_UPDATE_COMMAND_UI(ID_TST_CLEAR_LIST, &CBtsApiDemoDlg::OnUpdateTstClearList)
		ON_COMMAND(ID_TST_DEL_ALL, &CBtsApiDemoDlg::OnTstDelAll)
		ON_UPDATE_COMMAND_UI(ID_TST_DEL_ALL, &CBtsApiDemoDlg::OnUpdateTstDelAll)
		ON_COMMAND(ID_TST_DEL_SEL, &CBtsApiDemoDlg::OnTstDelSel)
		ON_UPDATE_COMMAND_UI(ID_TST_DEL_SEL, &CBtsApiDemoDlg::OnUpdateTstDelSel)
	ON_BN_CLICKED(IDC_GET_UV_MODE, &CBtsApiDemoDlg::OnBnClickedGetUvMode)
	ON_BN_CLICKED(IDC_SET_UV_MODE, &CBtsApiDemoDlg::OnBnClickedSetUvMode)
END_MESSAGE_MAP()


// CBtsApiDemoDlg 消息处理程序

BOOL CBtsApiDemoDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE); // 设置大图标
	SetIcon(m_hIcon, FALSE); // 设置小图标

	m_standardContextMenu.LoadMenu(IDR_STANDARDS_CONTEXT_MENU);
	m_testContextMenu.LoadMenu(IDR_TESTS_LIST_CONTEXT_MENU);
	m_resultContextMenu.LoadMenu(IDR_RESULT_LIST_CONTEXT_MENU);

	auto colorSpaceMenu = m_resultContextMenu.GetSubMenu(0)->GetSubMenu(0);
	colorSpaceMenu->DeleteMenu(0, MF_BYPOSITION); // 删除占位项
	for (int colorSpace = 0; colorSpace <= btsDIN_LAB99; ++colorSpace)
	{
		// 不支持 Munsell 色空间
		if (colorSpace != btsMUNSELL)
		{
			colorSpaceMenu->AppendMenu(MF_STRING,
			                           ID_COLORSPACE_MENU_ITEM_BEGIN + colorSpace, ColorSpaceName(colorSpace));
		}
	}

	auto illuminantSpaceMenu = m_resultContextMenu.GetSubMenu(0)->GetSubMenu(1);
	illuminantSpaceMenu->DeleteMenu(0, MF_BYPOSITION);
	for (int illuminant = 0; illuminant <= btsF12; ++illuminant)
	{
		illuminantSpaceMenu->AppendMenu(MF_STRING,
		                                ID_ILLUMINANT_MENU_ITEM_BEGIN + illuminant,
		                                IlluminantName(illuminant));
	}

	auto observerMenu = m_resultContextMenu.GetSubMenu(0)->GetSubMenu(2);
	observerMenu->DeleteMenu(0, MF_BYPOSITION);
	for (int observer = 0; observer <= btsCIE1964; observer++)
	{
		observerMenu->AppendMenu(MF_STRING,
		                         ID_OBSERVER_MENU_ITEM_BEGIN + observer,
		                         ObserverName(observer));
	}


	// 初始化信息表头
	m_listDevInfo.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_listDevInfo.InsertColumn(0, LoadString(IDS_ITEM), 0, 72);
	m_listDevInfo.InsertColumn(1, LoadString(IDS_VALUE), 0, 150);


	m_listDevStatus.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_listDevStatus.InsertColumn(0, LoadString(IDS_ITEM), 0, 72);
	m_listDevStatus.InsertColumn(1, LoadString(IDS_VALUE), 0, 150);

	m_listMesResult.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_listMesResult.InsertColumn(0, LoadString(IDS_ITEM), 0, 72);
	m_listMesResult.InsertColumn(1, LoadString(IDS_STANDARD), 0, 100);
	m_listMesResult.InsertColumn(2, LoadString(IDS_TEST), 0, 100);
	m_listMesResult.InsertColumn(3, LoadString(IDS_COLOR_DIFF), 0, 100);

	m_spinStdIndex.SetBuddy(&m_editStdIndex);
	m_spinStdIndex.SetRange(-1, 1000);
	m_spinStdIndex.SetPos(-1);

	// 初始化标样列表和试样列表
	m_listStandards.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_listTests.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);

	UINT labelIds[] =
	{
		IDS_ID,
		IDS_NAME,
		IDS_DATE_TIME,
		IDS_SPECTRAL_TYPE,
		IDS_ILLUMINANT,
		IDS_OBSERVER,
		IDS_L,
		IDS_A,
		IDS_B
	};
	for (int i = 0; i < ARRAYSIZE(labelIds); i++)
	{
		m_listStandards.InsertColumn(i, LoadString(labelIds[i]), 0, 75);
		m_listTests.InsertColumn(i, LoadString(labelIds[i]), 0, 75);
	}

	for (int i = 0; i < btsSPECTRAL_DATA_COUNT; i++)
	{
		CString str;
		str.Format(_T("%d nm"), btsWAVELENGTH_BEGIN + btsWAVELENGTH_STEP * i);
		int nColumn = ARRAYSIZE(labelIds) + i;
		m_listStandards.InsertColumn(nColumn, str, 0, 75);
		m_listTests.InsertColumn(nColumn, str, 0, 75);
	}


	m_uvModes.AddString(LoadString(IDS_UV_CUT_NONE));
	m_uvModes.AddString(LoadString(IDS_UV_CUT_400));
	m_uvModes.AddString(LoadString(IDS_UV_CUT_420));
	m_uvModes.AddString(LoadString(IDS_UV_CUT_460));

	return TRUE; // 除非将焦点设置到控件，否则返回 TRUE
}

void CBtsApiDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CBtsApiDemoDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CBtsApiDemoDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


// 连接/断开
void CBtsApiDemoDlg::OnBnClickedConnect()
{
	// 如果已连接就断开连接，否则连接仪器

	if (IsOpen())
	{
		btsClose(m_instrument);
		m_instrument = NULL;
	}
	else
	{
		m_instrument = btsOpen(NULL);
		if (m_instrument == NULL)
		{
			AfxMessageBox(IDS_OPEN_DEVICE_FAILED, MB_OK | MB_ICONWARNING);
		}
		else
		{
			// 获取标样总数
			uint32_t total;
			auto err = btsGetTotalStandards(m_instrument, &total);
			if (err == btsNO_ERROR)
			{
				m_spinStdIndex.SetRange(-1, (short)total);
			}
		}
	}
	SetDlgItemText(IDC_CONNECT, LoadString(IsOpen() ? IDS_DISCONNECT : IDS_CONNECT));
}

//获取仪器信息
void CBtsApiDemoDlg::OnBnClickedGetDevInfo()
{
	m_listDevInfo.DeleteAllItems();

	CHECK_CONNECTION();

	btsDeviceInfo devInfo;
	auto err = btsGetDeviceInfo(m_instrument, &devInfo);
	if (err != btsNO_ERROR)
	{
		ShowErrorMessage(err);
		return;
	}

	int nItem = 0;
	m_listDevInfo.InsertItem(nItem, LoadString(IDS_INSTRUMENT_MODEL));
	m_listDevInfo.SetItemText(nItem, 1, MstrToStr(devInfo.model));

	m_listDevInfo.InsertItem(++nItem, LoadString(IDS_OPTICAL_STRUCTURE));
	m_listDevInfo.SetItemText(nItem, 1, MstrToStr(devInfo.optical));

	m_listDevInfo.InsertItem(++nItem, LoadString(IDS_SN));
	m_listDevInfo.SetItemText(nItem, 1, MstrToStr(devInfo.sn));

	m_listDevInfo.InsertItem(++nItem, LoadString(IDS_SOFTWARE_VERSION));
	m_listDevInfo.SetItemText(nItem, 1, MstrToStr(devInfo.software_version));

	m_listDevInfo.InsertItem(++nItem, LoadString(IDS_HARDWARE_VERSION));
	m_listDevInfo.SetItemText(nItem, 1, MstrToStr(devInfo.hardware_version));

	m_listDevInfo.InsertItem(++nItem, LoadString(IDS_WHITE_BOARD_NUMBER));
	m_listDevInfo.SetItemText(nItem, 1, MstrToStr(devInfo.white_board_number));

	m_listDevInfo.InsertItem(++nItem, LoadString(IDS_BLACK_BUCKET_NUMBER));
	m_listDevInfo.SetItemText(nItem, 1, MstrToStr(devInfo.black_bucket_number));

	m_listDevInfo.InsertItem(++nItem, LoadString(IDS_STANDARD_CAPACITY));
	m_listDevInfo.SetItemText(nItem, 1, ToString(devInfo.standard_capacity));

	m_listDevInfo.InsertItem(++nItem, LoadString(IDS_TRIAL_CAPACITY));
	m_listDevInfo.SetItemText(nItem, 1, ToString(devInfo.trial_capacity));
}

// 获取仪器状态
void CBtsApiDemoDlg::OnBnClickedGetDevStatus()
{
	m_listDevStatus.DeleteAllItems();

	CHECK_CONNECTION();

	btsInstrumentStatus status;
	auto err = btsGetInstrumentStatus(m_instrument, &status);
	if (err != btsNO_ERROR)
	{
		ShowErrorMessage(err);
		return;
	}

	int nItem = 0;
	m_listDevStatus.InsertItem(nItem, LoadString(IDS_MEASUREMENT_APERTURE));
	m_listDevStatus.SetItemText(nItem, 1, ApertureName(status.caliber));

	m_listDevStatus.InsertItem(++nItem, LoadString(IDS_LENS_POSITION));
	m_listDevStatus.SetItemText(nItem, 1, LensPosName(status.lens_pos));

	m_listDevStatus.InsertItem(++nItem, LoadString(IDS_LENS_SWITCH_MODE));
	m_listDevStatus.SetItemText(nItem, 1, LensModeName(status.lens_switch_mode));

	m_listDevStatus.InsertItem(++nItem, LoadString(IDS_TRANSMISSION_FLAG));
	m_listDevStatus.SetItemText(nItem, 1, LoadString(status.transmission ? IDS_TRANSMISSIVE : IDS_REFLECTIVE));

	m_listDevStatus.InsertItem(++nItem, LoadString(IDS_SC_MODE));
	m_listDevStatus.SetItemText(nItem, 1, ScModeName(status.sc_mode));

	m_listDevStatus.InsertItem(++nItem, LoadString(IDS_UV_MODE));
	m_listDevStatus.SetItemText(nItem, 1, UvModeName(status.uv_mode));

	m_listDevStatus.InsertItem(++nItem, LoadString(IDS_OBSERVER));
	m_listDevStatus.SetItemText(nItem, 1, ObserverName(status.observer));

	m_listDevStatus.InsertItem(++nItem, LoadString(IDS_ILLUMINANT));
	m_listDevStatus.SetItemText(nItem, 1, IlluminantName(status.light_type));

	m_listDevStatus.InsertItem(++nItem, LoadString(IDS_COLOR_SPACE));
	m_listDevStatus.SetItemText(nItem, 1, ColorSpaceName(status.color_space));

	m_listDevStatus.InsertItem(++nItem, LoadString(IDS_COLOR_DIFF_FORMULA));
	m_listDevStatus.SetItemText(nItem, 1, ColorDiffFormulaName(status.color_diff_formula));

	m_listDevStatus.InsertItem(++nItem, LoadString(IDS_COLOR_INDEX));
	m_listDevStatus.SetItemText(nItem, 1, ColorIndexName(status.color_index));

	m_listDevStatus.InsertItem(++nItem, LoadString(IDS_STANDARD_COUNT));
	m_listDevStatus.SetItemText(nItem, 1, ToString(status.standard_count));

	m_listDevStatus.InsertItem(++nItem, LoadString(IDS_TRIAL_COUNT));
	m_listDevStatus.SetItemText(nItem, 1, ToString(status.trial_count));

	m_listDevStatus.InsertItem(++nItem, LoadString(IDS_IS_CALIBRATED));
	m_listDevStatus.SetItemText(nItem, 1, LoadString(status.is_calibrated ? IDS_CALIBRATED : IDS_UNCALIBRATED));
}

// 黑校准
void CBtsApiDemoDlg::OnBnClickedCalBlack()
{
	CHECK_CONNECTION();

	// 获取仪器状态，根据透射或反射进行不同的提示
	btsInstrumentStatus status;

	auto err = btsGetInstrumentStatus(m_instrument, &status);
	if (err != btsNO_ERROR)
	{
		ShowErrorMessage(err);
		return;
	}

	// status.transmission为零表示反射模式，否则表示仪器处于透射模式
	UINT promptId = status.transmission == 0
		                ? IDS_REFLECTIVE_BLACK_CALIBRATION_PROMPT
		                : IDS_TRANSMISSIVE_BLACK_CALIBRATION_PROMPT;
	UINT result = AfxMessageBox(promptId, MB_OKCANCEL | MB_ICONINFORMATION);
	if (result == IDCANCEL)
	{
		return;
	}

	HCURSOR savedCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));

	// 进行黑校
	err = btsCalibrateBlack(m_instrument);

	SetCursor(savedCursor);

	if (err == btsNO_ERROR)
	{
		AfxMessageBox(IDS_SUCCESSFUL);
	}
	else
	{
		ShowErrorMessage(err);
	}
}

// 白校
void CBtsApiDemoDlg::OnBnClickedCalWhite()
{
	CHECK_CONNECTION();

	// 获取仪器状态，根据透射或反射进行不同的提示
	btsInstrumentStatus status;

	auto err = btsGetInstrumentStatus(m_instrument, &status);
	if (err != btsNO_ERROR)
	{
		ShowErrorMessage(err);
		return;
	}

	// status.transmission为零表示反射模式，否则表示仪器处于透射模式
	UINT promptId = status.transmission == 0
		                ? IDS_REFLECTIVE_WHITE_CALIBRATION_PROMPT
		                : IDS_TRANSMISSIVE_WHITE_CALIBRATION_PROMPT;
	UINT result = AfxMessageBox(promptId, MB_OKCANCEL | MB_ICONINFORMATION);
	if (result == IDCANCEL)
	{
		return;
	}

	HCURSOR savedCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));

	// 进行白校
	err = btsCalibrateWhite(m_instrument);

	SetCursor(savedCursor);

	if (err == btsNO_ERROR)
	{
		AfxMessageBox(IDS_SUCCESSFUL);
	}
	else
	{
		ShowErrorMessage(err);
	}
}

// 更新测量如果列表的显示
void CBtsApiDemoDlg::UpdateResultList()
{
	m_listMesResult.DeleteAllItems();


	float stdValues[3];
	float testValues[3];
	auto stdSpectralData = m_standard ? m_standard->GetSpectralData(m_scMode == btsSCE) : NULL;
	auto testSpectralData = m_test ? m_test->GetSpectralData(m_scMode == btsSCE) : NULL;

	// 根据反射率计算指定颜色空间的颜色值

	if (stdSpectralData)
	{
		btsGetColorDataFromSpectralData(stdSpectralData,
		                                (btsColorSpace)m_colorSpace,
		                                (btsStandardIlluminant)m_illuminant,
		                                (btsStandardObserver)m_observer,
		                                stdValues);
	}
	if (testSpectralData)
	{
		btsGetColorDataFromSpectralData(testSpectralData,
		                                (btsColorSpace)m_colorSpace,
		                                (btsStandardIlluminant)m_illuminant,
		                                (btsStandardObserver)m_observer,
		                                testValues);
	}


	// 插入颜色值
	auto labels = GetColorSpaceLabels(m_colorSpace);
	for (int i = 0; i < 3; i++)
	{
		int nItem = m_listMesResult.GetItemCount();

		m_listMesResult.InsertItem(nItem, labels[i]);
		int precision = (labels[i] == _T("x") || labels[i] == _T("y")) ? 4 : 2;
		if (stdSpectralData)
		{
			m_listMesResult.SetItemText(nItem, 1, ToString(stdValues[i], precision));
		}
		if (testSpectralData)
		{
			m_listMesResult.SetItemText(nItem, 2, ToString(testValues[i], precision));
		}
		if (stdSpectralData && testSpectralData)
		{
			m_listMesResult.SetItemText(nItem, 3, ToString(testValues[i] - stdValues[i], precision));
		}
	}

	// 插入反射率数据
	for (int i = 0; i < btsSPECTRAL_DATA_COUNT; i++)
	{
		int nItem = m_listMesResult.GetItemCount();

		CString label;
		label.Format(_T("%d nm"), btsWAVELENGTH_BEGIN + btsWAVELENGTH_STEP * i);
		m_listMesResult.InsertItem(nItem, label);

		if (stdSpectralData)
		{
			m_listMesResult.SetItemText(nItem, 1, ToString(stdSpectralData[i] * 100, 2));
		}
		if (testSpectralData)
		{
			m_listMesResult.SetItemText(nItem, 2, ToString(testSpectralData[i] * 100, 2));
		}
		if (stdSpectralData && testSpectralData)
		{
			m_listMesResult.SetItemText(nItem, 3, ToString((testSpectralData[i] - stdSpectralData[i]) * 100, 2));
		}
	}
}


// 测量标样
void CBtsApiDemoDlg::OnBnClickedMesStd()
{
	CHECK_CONNECTION();

	auto savedCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));
	btsStandardRecord record;
	auto err = btsMeasureStandard(m_instrument, &record);
	SetCursor(savedCursor);
	if (err != btsNO_ERROR)
	{
		ShowErrorMessage(err);
		return;
	}

	m_standard = std::make_shared<Sample>(record);

	UpdateResultList();
}


// 测量试样
void CBtsApiDemoDlg::OnBnClickedMesTest()
{
	CHECK_CONNECTION();

	auto savedCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));
	btsTrialRecord record;
	auto err = btsMeasureTrial(m_instrument, &record);
	SetCursor(savedCursor);
	if (err != btsNO_ERROR)
	{
		ShowErrorMessage(err);
		return;
	}

	m_test = std::make_shared<Sample>(record);
	UpdateResultList();
}


void CBtsApiDemoDlg::OnRclickListMesResult(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);


	CPoint position;
	GetCursorPos(&position);

	m_resultContextMenu.GetSubMenu(0)
	                   ->TrackPopupMenu(TPM_LEFTALIGN | TPM_TOPALIGN, position.x, position.y, this);
	*pResult = 0;
}

void CBtsApiDemoDlg::OnUpdateColorSpaceMenuItem(CCmdUI* pCmdUi)
{
	pCmdUi->SetCheck((pCmdUi->m_nID - ID_COLORSPACE_MENU_ITEM_BEGIN) == m_colorSpace);
}

void CBtsApiDemoDlg::OnUpdateIlluminantMenuItem(CCmdUI* pCmdUi)
{
	pCmdUi->SetCheck((pCmdUi->m_nID - ID_ILLUMINANT_MENU_ITEM_BEGIN) == m_illuminant);
}

void CBtsApiDemoDlg::OnUpdateObserverMenuItem(CCmdUI* pCmdUi)
{
	pCmdUi->SetCheck((pCmdUi->m_nID - ID_OBSERVER_MENU_ITEM_BEGIN) == m_observer);
}

void CBtsApiDemoDlg::OnColorSpaceMenuItemClick(UINT nId)
{
	m_colorSpace = nId - ID_COLORSPACE_MENU_ITEM_BEGIN;
	UpdateResultList();
}

void CBtsApiDemoDlg::OnIlluminantMenuItemClick(UINT nId)
{
	m_illuminant = nId - ID_ILLUMINANT_MENU_ITEM_BEGIN;
	UpdateResultList();
}

void CBtsApiDemoDlg::OnObserverMenuItemClick(UINT nId)
{
	m_observer = nId - ID_OBSERVER_MENU_ITEM_BEGIN;
	UpdateResultList();
}

// 更新弹出菜单
void CBtsApiDemoDlg::OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu)
{
	//CDialogEx::OnInitMenuPopup(pPopupMenu, nIndex, bSysMenu);

	ASSERT(pPopupMenu != NULL);
	// Check the enabled state of various menu items.

	CCmdUI state;
	state.m_pMenu = pPopupMenu;
	ASSERT(state.m_pOther == NULL);
	ASSERT(state.m_pParentMenu == NULL);

	// Determine if menu is popup in top-level menu and set m_pOther to
	// it if so (m_pParentMenu == NULL indicates that it is secondary popup).
	HMENU hParentMenu;
	if (AfxGetThreadState()->m_hTrackingMenu == pPopupMenu->m_hMenu)
		state.m_pParentMenu = pPopupMenu; // Parent == child for tracking popup.
	else if ((hParentMenu = ::GetMenu(m_hWnd)) != NULL)
	{
		CWnd* pParent = this;
		// Child windows don't have menus--need to go to the top!
		if (pParent != NULL &&
			(hParentMenu = ::GetMenu(pParent->m_hWnd)) != NULL)
		{
			int nIndexMax = ::GetMenuItemCount(hParentMenu);
			for (int nIndex = 0; nIndex < nIndexMax; nIndex++)
			{
				if (::GetSubMenu(hParentMenu, nIndex) == pPopupMenu->m_hMenu)
				{
					// When popup is found, m_pParentMenu is containing menu.
					state.m_pParentMenu = CMenu::FromHandle(hParentMenu);
					break;
				}
			}
		}
	}

	state.m_nIndexMax = pPopupMenu->GetMenuItemCount();
	for (state.m_nIndex = 0; state.m_nIndex < state.m_nIndexMax;
	     state.m_nIndex++)
	{
		state.m_nID = pPopupMenu->GetMenuItemID(state.m_nIndex);
		if (state.m_nID == 0)
			continue; // Menu separator or invalid cmd - ignore it.

		ASSERT(state.m_pOther == NULL);
		ASSERT(state.m_pMenu != NULL);
		if (state.m_nID == (UINT)-1)
		{
			// Possibly a popup menu, route to first item of that popup.
			state.m_pSubMenu = pPopupMenu->GetSubMenu(state.m_nIndex);
			if (state.m_pSubMenu == NULL ||
				(state.m_nID = state.m_pSubMenu->GetMenuItemID(0)) == 0 ||
				state.m_nID == (UINT)-1)
			{
				continue; // First item of popup can't be routed to.
			}
			state.DoUpdate(this, TRUE); // Popups are never auto disabled.
		}
		else
		{
			// Normal menu item.
			// Auto enable/disable if frame window has m_bAutoMenuEnable
			// set and command is _not_ a system command.
			state.m_pSubMenu = NULL;
			state.DoUpdate(this, FALSE);
		}

		// Adjust for menu deletions and additions.
		UINT nCount = pPopupMenu->GetMenuItemCount();
		if (nCount < state.m_nIndexMax)
		{
			state.m_nIndex -= (state.m_nIndexMax - nCount);
			while (state.m_nIndex < nCount &&
				pPopupMenu->GetMenuItemID(state.m_nIndex) == state.m_nID)
			{
				state.m_nIndex++;
			}
		}
		state.m_nIndexMax = nCount;
	}
}


void CBtsApiDemoDlg::OnScmodeSci()
{
	m_scMode = btsSCI;
	UpdateResultList();
}


void CBtsApiDemoDlg::OnUpdateScmodeSci(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_scMode == btsSCI);
}


void CBtsApiDemoDlg::OnScmodeSce()
{
	m_scMode = btsSCE;
	UpdateResultList();
}


void CBtsApiDemoDlg::OnUpdateScmodeSce(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_scMode == btsSCE);
}


void CBtsApiDemoDlg::OnBnClickedUploadStandards()
{
	CHECK_CONNECTION();

	m_listStandards.DeleteAllItems();

	BOOL isOk;
	int stdIndex = (int)GetDlgItemInt(IDC_STD_INDEX, &isOk);

	btsStandardRecord* buffer = NULL;
	uint32_t count = 1;
	uint32_t from = stdIndex;
	btsErrorCode err;


	// 如果索引无效或为-1上传所有标样
	if (!isOk || stdIndex == -1)
	{
		from = 0;

		// 获取标样总数
		err = btsGetTotalStandards(m_instrument, &count);
		if (err != btsNO_ERROR)
		{
			ShowErrorMessage(err);
			return;
		}
	}

	buffer = new btsStandardRecord[count];

	// 输入无效时上传所有标样
	auto savedCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));
	err = btsUploadStandards(m_instrument, buffer, from, count);

	if (err != btsNO_ERROR)
	{
		ShowErrorMessage(err);
		delete[] buffer;
		SetCursor(savedCursor);
		return;
	}

	float lab[3];
	for (int i = 0; i < count; i++)
	{
		Sample sample(buffer[i]);
		m_listStandards.InsertItem(i, ToString(sample.Id()));
		m_listStandards.SetItemText(i, 1, sample.Name());
		m_listStandards.SetItemText(i, 2, sample.DateTime());
		m_listStandards.SetItemText(i, 3, LoadString(sample.IsTransmissive() ? IDS_TRANSMISSIVE : IDS_REFLECTIVE));
		m_listStandards.SetItemText(i, 4, IlluminantName(sample.Illuminant()));
		m_listStandards.SetItemText(i, 5, ObserverName(sample.Observer()));
		const auto xyz = sample.GetXyzData(m_scMode);
		if (xyz)
		{
			btsGetColorDataFromXyz(sample.Illuminant(), sample.Observer(), xyz, btsCIELAB, lab);
			m_listStandards.SetItemText(i, 6, ToString(lab[0], 2));
			m_listStandards.SetItemText(i, 7, ToString(lab[1], 2));
			m_listStandards.SetItemText(i, 8, ToString(lab[2], 2));
		}

		const auto spectralData = sample.GetSpectralData(m_scMode);
		if (spectralData)
		{
			for (int j = 0; j < btsSPECTRAL_DATA_COUNT; ++j)
			{
				m_listStandards.SetItemText(i, 9 + j, ToString(spectralData[j] * 100, 2));
			}
		}

		// 存储标样ID的值方便上传标相应试样
		m_listStandards.SetItemData(i, (DWORD_PTR)sample.Id());
	}


	delete[] buffer;
	SetCursor(savedCursor);
}


//void CBtsApiDemoDlg::OnItemclickListStandards(NMHDR *pNMHDR, LRESULT *pResult)
//{
//	LPNMHEADER phdr = reinterpret_cast<LPNMHEADER>(pNMHDR);
//	// TODO: 在此添加控件通知处理程序代码
//	*pResult = 0;
//}

// 双击标样上传相关联的试样
//void CBtsApiDemoDlg::OnItemdblclickListStandards(NMHDR* pNMHDR, LRESULT* pResult)
//{
//	LPNMHEADER phdr = reinterpret_cast<LPNMHEADER>(pNMHDR);
//	*pResult = 0;
//
//
//}


void CBtsApiDemoDlg::OnRclickListStandards(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: 在此添加控件通知处理程序代码
	*pResult = 0;

	CPoint position;
	GetCursorPos(&position);

	m_standardContextMenu.GetSubMenu(0)
	                     ->TrackPopupMenu(TPM_LEFTALIGN | TPM_TOPALIGN, position.x, position.y, this);
}


void CBtsApiDemoDlg::OnRclickListTests(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: 在此添加控件通知处理程序代码
	*pResult = 0;

	CPoint position;
	GetCursorPos(&position);

	m_testContextMenu.GetSubMenu(0)
	                 ->TrackPopupMenu(TPM_LEFTALIGN | TPM_TOPALIGN, position.x, position.y, this);
}

// 上传标样关联的试样
void CBtsApiDemoDlg::UploadTests(int nItem)
{
	m_curStdId = -1;
	m_listTests.DeleteAllItems();


	CHECK_CONNECTION();

	auto savedCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));

	uint32_t id = (uint32_t)m_listStandards.GetItemData(nItem);

	// 获取试样数
	uint32_t count;
	auto err = btsGetSampleCount(m_instrument, id, &count);
	if (err != btsNO_ERROR)
	{
		SetCursor(savedCursor);
		ShowErrorMessage(err);
		return;
	}
	if (count == 0)
	{
		SetCursor(savedCursor);
		return;
	}

	btsTrialRecord* buffer = new btsTrialRecord[count];
	err = btsUploadSamples(m_instrument, buffer, id, 0, count);
	if (err != btsNO_ERROR)
	{
		delete[] buffer;
		SetCursor(savedCursor);
		ShowErrorMessage(err);
		return;
	}

	float lab[3];
	for (int i = 0; i < count; i++)
	{
		Sample sample(buffer[i]);
		m_listTests.InsertItem(i, ToString(sample.Id()));
		m_listTests.SetItemText(i, 1, sample.Name());
		m_listTests.SetItemText(i, 2, sample.DateTime());
		m_listTests.SetItemText(i, 3, LoadString(sample.IsTransmissive() ? IDS_TRANSMISSIVE : IDS_REFLECTIVE));
		m_listTests.SetItemText(i, 4, IlluminantName(sample.Illuminant()));
		m_listTests.SetItemText(i, 5, ObserverName(sample.Observer()));

		const auto xyz = sample.GetXyzData(m_scMode);
		if (xyz)
		{
			btsGetColorDataFromXyz(sample.Illuminant(), sample.Observer(), sample.GetXyzData(m_scMode),
			                       btsCIELAB, lab);
			m_listTests.SetItemText(i, 6, ToString(lab[0], 2));
			m_listTests.SetItemText(i, 7, ToString(lab[1], 2));
			m_listTests.SetItemText(i, 8, ToString(lab[2], 2));
		}

		const auto spectralData = sample.GetSpectralData(m_scMode);
		if (spectralData)
		{
			for (int j = 0; j < btsSPECTRAL_DATA_COUNT; ++j)
			{
				m_listTests.SetItemText(i, 9 + j, ToString(spectralData[j] * 100, 2));
			}
		}

		// 存储标样ID的值方便上传标相应试样
		m_listTests.SetItemData(i, (DWORD_PTR)sample.Id());
	}

	m_curStdId = id;

	delete[] buffer;
	SetCursor(savedCursor);
	return;
}


void CBtsApiDemoDlg::OnNMDblclkListStandards(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: 在此添加控件通知处理程序代码
	*pResult = 0;

	if (pNMItemActivate->iItem < 0)
		return;

	UploadTests(pNMItemActivate->iItem);
}


void CBtsApiDemoDlg::OnStdUploadTests()
{
	auto pos = m_listStandards.GetFirstSelectedItemPosition();
	if (pos == NULL)
		return;

	UploadTests(m_listStandards.GetNextSelectedItem(pos));
}


void CBtsApiDemoDlg::OnUpdateStdUploadTests(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsOpen() && m_listStandards.GetSelectedCount() > 0);
}


void CBtsApiDemoDlg::OnStdDelSel()
{
	auto pos = m_listStandards.GetFirstSelectedItemPosition();
	int nItem = m_listStandards.GetNextSelectedItem(pos);
	if (nItem >= 0)
	{
		int nId = m_listStandards.GetItemData(nItem);
		auto err = btsDeleteStandard(m_instrument, nId);
		if (err == btsNO_ERROR)
		{
			AfxMessageBox(IDS_SUCCESSFUL);
			m_listStandards.DeleteItem(nItem);
		}
		else
		{
			ShowErrorMessage(err);
		}
	}
}


void CBtsApiDemoDlg::OnUpdateStdDelSel(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsOpen());
}


void CBtsApiDemoDlg::OnStdDelAll()
{
	auto err = btsDeleteAllRecords(m_instrument);
	if (err == btsNO_ERROR)
	{
		AfxMessageBox(IDS_SUCCESSFUL);
		m_listStandards.DeleteAllItems();
		m_listTests.DeleteAllItems();
	}
	else
	{
		ShowErrorMessage(err);
	}
}


void CBtsApiDemoDlg::OnUpdateStdDelAll(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsOpen() && m_listStandards.GetItemCount() > 0);
}


void CBtsApiDemoDlg::OnStdClearList()
{
	m_listStandards.DeleteAllItems();
	m_listTests.DeleteAllItems();
}


void CBtsApiDemoDlg::OnUpdateStdClearList(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_listStandards.GetItemCount());
}

// 清空试样列表
void CBtsApiDemoDlg::OnTstClearList()
{
	m_listTests.DeleteAllItems();
}


void CBtsApiDemoDlg::OnUpdateTstClearList(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_listTests.GetItemCount() > 0);
}

// 删除所有试样
void CBtsApiDemoDlg::OnTstDelAll()
{
	auto err = btsDeleteSample(m_instrument, m_curStdId, -1);
	if (err == btsNO_ERROR)
	{
		AfxMessageBox(IDS_SUCCESSFUL);
		m_listTests.DeleteAllItems();
	}
	else
	{
		ShowErrorMessage(err);
	}
}


void CBtsApiDemoDlg::OnUpdateTstDelAll(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsOpen() && m_listTests.GetItemCount() > 0 && m_curStdId != -1);
}

// 删除所选试样
void CBtsApiDemoDlg::OnTstDelSel()
{
	auto pos = m_listTests.GetFirstSelectedItemPosition();
	if (pos != NULL)
	{
		// 试样删除只能以序号方式
		int nItem = m_listTests.GetNextSelectedItem(pos);
		auto err = btsDeleteSample(m_instrument, m_curStdId, nItem);
		if (err == btsNO_ERROR)
		{
			AfxMessageBox(IDS_SUCCESSFUL);
			m_listTests.DeleteItem(nItem);
		}
		else
		{
			ShowErrorMessage(err);
		}
	}
}


void CBtsApiDemoDlg::OnUpdateTstDelSel(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsOpen() && m_listTests.GetSelectedCount() > 0 && m_curStdId != -1);
}


void CBtsApiDemoDlg::OnBnClickedGetUvMode()
{
	uint32_t uv_mode;
	auto err = btsGetMeasurementParameter(m_instrument, btsMP_UV_MODE, &uv_mode);
	if (err == btsNO_ERROR)
	{
		m_uvModes.SetCurSel(uv_mode);
		AfxMessageBox(IDS_SUCCESSFUL);
	}
	else
	{
		ShowErrorMessage(err);
	}
}


void CBtsApiDemoDlg::OnBnClickedSetUvMode()
{
	int uv_mode = m_uvModes.GetCurSel();
	if (uv_mode < 0) {
		return;
	}

	auto err = btsSetMeasurementParameter(m_instrument, btsMP_UV_MODE, uv_mode);
	if (err == btsNO_ERROR)
	{
		AfxMessageBox(IDS_SUCCESSFUL);
	}
	else
	{
		ShowErrorMessage(err);
	}
}
