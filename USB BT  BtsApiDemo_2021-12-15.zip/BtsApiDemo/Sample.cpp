#include "stdafx.h"
#include "Sample.h"

CString MstrToStr(const char* lpsz);


template <typename RecordType>
void Sample::SetData(const RecordType& record)
{
	m_flags = record.flags;
	m_id = record.id;
	m_dateTime = record.date_time;
	m_name = MstrToStr(record.name);

	if (HasSci())
	{
		if (HasSpectralData()) 
		{
			for (int i = 0; i < btsSPECTRAL_DATA_COUNT; ++i)
			{
				// ���������ݳ���10000������Ӧ�ķ�����
				m_sci[i] = record.sci.spectral_data[i] * 0.0001f;
			}
			m_illuminant = btsD65;
			m_observer = btsCIE1964;
			btsGetColorDataFromSpectralData(m_sci, btsCIEXYZ, m_illuminant, m_observer, m_sciXyz);
		}
		else
		{
			m_illuminant = (btsStandardIlluminant)record.sci.user_data.illuminant;
			m_observer = (btsStandardObserver)record.sci.user_data.observer;
			m_sciXyz[0] = record.sci.user_data.values[0];
			m_sciXyz[1] = record.sci.user_data.values[1];
			m_sciXyz[2] = record.sci.user_data.values[2];
		}
	}

	if (HasSce())
	{
		if (HasSpectralData()) 
		{
			for (int i = 0; i < btsSPECTRAL_DATA_COUNT; ++i)
			{
				// ���������ݳ���10000������Ӧ�ķ�����
				m_sce[i] = record.sce.spectral_data[i] * 0.0001f;
			}

			m_illuminant = btsD65;
			m_observer = btsCIE1964;
			btsGetColorDataFromSpectralData(m_sce, btsCIEXYZ, m_illuminant, m_observer, m_sceXyz);
		}
		else
		{
			m_illuminant = (btsStandardIlluminant)record.sce.user_data.illuminant;
			m_observer = (btsStandardObserver)record.sce.user_data.observer;
			m_sceXyz[0] = record.sce.user_data.values[0];
			m_sceXyz[1] = record.sce.user_data.values[1];
			m_sceXyz[2] = record.sce.user_data.values[2];
		}
	}
}


Sample::Sample(btsStandardRecord standard)
	: m_isStandard(true)
	, m_tolerance(standard.tolerance)
	, m_standardId(0)
{
	SetData(standard);
}

Sample::Sample(btsTrialRecord test)
	: m_isStandard(false)
	, m_flags(test.flags)
	, m_standardId(test.standard_id)
{
	SetData(test);
}

Sample::~Sample()
{
}
