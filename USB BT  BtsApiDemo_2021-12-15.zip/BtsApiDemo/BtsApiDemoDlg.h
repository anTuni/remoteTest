﻿// BtsApiDemoDlg.h: 头文件
//

#pragma once
#include <memory>
#include "BtsApi.h"
#include "Sample.h"

// CBtsApiDemoDlg 对话框
class CBtsApiDemoDlg : public CDialogEx
{
	// 构造
public:
	CBtsApiDemoDlg(CWnd* pParent = nullptr); // 标准构造函数

	// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_BTSAPIDEMO_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX); // DDX/DDV 支持

	bool IsOpen() const { return m_instrument != NULL && m_instrument != INVALID_HANDLE_VALUE; }

	// 更新测量如果显示
	void UpdateResultList();
	// 上传指定标样记录关联的试样
	void UploadTests(int nItem);

	// 实现
protected:
	HICON m_hIcon;
	btsHandle m_instrument;	// 仪器句柄
	CListCtrl m_listDevInfo;	// 设备信息表
	CListCtrl m_listDevStatus;	// 设备状态表
	CListCtrl m_listMesResult;	// 测量如果表
	CListCtrl m_listStandards;	// 标样记录表
	CListCtrl m_listTests;		// 试样记录列表
	
	CMenu m_resultContextMenu;	// 测量结果列表上下文菜单
	CMenu m_standardContextMenu; // 标样列表上下文菜单
	CMenu m_testContextMenu;	// 试样列表上下文菜单
	CEdit m_editStdIndex;
	CSpinButtonCtrl m_spinStdIndex;

	int m_colorSpace;	 // 测量结果的色空间
	int m_illuminant;	 // 测量结果使用的光源
	int m_observer;		 // 测量结果使用的观察者
	int m_scMode;		 // 显示的是SCI还是SCE数据
	uint32_t m_curStdId; //  当前显示的试样列表关联的标样ID

	std::shared_ptr<Sample> m_standard; // 测量量的标样
	std::shared_ptr<Sample> m_test; // 试样

	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
DECLARE_MESSAGE_MAP()
public:
	// 连接或断开连接
	afx_msg void OnBnClickedConnect();
	// 获取设备信息
	afx_msg void OnBnClickedGetDevInfo();
	// 获取设备状态
	afx_msg void OnBnClickedGetDevStatus();
	// 黑校准
	afx_msg void OnBnClickedCalBlack();
	// 白校准
	afx_msg void OnBnClickedCalWhite();
	// 测量标样
	afx_msg void OnBnClickedMesStd();
	// 测量试样
	afx_msg void OnBnClickedMesTest();
	// 测量结果表右键菜单消息处理函数
	afx_msg void OnRclickListMesResult(NMHDR* pNMHDR, LRESULT* pResult);
	// 更新色空间菜单项状态
	afx_msg void OnUpdateColorSpaceMenuItem(CCmdUI* pCmdUi);
	afx_msg void OnUpdateIlluminantMenuItem(CCmdUI* pCmdUi);
	afx_msg void OnUpdateObserverMenuItem(CCmdUI* pCmdUi);
	// 切换测量如果显示的色空间
	afx_msg void OnColorSpaceMenuItemClick(UINT nId);
	// 切换测量如果显示的光源
	afx_msg void OnIlluminantMenuItemClick(UINT nId);
	// 更新测量如果显示的观察者
	afx_msg void OnObserverMenuItemClick(UINT nId);
	// 更新上下文菜单
	afx_msg void OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu);
	// 切换显示SCI数据
	afx_msg void OnScmodeSci();
	afx_msg void OnUpdateScmodeSci(CCmdUI* pCmdUI);
	// 切换显示SCE数据
	afx_msg void OnScmodeSce();
	afx_msg void OnUpdateScmodeSce(CCmdUI* pCmdUI);
	// 上传标样记录
	afx_msg void OnBnClickedUploadStandards();
	// 弹出标样列表上下文菜单
	afx_msg void OnRclickListStandards(NMHDR* pNMHDR, LRESULT* pResult);
	// 弹出试样列表上下文菜单
	afx_msg void OnRclickListTests(NMHDR* pNMHDR, LRESULT* pResult);
	// 标样记录双击事件，在双击时上传关联的试样
	afx_msg void OnNMDblclkListStandards(NMHDR* pNMHDR, LRESULT* pResult);
	// 上传标样关联的试样菜单响应
	afx_msg void OnStdUploadTests();
	afx_msg void OnUpdateStdUploadTests(CCmdUI* pCmdUI);
	// 从仪器删除所选标样记录
	afx_msg void OnStdDelSel();
	afx_msg void OnUpdateStdDelSel(CCmdUI* pCmdUI);
	// 从仪器删除所有标样
	afx_msg void OnStdDelAll();
	afx_msg void OnUpdateStdDelAll(CCmdUI* pCmdUI);
	// 清空标样列表
	afx_msg void OnStdClearList();
	afx_msg void OnUpdateStdClearList(CCmdUI* pCmdUI);
	// 清空试样列表
	afx_msg void OnTstClearList();
	afx_msg void OnUpdateTstClearList(CCmdUI* pCmdUI);
	// 从仪器删除当前试样列表中关联的标样下的所有试样
	afx_msg void OnTstDelAll();
	afx_msg void OnUpdateTstDelAll(CCmdUI* pCmdUI);
	// 从仪器删除所选试样
	afx_msg void OnTstDelSel();
	afx_msg void OnUpdateTstDelSel(CCmdUI* pCmdUI);
private:
	CComboBox m_uvModes;
public:
	afx_msg void OnBnClickedGetUvMode();
	afx_msg void OnBnClickedSetUvMode();
};
