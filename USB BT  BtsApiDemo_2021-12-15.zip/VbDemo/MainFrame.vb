﻿Imports BtsComm

Public Class MainForm
    Dim _instrument As Instrument = New Instrument()

    Dim _errorDescriptions As New Dictionary(Of ErrorCode, String) From
        {
        {ErrorCode.NoError, "没有错误"},
        {ErrorCode.DeviceNotFound, "找不到设备"},
        {ErrorCode.OpenDeviceFailed, "打开设备失败"},
        {ErrorCode.DeviceNotOpen, "未连接"},
        {ErrorCode.NoSession, "没有会话"},
        {ErrorCode.DeviceBusy, "设备忙"},
        {ErrorCode.SendTimeout, "发送超时"},
        {ErrorCode.RecvTimeout, "接收超时"},
        {ErrorCode.RemoteError, "执行命令发生错误"},
        {ErrorCode.DeviceError, "设备错误"},
        {ErrorCode.InvalidPacket, "无效数据包"},
        {ErrorCode.UnexpectCommand, "未知命令"},
        {ErrorCode.Uncalibrated, "未校准"},
        {ErrorCode.StorageIsFull, "存储区已满"},
        {ErrorCode.CalibrationFailed, "校准失败"},
        {ErrorCode.NotEnoughStorage, "仪器没有足够内存"},
        {ErrorCode.InvalidArgument, "无效参数"}
     }

    Dim _colorSpaceNames As New Dictionary(Of ColorSpace, String) From {
        {ColorSpace.CIELAB, "CIE L*a*b*" },
        {ColorSpace.CIEXYZ, "CIE XYZ" },
        {ColorSpace.CIEYxy, "CIE Yxy" },
        {ColorSpace.CIELCH, "CIE L*C*h°" },
        {ColorSpace.CIELUV, "CIE L*u*v*" },
        {ColorSpace.HUNTERLAB, "Hunter Lab" },
        {ColorSpace.BETA_XY, "βxy" },
        {ColorSpace.DIN_LAB99, "DIN99 Lab" },
        {ColorSpace.SRGB, "sRGB"},
        {ColorSpace.MUNSELL, "孟赛尔"}
    }

    Dim _colorSpaceItems As New Dictionary(Of ColorSpace, String()) From{
        {ColorSpace.CIELAB, {"L*", "a*", "b*"} },
        {ColorSpace.CIEXYZ, {"X", "Y", "Z"} },
        {ColorSpace.CIEYxy, {"Y", "x", "y"} },
        {ColorSpace.CIELCH, {"L*", "C*", "h°"} },
        {ColorSpace.CIELUV, {"L*", "u*", "v*"} },
        {ColorSpace.HUNTERLAB, {"L", "a", "b"} },
        {ColorSpace.BETA_XY, {"β", "x", "y"} },
        {ColorSpace.DIN_LAB99,{"L99", "a99", "b99"} },
        {ColorSpace.SRGB, {"R", "G", "B"} }
        }

    Dim _apertureNames As New Dictionary(Of Aperture, String) From{
        {Aperture.Phi4, "Φ4mm"},
        {Aperture.Phi8, "Φ8mm"},
        {Aperture.Phi15, "Φ15mm"},
        {Aperture.Phi25, "Φ25.4mm"}
        }

    Dim _lensPosNames As New Dictionary(Of LensPos, String) From{
        {LensPos.Pos4, "4mm"},
        {LensPos.Pos8, "8mm"},
        {LensPos.Pos15, "15mm"},
        {LensPos.Pos25, "25.4mm"}
        }

    Dim _uvNames As New Dictionary(Of UvMode, String) From{
        {UvMode.CutNone, "无截止"},
        {UvMode.Cut400, "400nm截止"},
        {UvMode.Cut420, "420nm截止"},
        {UvMode.Cut460, "460nm截止"}
        }

    Dim _observerNames As New Dictionary(Of StandardObserver, String) From{
        {StandardObserver.CIE1931, "2°(CIE 1931)"},
        {StandardObserver.CIE1964, "10°(CIE 1964)"}
        }

    Dim _diffFormulaNames As New Dictionary(Of ColorDiffFormula, String) From{
        {ColorDiffFormula.CIEDE, "CIE ΔE*(1976)"},    
        {ColorDiffFormula.CIEDE2000, "CIE ΔE*(2000)"},    
        {ColorDiffFormula.CIEDE94, "CIE ΔE*(1994)"},    
        {ColorDiffFormula.DECMC, "CMC(l:c)"},    
        {ColorDiffFormula.DECMC11, "CMC(1:1)"},    
        {ColorDiffFormula.DECMC21, "CMC(2:1)"},    
        {ColorDiffFormula.DEHUNTER, "Hunter ΔE"},    
        {ColorDiffFormula.DIN_E99, "DIN99 ΔE*"}   
        }

    Dim _colorIndexNames As New Dictionary(Of ColorIndex, String) From{
        {ColorIndex.COLOR_FASTNESS, "变色牢度"},
        {ColorIndex.GARDNER_INDEX, "加德纳指数"},
        {ColorIndex.GLOSS_8, "8度光泽度"},
        {ColorIndex.HUE_CLASSIFY_555, "555色调值"},
        {ColorIndex.METAMERISM_INDIEX, "同色异谱"},
        {ColorIndex.INVALID, "未设置"},
        {ColorIndex.OPACITY, "遮盖度"},
        {ColorIndex.PT_CO_INDEX, "钴铂指数"},
        {ColorIndex.STAINING_FASTNESS, "粘色牢度"},
        {ColorIndex.STRENGTH, "力份"}
        }

    Private Function ErrorMessage(err As ErrorCode) As String
        If _errorDescriptions.ContainsKey(err) Then
            Return _errorDescriptions(err)
        End If
        Return "未知错误"
    End Function

    Private Function GetLab(record As Record, scModel As ScMode) As Double()
        If (scModel = ScMode.SCI And record.Flags.ScMode = ScMode.SCE) Or
           (scModel = ScMode.SCE And record.Flags.ScMode = ScMode.SCI) Then
            Return Nothing
        End If

        Dim clr As ColorData = IIf(scModel = ScMode.SCI, record.Sci, record.Sce)

        If record.Flags.ColorDataType = ColorDataType.SpectalData Then
            ' 通过反射率数据计算Lab值
            Return Instrument.GetColorDataFromSpectralData(
                ColorSpace.CIELAB, clr.SpectralData, record.Flags.Illuminant, record.Flags.Observer)
        Else
            Return new Double() {clr.L, clr.A, clr.B}
        End If
    End Function

    Private Sub ButtonConnect_Click(sender As Object, e As EventArgs) Handles ButtonConnect.Click
        If _instrument.IsOpen Then
            _instrument.Close()
            ButtonConnect.Text = "连接"
        Else
            Dim err = _instrument.Open(String.Empty)
            If err = ErrorCode.NoError Then
                ButtonConnect.Text = "断开"
            Else
                MessageBox.Show(ErrorMessage(err))
            End If
        End If
    End Sub

    Private Sub ButtonGetDevInfo_Click(sender As Object, e As EventArgs) Handles ButtonGetDevInfo.Click
        Dim info As DeviceInfo
        Dim err = _instrument.GetDeviceInfo(info)
        If err <> ErrorCode.NoError Then
            MessageBox.Show(ErrorMessage(err))
        Else
            DevInfoListView.Items(0).SubItems(1).Text = info.Model
            DevInfoListView.Items(1).SubItems(1).Text = info.Sn
            DevInfoListView.Items(2).SubItems(1).Text = info.HardwareVersion
            DevInfoListView.Items(3).SubItems(1).Text = info.SoftwareVersion
            DevInfoListView.Items(4).SubItems(1).Text = info.Optical
            DevInfoListView.Items(5).SubItems(1).Text = info.WhiteBoardNumber
        End If
    End Sub

    Private Sub ButtonGetDevStatus_Click(sender As Object, e As EventArgs) Handles ButtonGetDevStatus.Click
        Dim status As InstrumentStatus
        Dim err = _instrument.GetInstrumentStatus(status)
        If err <> ErrorCode.NoError Then
            MessageBox.Show(ErrorMessage((err)))
        Else
            DevStatusListView.Items(0).SubItems(1).Text = _apertureNames(status.Aperture)
            DevStatusListView.Items(1).SubItems(1).Text = _lensPosNames(status.LensPos)
            DevStatusListView.Items(2).SubItems(1).Text = status.ScMode.ToString()
            DevStatusListView.Items(3).SubItems(1).Text = IIf(status.IsTransitive, "透射", "反射")
            DevStatusListView.Items(4).SubItems(1).Text = _uvNames(status.UvMode)
            DevStatusListView.Items(5).SubItems(1).Text = IIf(status.LensSwitchMode = LensSwitchMode.Auto, "自动", "手动")
            DevStatusListView.Items(6).SubItems(1).Text = _observerNames(status.Observer)
            DevStatusListView.Items(7).SubItems(1).Text = status.Illuminant.ToString()
            DevStatusListView.Items(8).SubItems(1).Text = _colorSpaceNames(status.ColorSpace)
            DevStatusListView.Items(9).SubItems(1).Text = _diffFormulaNames(status.ColorDiffFormula)
            DevStatusListView.Items(10).SubItems(1).Text = _colorIndexNames(status.ColorIndex)
            DevStatusListView.Items(11).SubItems(1).Text = status.StandardCount
            DevStatusListView.Items(12).SubItems(1).Text = status.TrialCount
            DevStatusListView.Items(13).SubItems(1).Text = IIf(status.IsCalibrated, "已校准", "未校准")
        End If
    End Sub

    Private Sub MainForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' 初始化标样和试样列表
        Dim labels As New List(Of String) From {
                "ID", "名称", "日期", "光谱类型", "光源", "观察者", "L*", "a*", "b*"
                }
        For wavelength = Instrument.WaveLengthMin To Instrument.WaveLengthMax Step Instrument.WaveLengthInterval
            labels.Add($"{wavelength}nm")
        Next

        For Each label in labels
            ListViewStandards.Columns.Add(label)
            ListViewTrialRecords.Columns.Add(label)
            ListViewMeasurement.Columns.Add(label)
        Next

        ScMode = ScMode.SCI
    End Sub

    Private Sub ButtonUploadStandards_Click(sender As Object, e As EventArgs) Handles ButtonUploadStandards.Click 
        ListViewStandards.Items.Clear()
        ListViewTrialRecords.Items.Clear()

        Dim count As Integer
        ' 获取标样数
        Dim err = _instrument.GetTotalStandards(count)
        If err <> ErrorCode.NoError Then
            MessageBox.Show(ErrorMessage(err))
            Return
        ElseIf count = 0 Then
            MessageBox.Show("仪器中没有标样记录")
            Return
        End If

        Dim savedCursor = Cursor
        Cursor = Cursors.WaitCursor

        Dim records() As StandardRecord
        ' 上传标样
        err = _instrument.UploadStandards(records, 0, count)
        If err <> ErrorCode.NoError Then
            MessageBox.Show(ErrorMessage(err))
            Cursor = savedCursor
            Return
        End If

        For Each record In records
            Dim item = new ListViewItem()
            item.Tag = record
            FillRecordData(item, record)
            ListViewStandards.Items.Add(item)
        Next
        Cursor = savedCursor
    End Sub

    Private Sub FillRecordData(item As ListViewItem, record As Record)
        item.Text = record.Id.ToString()
        item.SubItems.AddRange({ _
                                   record.Name,
                                   record.DateTime.ToString(),
                                   IIf(record.Flags.IsTransitive, "透射", "反射"),
                                   record.Flags.Illuminant.ToString(),
                                   _observerNames(record.Flags.Observer)
                               })
        Dim lab = GetLab(record, ScMode)

        ' 如果没有相应ScMode的数据
        If IsNothing(lab) Then Return

        item.SubItems.AddRange({ _
                                   lab(0).ToString("F2"),
                                   lab(1).ToString("F2"),
                                   lab(2).ToString("F2")})
        If record.Flags.ColorDataType = ColorDataType.SpectalData Then
            Dim spectralData As Double() = IIf(ScMode = ScMode.SCI,
                                               record.Sci.SpectralData,
                                               record.Sce.SpectralData)
            item.SubItems.AddRange((From x In spectralData Select (x*100.0).ToString("F2")).ToArray())
        End If
    End Sub

    Private Sub ComboBoxScMode_SelectedIndexChanged(sender As Object, e As EventArgs) _
        Handles ComboBoxScMode.SelectedIndexChanged
        For Each item As ListViewItem In ListViewStandards.Items
            Dim record As StandardRecord = item.Tag
            item.SubItems.Clear()
            FillRecordData(item, record)
        Next

        For Each item As ListViewItem In ListViewTrialRecords.Items
            Dim record As TrialRecord = item.Tag
            item.SubItems.Clear()
            FillRecordData(item, record)
        Next
    End Sub

    Private Property ScMode() As ScMode
        Get
            Return IIf(ComboBoxScMode.SelectedIndex = 0, ScMode.SCI, ScMode.SCE)
        End Get
        Set(value As ScMode)
            If value = ScMode.SCI Then
                ComboBoxScMode.SelectedIndex = 0
            Else
                ComboBoxScMode.SelectedIndex = 1
            End If
        End Set
    End Property

    Private Sub ButtonUploadTrialRecords_Click(sender As Object, e As EventArgs) Handles ButtonUploadTrialRecords.Click 
        ListViewTrialRecords.Items.Clear()

        If ListViewStandards.SelectedItems.Count = 0 Then
            MessageBox.Show("请选择一个标样")
            Return
        End If

        Dim standardRecord As StandardRecord = ListViewStandards.SelectedItems(0).Tag
        Dim count As UInteger
        ' 获取试样个数
        Dim err = _instrument.GetSampleCount(standardRecord.Id, count)
        If err <> ErrorCode.NoError Then
            MessageBox.Show(ErrorMessage(err))
            Return
        ElseIf count = 0 Then
            MessageBox.Show("没有关联的试样")
            Return
        End If

        Dim savedCursor = Cursor
        Cursor = Cursors.WaitCursor

        Dim records As TrialRecord()
        ' 上传试样
        err = _instrument.UploadSamples(records, standardRecord.Id, 0, count)
        If err <> ErrorCode.NoError Then
            MessageBox.Show(ErrorMessage(err))
            Cursor = savedCursor
            Return
        End If

        For Each record As TrialRecord In records
            Dim item = New ListViewItem()
            FillRecordData(item, record)
            ListViewTrialRecords.Items.Add(item)
        Next
    End Sub

    Private Sub ButtonCalibrateBlack_Click(sender As Object, e As EventArgs) Handles ButtonCalibrateBlack.Click
        ' 选获取状态，根据透射或反射模式提显示不同提示语
        Dim status As InstrumentStatus
        Dim err = _instrument.GetInstrumentStatus(status)
        If err <> ErrorCode.NoError
            MessageBox.Show(ErrorMessage(err))
            Return
        End If

        Dim result = MessageBox.Show(
            IIf(status.IsTransitive,
                "请在反射测量口放置白板，并在透射测量口放置黑板",
                "请在反射测量口放置黑桶，并将透射仓清空"),
            "黑校准", MessageBoxButtons.OKCancel)
        If result = DialogResult.Cancel Then Return

        Dim savedCursor = Cursor
        Cursor = Cursors.WaitCursor

        err = _instrument.CalibrateBlack()

        Cursor = savedCursor

        If err = ErrorCode.NoError Then
            MessageBox.Show("黑校准完成")
        Else 
            MessageBox.Show("黑校准失败：" + ErrorMessage(err))
        End If
    End Sub

    Private Sub ButtonCalibrateWhite_Click(sender As Object, e As EventArgs) Handles ButtonCalibrateWhite.Click
        ' 选获取状态，根据透射或反射模式提显示不同提示语
        Dim status As InstrumentStatus
        Dim err = _instrument.GetInstrumentStatus(status)
        If err <> ErrorCode.NoError
            MessageBox.Show(ErrorMessage(err))
            Return
        End If

        Dim result = MessageBox.Show(
            IIf(status.IsTransitive,
                "请在反射测量口放置白板，并在透射测量口放置空容器或置空",
                "请在反射测量口放置白板，并将透射仓清空"),
            "白校准", MessageBoxButtons.OKCancel)
        If result = DialogResult.Cancel Then Return

        Dim savedCursor = Cursor
        Cursor = Cursors.WaitCursor

        err = _instrument.CalibrateWhite()

        Cursor = savedCursor

        If err = ErrorCode.NoError Then
            MessageBox.Show("白校准完成")
        Else 
            MessageBox.Show("白校准失败：" + ErrorMessage(err))
        End If
    End Sub

    Private Sub ButtonMeasureStandard_Click(sender As Object, e As EventArgs) Handles ButtonMeasureStandard.Click
        ListViewMeasurement.Items.Clear()

        Dim record As StandardRecord
        Dim err = _instrument.MeasureStandard(record)
        If err <> ErrorCode.NoError Then
            MessageBox.Show(ErrorMessage(err))
            Return
        End If

        record.Name = "标样"
        Dim item = New ListViewItem()
        FillRecordData(item, record)
        ListViewMeasurement.Items.Add(item)
    End Sub

    Private Sub ButtonMeasureTrial_Click(sender As Object, e As EventArgs) Handles ButtonMeasureTrial.Click
        Dim record As TrialRecord
        Dim err = _instrument.MeasureTrial(record)
        If err <> ErrorCode.NoError Then
            MessageBox.Show(ErrorMessage(err))
            Return
        End If

        record.Name = "试样"
        Dim item = New ListViewItem()
        FillRecordData(item, record)
        ListViewMeasurement.Items.Add(item)
    End Sub
End Class
