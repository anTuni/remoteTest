﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。  
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim ListViewItem21 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"仪器型号", "", ""}, -1)
        Dim ListViewItem22 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"仪器编号", "", ""}, -1)
        Dim ListViewItem23 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"硬件版本", "", ""}, -1)
        Dim ListViewItem24 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"软件版本", "", ""}, -1)
        Dim ListViewItem25 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"光学结构", "", ""}, -1)
        Dim ListViewItem26 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"白板编号", "", ""}, -1)
        Dim ListViewItem27 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"测量口径", "", ""}, -1)
        Dim ListViewItem28 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"透镜位置", "", ""}, -1)
        Dim ListViewItem29 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"SCI/SCE", "", ""}, -1)
        Dim ListViewItem30 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"反射/透射", "", ""}, -1)
        Dim ListViewItem31 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"UV模式", "", ""}, -1)
        Dim ListViewItem32 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"透镜切换模式", "", ""}, -1)
        Dim ListViewItem33 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"观察者", "", ""}, -1)
        Dim ListViewItem34 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"光源", "", ""}, -1)
        Dim ListViewItem35 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"颜色空间", "", ""}, -1)
        Dim ListViewItem36 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"色差公式", "", ""}, -1)
        Dim ListViewItem37 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"颜色指数", "", ""}, -1)
        Dim ListViewItem38 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"标样总数", "", ""}, -1)
        Dim ListViewItem39 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"试样总数", "", ""}, -1)
        Dim ListViewItem40 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"校准状态", "", ""}, -1)
        Me.ButtonConnect = New System.Windows.Forms.Button()
        Me.ButtonGetDevInfo = New System.Windows.Forms.Button()
        Me.ButtonGetDevStatus = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.DevInfoListView = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.DevStatusListView = New System.Windows.Forms.ListView()
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.ListViewStandards = New System.Windows.Forms.ListView()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.ListViewTrialRecords = New System.Windows.Forms.ListView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ComboBoxScMode = New System.Windows.Forms.ComboBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.ListViewMeasurement = New System.Windows.Forms.ListView()
        Me.ButtonMeasureTrial = New System.Windows.Forms.Button()
        Me.ButtonMeasureStandard = New System.Windows.Forms.Button()
        Me.ButtonCalibrateBlack = New System.Windows.Forms.Button()
        Me.ButtonCalibrateWhite = New System.Windows.Forms.Button()
        Me.ButtonUploadTrialRecords = New System.Windows.Forms.Button()
        Me.ButtonUploadStandards = New System.Windows.Forms.Button()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.FlowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.GroupBox1.SuspendLayout
        Me.GroupBox2.SuspendLayout
        Me.GroupBox3.SuspendLayout
        Me.GroupBox4.SuspendLayout
        Me.GroupBox5.SuspendLayout
        Me.FlowLayoutPanel1.SuspendLayout
        Me.FlowLayoutPanel2.SuspendLayout
        Me.TableLayoutPanel1.SuspendLayout
        Me.TableLayoutPanel2.SuspendLayout
        Me.SuspendLayout
        '
        'ButtonConnect
        '
        Me.ButtonConnect.Location = New System.Drawing.Point(3, 3)
        Me.ButtonConnect.Name = "ButtonConnect"
        Me.ButtonConnect.Size = New System.Drawing.Size(75, 23)
        Me.ButtonConnect.TabIndex = 0
        Me.ButtonConnect.Text = "连接"
        Me.ButtonConnect.UseVisualStyleBackColor = true
        '
        'ButtonGetDevInfo
        '
        Me.ButtonGetDevInfo.Location = New System.Drawing.Point(84, 3)
        Me.ButtonGetDevInfo.Name = "ButtonGetDevInfo"
        Me.ButtonGetDevInfo.Size = New System.Drawing.Size(90, 23)
        Me.ButtonGetDevInfo.TabIndex = 1
        Me.ButtonGetDevInfo.Text = "获取仪器信息"
        Me.ButtonGetDevInfo.UseVisualStyleBackColor = true
        '
        'ButtonGetDevStatus
        '
        Me.ButtonGetDevStatus.Location = New System.Drawing.Point(180, 3)
        Me.ButtonGetDevStatus.Name = "ButtonGetDevStatus"
        Me.ButtonGetDevStatus.Size = New System.Drawing.Size(75, 23)
        Me.ButtonGetDevStatus.TabIndex = 2
        Me.ButtonGetDevStatus.Text = "获取仪器状态"
        Me.ButtonGetDevStatus.UseVisualStyleBackColor = true
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.DevInfoListView)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Location = New System.Drawing.Point(3, 45)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(281, 154)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = false
        Me.GroupBox1.Text = "仪器信息"
        '
        'DevInfoListView
        '
        Me.DevInfoListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2})
        Me.DevInfoListView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DevInfoListView.Items.AddRange(New System.Windows.Forms.ListViewItem() {ListViewItem21, ListViewItem22, ListViewItem23, ListViewItem24, ListViewItem25, ListViewItem26})
        Me.DevInfoListView.Location = New System.Drawing.Point(3, 17)
        Me.DevInfoListView.Name = "DevInfoListView"
        Me.DevInfoListView.Size = New System.Drawing.Size(275, 134)
        Me.DevInfoListView.TabIndex = 0
        Me.DevInfoListView.UseCompatibleStateImageBehavior = false
        Me.DevInfoListView.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "项"
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "值"
        Me.ColumnHeader2.Width = 150
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.DevStatusListView)
        Me.GroupBox2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox2.Location = New System.Drawing.Point(3, 205)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(281, 398)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = false
        Me.GroupBox2.Text = "仪器状态"
        '
        'DevStatusListView
        '
        Me.DevStatusListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader3, Me.ColumnHeader4})
        Me.DevStatusListView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DevStatusListView.Items.AddRange(New System.Windows.Forms.ListViewItem() {ListViewItem27, ListViewItem28, ListViewItem29, ListViewItem30, ListViewItem31, ListViewItem32, ListViewItem33, ListViewItem34, ListViewItem35, ListViewItem36, ListViewItem37, ListViewItem38, ListViewItem39, ListViewItem40})
        Me.DevStatusListView.Location = New System.Drawing.Point(3, 17)
        Me.DevStatusListView.Name = "DevStatusListView"
        Me.DevStatusListView.Size = New System.Drawing.Size(275, 378)
        Me.DevStatusListView.TabIndex = 0
        Me.DevStatusListView.UseCompatibleStateImageBehavior = false
        Me.DevStatusListView.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "项"
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "值"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.ListViewStandards)
        Me.GroupBox3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox3.Location = New System.Drawing.Point(290, 45)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(757, 154)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = false
        Me.GroupBox3.Text = "标样记录"
        '
        'ListViewStandards
        '
        Me.ListViewStandards.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListViewStandards.FullRowSelect = true
        Me.ListViewStandards.Location = New System.Drawing.Point(3, 17)
        Me.ListViewStandards.MultiSelect = false
        Me.ListViewStandards.Name = "ListViewStandards"
        Me.ListViewStandards.Size = New System.Drawing.Size(751, 134)
        Me.ListViewStandards.TabIndex = 0
        Me.ListViewStandards.UseCompatibleStateImageBehavior = false
        Me.ListViewStandards.View = System.Windows.Forms.View.Details
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.ListViewTrialRecords)
        Me.GroupBox4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox4.Location = New System.Drawing.Point(290, 205)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(757, 398)
        Me.GroupBox4.TabIndex = 4
        Me.GroupBox4.TabStop = false
        Me.GroupBox4.Text = "试样记录"
        '
        'ListViewTrialRecords
        '
        Me.ListViewTrialRecords.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListViewTrialRecords.FullRowSelect = true
        Me.ListViewTrialRecords.Location = New System.Drawing.Point(3, 17)
        Me.ListViewTrialRecords.Name = "ListViewTrialRecords"
        Me.ListViewTrialRecords.Size = New System.Drawing.Size(751, 378)
        Me.ListViewTrialRecords.TabIndex = 0
        Me.ListViewTrialRecords.UseCompatibleStateImageBehavior = false
        Me.ListViewTrialRecords.View = System.Windows.Forms.View.Details
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label1.AutoSize = true
        Me.Label1.Location = New System.Drawing.Point(223, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 12)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "SC模式"
        '
        'ComboBoxScMode
        '
        Me.ComboBoxScMode.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ComboBoxScMode.FormattingEnabled = true
        Me.ComboBoxScMode.Items.AddRange(New Object() {"SCI", "SCE"})
        Me.ComboBoxScMode.Location = New System.Drawing.Point(270, 4)
        Me.ComboBoxScMode.Name = "ComboBoxScMode"
        Me.ComboBoxScMode.Size = New System.Drawing.Size(121, 20)
        Me.ComboBoxScMode.TabIndex = 7
        Me.ComboBoxScMode.Text = "SCI"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.ListViewMeasurement)
        Me.GroupBox5.Controls.Add(Me.ButtonMeasureTrial)
        Me.GroupBox5.Controls.Add(Me.ButtonMeasureStandard)
        Me.GroupBox5.Controls.Add(Me.ButtonCalibrateBlack)
        Me.GroupBox5.Controls.Add(Me.ButtonCalibrateWhite)
        Me.GroupBox5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox5.Location = New System.Drawing.Point(3, 615)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(1050, 151)
        Me.GroupBox5.TabIndex = 8
        Me.GroupBox5.TabStop = false
        Me.GroupBox5.Text = "测量功能"
        '
        'ListViewMeasurement
        '
        Me.ListViewMeasurement.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom)  _
            Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.ListViewMeasurement.Location = New System.Drawing.Point(96, 20)
        Me.ListViewMeasurement.Name = "ListViewMeasurement"
        Me.ListViewMeasurement.Size = New System.Drawing.Size(948, 116)
        Me.ListViewMeasurement.TabIndex = 4
        Me.ListViewMeasurement.UseCompatibleStateImageBehavior = false
        Me.ListViewMeasurement.View = System.Windows.Forms.View.Details
        '
        'ButtonMeasureTrial
        '
        Me.ButtonMeasureTrial.Location = New System.Drawing.Point(7, 113)
        Me.ButtonMeasureTrial.Name = "ButtonMeasureTrial"
        Me.ButtonMeasureTrial.Size = New System.Drawing.Size(75, 23)
        Me.ButtonMeasureTrial.TabIndex = 3
        Me.ButtonMeasureTrial.Text = "测量试样"
        Me.ButtonMeasureTrial.UseVisualStyleBackColor = true
        '
        'ButtonMeasureStandard
        '
        Me.ButtonMeasureStandard.Location = New System.Drawing.Point(8, 81)
        Me.ButtonMeasureStandard.Name = "ButtonMeasureStandard"
        Me.ButtonMeasureStandard.Size = New System.Drawing.Size(75, 23)
        Me.ButtonMeasureStandard.TabIndex = 2
        Me.ButtonMeasureStandard.Text = "测量标样"
        Me.ButtonMeasureStandard.UseVisualStyleBackColor = true
        '
        'ButtonCalibrateBlack
        '
        Me.ButtonCalibrateBlack.Location = New System.Drawing.Point(8, 20)
        Me.ButtonCalibrateBlack.Name = "ButtonCalibrateBlack"
        Me.ButtonCalibrateBlack.Size = New System.Drawing.Size(75, 23)
        Me.ButtonCalibrateBlack.TabIndex = 1
        Me.ButtonCalibrateBlack.Text = "黑校准"
        Me.ButtonCalibrateBlack.UseVisualStyleBackColor = true
        '
        'ButtonCalibrateWhite
        '
        Me.ButtonCalibrateWhite.Location = New System.Drawing.Point(8, 52)
        Me.ButtonCalibrateWhite.Name = "ButtonCalibrateWhite"
        Me.ButtonCalibrateWhite.Size = New System.Drawing.Size(75, 23)
        Me.ButtonCalibrateWhite.TabIndex = 0
        Me.ButtonCalibrateWhite.Text = "白校准"
        Me.ButtonCalibrateWhite.UseVisualStyleBackColor = true
        '
        'ButtonUploadTrialRecords
        '
        Me.ButtonUploadTrialRecords.Location = New System.Drawing.Point(84, 3)
        Me.ButtonUploadTrialRecords.Name = "ButtonUploadTrialRecords"
        Me.ButtonUploadTrialRecords.Size = New System.Drawing.Size(133, 23)
        Me.ButtonUploadTrialRecords.TabIndex = 5
        Me.ButtonUploadTrialRecords.Text = "上传所选标样的试样"
        Me.ButtonUploadTrialRecords.UseVisualStyleBackColor = true
        '
        'ButtonUploadStandards
        '
        Me.ButtonUploadStandards.Location = New System.Drawing.Point(3, 3)
        Me.ButtonUploadStandards.Name = "ButtonUploadStandards"
        Me.ButtonUploadStandards.Size = New System.Drawing.Size(75, 23)
        Me.ButtonUploadStandards.TabIndex = 5
        Me.ButtonUploadStandards.Text = "上传所有标样"
        Me.ButtonUploadStandards.UseVisualStyleBackColor = true
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Controls.Add(Me.ButtonConnect)
        Me.FlowLayoutPanel1.Controls.Add(Me.ButtonGetDevInfo)
        Me.FlowLayoutPanel1.Controls.Add(Me.ButtonGetDevStatus)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(3, 3)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(275, 36)
        Me.FlowLayoutPanel1.TabIndex = 9
        '
        'FlowLayoutPanel2
        '
        Me.FlowLayoutPanel2.AutoSize = true
        Me.FlowLayoutPanel2.Controls.Add(Me.ButtonUploadStandards)
        Me.FlowLayoutPanel2.Controls.Add(Me.ButtonUploadTrialRecords)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label1)
        Me.FlowLayoutPanel2.Controls.Add(Me.ComboBoxScMode)
        Me.FlowLayoutPanel2.Location = New System.Drawing.Point(290, 3)
        Me.FlowLayoutPanel2.Name = "FlowLayoutPanel2"
        Me.FlowLayoutPanel2.Size = New System.Drawing.Size(394, 29)
        Me.FlowLayoutPanel2.TabIndex = 11
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100!))
        Me.TableLayoutPanel1.Controls.Add(Me.FlowLayoutPanel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.FlowLayoutPanel2, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.GroupBox4, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.GroupBox1, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.GroupBox2, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.GroupBox3, 1, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 160!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1050, 606)
        Me.TableLayoutPanel1.TabIndex = 12
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 1
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100!))
        Me.TableLayoutPanel2.Controls.Add(Me.TableLayoutPanel1, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.GroupBox5, 0, 1)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 2
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(1056, 769)
        Me.TableLayoutPanel2.TabIndex = 13
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6!, 12!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1056, 769)
        Me.Controls.Add(Me.TableLayoutPanel2)
        Me.Name = "MainForm"
        Me.Text = "BTS示例程序"
        Me.GroupBox1.ResumeLayout(false)
        Me.GroupBox2.ResumeLayout(false)
        Me.GroupBox3.ResumeLayout(false)
        Me.GroupBox4.ResumeLayout(false)
        Me.GroupBox5.ResumeLayout(false)
        Me.FlowLayoutPanel1.ResumeLayout(false)
        Me.FlowLayoutPanel2.ResumeLayout(false)
        Me.FlowLayoutPanel2.PerformLayout
        Me.TableLayoutPanel1.ResumeLayout(false)
        Me.TableLayoutPanel1.PerformLayout
        Me.TableLayoutPanel2.ResumeLayout(false)
        Me.ResumeLayout(false)

End Sub

    Friend WithEvents ButtonConnect As Button
    Friend WithEvents ButtonGetDevInfo As Button
    Friend WithEvents ButtonGetDevStatus As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents DevInfoListView As ListView
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents DevStatusListView As ListView
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents ListViewStandards As ListView
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents ListViewTrialRecords As ListView
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents ColumnHeader3 As ColumnHeader
    Friend WithEvents ColumnHeader4 As ColumnHeader
    Friend WithEvents Label1 As Label
    Friend WithEvents ComboBoxScMode As ComboBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents ButtonMeasureTrial As Button
    Friend WithEvents ButtonMeasureStandard As Button
    Friend WithEvents ButtonCalibrateBlack As Button
    Friend WithEvents ButtonCalibrateWhite As Button
    Friend WithEvents ListViewMeasurement As ListView
    Friend WithEvents ButtonUploadTrialRecords As Button
    Friend WithEvents ButtonUploadStandards As Button
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents FlowLayoutPanel2 As FlowLayoutPanel
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
End Class
