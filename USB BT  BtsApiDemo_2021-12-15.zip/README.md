#FILES

- `BtsApiDemo\`: 	VC DEMO
- `BtsCommDemo\`: 	C# DEMO
- `include\`:		include fide for BtsApi.dll
- `Library\`:		dynamical library files
- `Library\x86`: 	for 32bits OS
- `Library\x64`: 	for 64bits OS
- `VirtualComPortDriver\`:	virtual communication port deriver

`BtsApi.dll` is for C language, ande `BtsComm.dll` is for .Net.
