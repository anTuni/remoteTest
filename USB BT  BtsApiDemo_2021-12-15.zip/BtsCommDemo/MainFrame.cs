﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Resources;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using BtsComm;
using BtsCommDemo.Properties;

namespace BtsCommDemo
{
    public partial class MainFrame : Form
    {
        static readonly  Dictionary<ColorSpace, string[]> ColorSpaceItems = new Dictionary<ColorSpace, string[]>
        {
            {ColorSpace.CIELAB, new []{"L*", "a*", "b*" } },
            {ColorSpace.CIEXYZ, new []{"X", "Y", "Z" } },
            {ColorSpace.CIEYxy, new []{"Y", "x", "y" } },
            {ColorSpace.CIELCH, new []{"L*", "C*", "h°" } },
            {ColorSpace.CIELUV, new []{"L*", "u*", "v*" } },
            {ColorSpace.HUNTERLAB, new []{"L", "a", "b" } },
            {ColorSpace.BETA_XY, new []{"β", "x", "y" } },
            {ColorSpace.DIN_LAB99, new []{"L99", "a99", "b99" } },
            {ColorSpace.SRGB, new []{"R", "G", "B" } },
        };

        Instrument instrument = new Instrument();

        private StandardRecord standard = null;
        private TrialRecord trial = null;
        private StandardIlluminant standardIlluminant = StandardIlluminant.D65;
        private StandardObserver standardObserver = StandardObserver.CIE1964;
        private ScMode scMode = ScMode.SCI;
        private ColorSpace colorSpace = ColorSpace.CIELAB;


        public MainFrame()
        {


            InitializeComponent();

            // 初始化标样和试样列表

            var labels = new[]
            {
                Resources.Id,
                Resources.Name,
                Resources.DateTime,
                Resources.SpectralType,
                Resources.Illuminant,
                Resources.Observer,
                Resources.LAsterisk,
                Resources.AAsterisk,
                Resources.BAsterisk
            };
            foreach (var label in labels)
            {
                standardsListView.Columns.Add(label);
                samplesListView.Columns.Add(label);
            }
            for (int wavelength = Instrument.WaveLengthMin; 
                wavelength <= Instrument.WaveLengthMax;
                wavelength += Instrument.WaveLengthInterval)
            {
                standardsListView.Columns.Add($"{wavelength}nm");
                samplesListView.Columns.Add($"{wavelength}nm");
            }


            // 初始化测量列表上下文菜单
            measureResultListContextMenuStrip.Items.Add(
                new ToolStripRadioButtonMenuItem(_(ScMode.SCI), scModeClicked, group: "ScMode") {Tag = ScMode.SCI, Checked = true});
            measureResultListContextMenuStrip.Items.Add(
                new ToolStripRadioButtonMenuItem(_(ScMode.SCE), group: "ScMode") {Tag = ScMode.SCE});

            foreach (var value in Enum.GetValues(typeof(StandardIlluminant)))
            {
                var item = new ToolStripRadioButtonMenuItem(
                    Enum.GetName(typeof(StandardIlluminant), value),
                    illuminantClicked, "StandardIlluminant") {Tag = value};
                if ((StandardIlluminant) value == standardIlluminant)
                    item.Checked = true;
                standardIlluminantToolStripMenuItem.DropDownItems.Add(item);
            }
            foreach (var value in Enum.GetValues(typeof(StandardObserver)))
            {
                var item = new ToolStripRadioButtonMenuItem(
                    _(Enum.GetName(typeof(StandardObserver), value)),
                    observerClicked, "StandardObserver") {Tag = value};
                if ((StandardObserver) value == standardObserver)
                {
                    item.Checked = true;
                }
                standardObserverToolStripMenuItem.DropDownItems.Add(item);
            }

            foreach (var value in Enum.GetValues(typeof(ColorSpace)))
            {
                // Not supported Munsell
                if ((ColorSpace)value == ColorSpace.MUNSELL)
                    continue;
                var item = new ToolStripRadioButtonMenuItem(
                    _(Enum.GetName(typeof(ColorSpace), value)),
                    onColorSpaceClicked, "ColorSpace") {Tag=value};
                if ((ColorSpace) item.Tag == colorSpace)
                {
                    item.Checked = true;
                }
                colorSpaceToolStripMenuItem.DropDownItems.Add(item);
            }

            foreach (var label in new [] {"Item", "Standard", "Sample", "Difference"})
            {
                measureResultListView.Columns.Add(_(label));
            }

            connectionMethods.Items.Add(Resources.ConnectWithUSB);
            connectionMethods.Items.Add(Resources.ConnectWithBluetooth);
            connectionMethods.SelectedIndex = 0;
        }


        string _(string key)
        {
            return Resources.ResourceManager.GetString(key);
        }

        string _(Enum enumItem)
        {
            return _(enumItem.ToString());
        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            if (instrument.IsOpen)
            {
                instrument.Close();
                buttonConnect.Text = Resources.Connect;
            }
            else
            {
                ErrorCode error;
                var method = connectionMethods.SelectedItem as string;
                if (method == Resources.ConnectWithUSB) { 
                    // 通过USB连接
                    error = instrument.Open(null);
                } 
                else
                {
                    // 自动查找蓝牙设备并连接
                    //error = instrument.OpenByBleDongle(null, null);
                    var dlg = new BleSlavesSelectionDlg();
                    if (dlg.ShowDialog(this) != DialogResult.OK)
                    {
                        return;
                    }
                    error = instrument.OpenByBleDongle(dlg.SelectedPortName, dlg.SelectedSlaveMac);
                }

                if (error == ErrorCode.NoError)
                {
                    buttonConnect.Text = Resources.Disconnect;
                    standardIndeicesComboBox.Items.Clear();
                    standardsListView.Items.Clear();
                    buttonUploadStandard.Enabled = false;
                }
                else
                {
                    MessageBox.Show(_(error.ToString()));
                }
            }
        }

        private void buttonGetDevInfo_Click(object sender, EventArgs e)
        {
            DeviceInfo info;
            var error = instrument.GetDeviceInfo(out info);
            if (error != ErrorCode.NoError)
            {
                MessageBox.Show(_(error.ToString()));
                return;
            }

            devInfoListView.Items[0].SubItems[1].Text = info.Model;
            devInfoListView.Items[1].SubItems[1].Text = info.Sn;
            devInfoListView.Items[2].SubItems[1].Text = info.Optical;
            devInfoListView.Items[3].SubItems[1].Text = info.SoftwareVersion;
            devInfoListView.Items[4].SubItems[1].Text = info.HardwareVersion;
            devInfoListView.Items[5].SubItems[1].Text = info.WhiteBoardNumber;
        }

        private void buttonGetStatus_Click(object sender, EventArgs e)
        {
            InstrumentStatus status;
            var error = instrument.GetInstrumentStatus(out status);
            if (error == ErrorCode.NoError)
            {
                instrumentStatusListView.Items[0].SubItems[1].Text =  _(status.Aperture.ToString());
                instrumentStatusListView.Items[1].SubItems[1].Text =  _(status.LensPosition.ToString());
                instrumentStatusListView.Items[2].SubItems[1].Text =  _(status.ScMode.ToString());
                instrumentStatusListView.Items[3].SubItems[1].Text =  _(status.IsTransitive ? "Transitive" : "Reflective");
                instrumentStatusListView.Items[4].SubItems[1].Text =  _(status.UvMode.ToString());
                instrumentStatusListView.Items[5].SubItems[1].Text =  _(status.LensSwitchMode.ToString());
                instrumentStatusListView.Items[6].SubItems[1].Text =  _(status.Observer.ToString());
                instrumentStatusListView.Items[7].SubItems[1].Text =  status.Illuminant.ToString();
                instrumentStatusListView.Items[8].SubItems[1].Text =  _(status.ColorSpace.ToString());
                instrumentStatusListView.Items[9].SubItems[1].Text =  _(status.ColorDiffFormula.ToString());
                instrumentStatusListView.Items[10].SubItems[1].Text =  _(status.ColorIndex.ToString());
                instrumentStatusListView.Items[11].SubItems[1].Text =  status.StandardCount.ToString();
                instrumentStatusListView.Items[12].SubItems[1].Text =  status.TrialCount.ToString();
            }
            else
            {
                MessageBox.Show(_(error.ToString()));
                return;
            }


        }

        private void standardIndeicesComboBox_DropDown(object sender, EventArgs e)
        {
            if (standardIndeicesComboBox.Items.Count == 0)
            {
                uint total;
                var error = instrument.GetTotalStandards(out total);
                if (error != ErrorCode.NoError)
                {
                    MessageBox.Show(_(error.ToString()));
                    return;
                }

                if (total > 0)
                {
                    standardIndeicesComboBox.Items.Add(-1);
                    for (int i = 0; i < total; i++)
                        standardIndeicesComboBox.Items.Add(i);
                    buttonUploadStandard.Enabled = true;
                }
            }
        }

        private void buttonUploadStandard_Click(object sender, EventArgs e)
        {
            if (standardIndeicesComboBox.SelectedItem == null)
            {
                return;
            }

            int index = (int) standardIndeicesComboBox.SelectedItem;
            StandardRecord[] standards;
            ErrorCode error;
            if (index >= 0)
            {
                error = instrument.UploadStandards(out standards, (uint) index, 1);
            }
            else
            {
                error = instrument.UploadStandards(out standards, 0, uint.MaxValue);
            }

            if (error != ErrorCode.NoError)
            {
                MessageBox.Show(_(error.ToString()));
                return;
            }

            foreach (var standard in standards)
            {
                var item = new ListViewItem(new []
                {
                    standard.Id.ToString(),
                    standard.Name,
                    standard.DateTime.ToString(CultureInfo.CurrentCulture),
                    standard.Flags.IsTransitive ? _("Transitive") : _("Reflective"),
                    standard.Flags.Illuminant.ToString(),
                    _(standard.Flags.Observer.ToString()),
                    standard.Sci.L.ToString("F2"),
                    standard.Sci.a.ToString("F2"),
                    standard.Sci.b.ToString("F2"),
                });
                foreach (var t in standard.Sci.SpectralData)
                {
                    item.SubItems.Add((t * 100.0).ToString("F2"));
                }

                item.Tag = standard.Id;
                standardsListView.Items.Add(item);
            }
        }

        private void onUploadSample(object sender, EventArgs e)
        {
            var item = sender as ToolStripMenuItem;
            if (item == null)
                return;

            var tag = (Tuple<uint, int>) item.Tag;
            TrialRecord[] records;
            var error = instrument.UploadSamples(out records,
                tag.Item1, tag.Item2 == -1 ? 0 : (uint)tag.Item2, tag.Item2 == -1 ? uint.MaxValue : 1);

            if (tag.Item2 == -1)
            {
                samplesListView.Tag = tag.Item1;    // 将标样ID存到Tag中
                fillSamplesListView(records);
            }
            else
            {
                // 如果试样列表中有其他标样的试样，先清空列表
                if (samplesListView.Tag is uint && (uint) samplesListView.Tag != tag.Item1)
                {
                    samplesListView.Items.Clear();
                    samplesListView.Tag = tag.Item1;
                }
                addSamplesListView(records);
            }
        }

        private void standardsListViewContextMenuStrip_Opening(object sender, CancelEventArgs e)
        {
            if (standardsListView.SelectedItems.Count > 0)
            {
                uint stdId = (uint) standardsListView.SelectedItems[0].Tag;
                uint sampleCount = 0;
                var error = instrument.GetSampleCount(stdId, out sampleCount);
                uploadSampleToolStripMenuItem.Enabled = sampleCount > 0;
                if (sampleCount > 0)
                {
                    uploadSampleToolStripMenuItem.DropDownItems.Clear();
                    var subItem = uploadSampleToolStripMenuItem.DropDownItems.Add(Resources.AllSamples, null, onUploadSample);
                    subItem.Tag = new Tuple<uint, int>(stdId, -1);
                    for (int i = 0; i < (int)sampleCount; i++)
                    {
                        subItem = uploadSampleToolStripMenuItem.DropDownItems.Add(
                            string.Format(Resources.SampleX, i), null, onUploadSample);
                        subItem.Tag = new Tuple<uint, int>(stdId, i);
                    }
                }
            }
            else
            {
                uploadSampleToolStripMenuItem.Enabled = false;
                deleteStandardMenuItem.Enabled = false;
                deleteAllStandardsMenuItem.Enabled = standardsListView.SelectedItems.Count > 0;
                clearStandardListMenuItem.Enabled = standardsListView.SelectedItems.Count > 0;
            }
        }

        private void fillSamplesListView(TrialRecord[] samples)
        {
            samplesListView.Items.Clear();
            addSamplesListView(samples);
        }

        private void addSamplesListView(TrialRecord[] samples)
        {
            foreach (var sample in samples)
            {
                var item = new ListViewItem(new []
                {
                    sample.Id.ToString(),
                    sample.Name,
                    sample.DateTime.ToString(CultureInfo.CurrentCulture),
                    sample.Flags.IsTransitive ? _("Transitive") : _("Reflective"),
                    sample.Flags.Illuminant.ToString(),
                    _(sample.Flags.Observer.ToString()),
                    sample.Sci.L.ToString("F2"),
                    sample.Sci.a.ToString("F2"),
                    sample.Sci.b.ToString("F2"),
                });

                if (sample.Sci == null)
                {
                    return;
                }

                foreach (var t in sample.Sci.SpectralData)
                {
                    item.SubItems.Add((t * 100.0).ToString("F2"));
                }

                item.Tag = sample.StandardId;
                samplesListView.Items.Add(item);
            }
        }

        private void standardsListView_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            var pos = e.Location;
            var item = standardsListView.GetItemAt(pos.X, pos.Y);
            if (item == null)
                return;

            var stdId = (uint)item.Tag;
            TrialRecord[] records;
            var error = instrument.UploadSamples(out records, stdId, 0, uint.MaxValue);
            if (error != ErrorCode.NoError)
            {
                MessageBox.Show(_(error.ToString()));
                return;
            }
            fillSamplesListView(records);
        }

        private void clearListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            standardsListView.Items.Clear();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (standardsListView.SelectedItems.Count == 0)
                return;

            uint stdId = (uint) standardsListView.SelectedItems[0].Tag;
            var error = instrument.DeleteStandard(stdId);
            if (error != ErrorCode.NoError)
            {
                MessageBox.Show(_(error.ToString()));
            }
            else
            {
                standardsListView.Items.Remove(standardsListView.SelectedItems[0]);
            }
        }

        private void deleteAllRecordsMenuItem_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            if (standardsListView.Items.Count > 0)
            {
                var error = instrument.DeleteAllRecords();
                if (error != ErrorCode.NoError)
                {
                    MessageBox.Show(_(error.ToString()));
                }
                else
                {
                    samplesListView.Items.Clear();
                    standardsListView.Items.Clear();
                }
            }
            Cursor = Cursors.Default;
        }

        private void clearSamplesListViewMenuItem_Click(object sender, EventArgs e)
        {
            samplesListView.Items.Clear();
        }

        private void deleteAllSamplesFromInstrumentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            if (samplesListView.Items.Count > 0)
            {
                var error = instrument.DeleteSample((uint) samplesListView.Tag, uint.MaxValue);
                if (error != ErrorCode.NoError)
                {
                    MessageBox.Show(_(error.ToString()));
                }
                else
                {
                    samplesListView.Items.Clear();
                }
            }

            Cursor = Cursors.Default;
        }

        private void samplesListViewContextMenuStrip_Opening(object sender, CancelEventArgs e)
        {
            deleteAllSamplesMenuItem.Enabled = samplesListView.Items.Count > 0;
            clearSampleListMenuItem.Enabled = samplesListView.Items.Count > 0;
            deleteSelectedSampleMenuItem.Enabled = samplesListView.SelectedItems.Count > 0;
        }

        private void buttonCalibrateBlack_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            var error = instrument.CalibrateBlack();
            MessageBox.Show(error != ErrorCode.NoError ? _(error.ToString()) : Resources.BlackCalibrationCompleted);
            Cursor = Cursors.Default;
        }

        private void buttonCalibrateWhite_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            var error = instrument.CalibrateWhite();
            MessageBox.Show(error != ErrorCode.NoError ? _(error.ToString()) : Resources.WhiteCalibrationCompleted);
            Cursor = Cursors.Default;
        }

        private void scModeClicked(object sender, EventArgs e)
        {
            var item = sender as ToolStripMenuItem;
            if (item?.Tag is ScMode)
            {
                scMode = (ScMode) item.Tag;
                updateMeasurementListView();
            }
        }

        private void illuminantClicked(object sender, EventArgs e)
        {
            ToolStripMenuItem item = sender as ToolStripMenuItem;
            if (item?.Tag is StandardIlluminant)
            {
                standardIlluminant = (StandardIlluminant) item.Tag;
                updateMeasurementListView();
            }
        }

        private void observerClicked(object sender, EventArgs e)
        {
            ToolStripMenuItem item = sender as ToolStripMenuItem;
            if (item?.Tag is StandardObserver)
            {
                standardObserver = (StandardObserver) item.Tag;
                updateMeasurementListView();
            }
        }

        
        private void onColorSpaceClicked(object sender, EventArgs e)
        {
            ToolStripMenuItem item = sender as ToolStripMenuItem;
            if (item?.Tag is ColorSpace)
            {
                colorSpace = (ColorSpace) item.Tag;
                updateMeasurementListView();
            }
        }

        private void updateMeasurementListView()
        {
            measureResultListView.Items.Clear();
            if (standard == null && trial == null)
            {
                return;
            }

            double[] stdValues = null;
            double[] stdSpectralData = null;
            double[] trialValues = null;
            double[] trialSpectralData = null;
            if (standard != null)
            {
                stdSpectralData = (scMode == ScMode.SCI ? standard.Sci : standard.Sce)?.SpectralData;
                if (stdSpectralData != null)
                {
                    stdValues = Instrument.GetColorDataFromSpectralData(colorSpace, stdSpectralData, 
                        standardIlluminant, standardObserver);
                }
            }

            if (trial != null)
            {
                trialSpectralData = (scMode == ScMode.SCI ? trial.Sci : trial.Sce)?.SpectralData;
                if (trialSpectralData != null)
                {
                    trialValues = Instrument.GetColorDataFromSpectralData(colorSpace, trialSpectralData,
                        standardIlluminant, standardObserver);
                }
            }

            for (int i = 0; i < ColorSpaceItems[colorSpace].Length; i++)
            {
                var item = new ListViewItem();
                var label = ColorSpaceItems[colorSpace][i];
                item.SubItems.Add(label);
                var format = new[] {"x", "y", "β"}.Contains(label) ? "F4" : "F2";
                item.SubItems.Add(stdValues == null ? "--" : stdValues[i].ToString(format));
                item.SubItems.Add(trialValues == null ? "--" : trialValues[i].ToString(format));
                if (stdValues != null && trialValues != null)
                {
                    item.SubItems.Add((trialValues[i] - stdValues[i]).ToString(format));
                }

                measureResultListView.Items.Add(item);
            }

            for (int i = 0; i < Instrument.SpectralDataCount; i++)
            {
                var item = new ListViewItem();
                var label = $"{Instrument.WaveLengthMin + i * Instrument.WaveLengthInterval}nm";
                item.SubItems.Add(label);
                item.SubItems.Add(stdSpectralData == null ? "--" : (stdSpectralData[i] * 100.0).ToString("F2"));
                item.SubItems.Add(trialSpectralData == null ? "--" : (trialSpectralData[i] * 100.0).ToString("F2"));
                if (stdSpectralData != null && trialSpectralData != null)
                {
                    item.SubItems.Add(((trialSpectralData[i] - stdSpectralData[i]) * 100.0).ToString("F2"));
                }

                measureResultListView.Items.Add(item);
            }
        }

        private void buttonMeasureStandard_Click(object sender, EventArgs e)
        {
            StandardRecord record;
            var error = instrument.MeasureStandard(out record);
            if (error != ErrorCode.NoError)
            {
                MessageBox.Show(_(error));
                return;
            }

            standard = record;
            updateMeasurementListView();
        }

        private void buttonMeasureSample_Click(object sender, EventArgs e)
        {
            TrialRecord record;
            var error = instrument.MeasureTrial(out record);
            if (error != ErrorCode.NoError)
            {
                MessageBox.Show(_(error));
                return;
            }

            trial = record;
            updateMeasurementListView();
        }

        private void buttonGetCalibrationTime_Click(object sender, EventArgs e)
        {
            // 获取校正有效期
            var error = instrument.GetCalibrationValidTime(out int seconds);
            if (error == ErrorCode.NoError)
            {
                if (seconds > 0) 
                {
                    var msg = string.Format(
                    Resources.H_hours_M_minutes_S_seconds, seconds / 3600, seconds % 3600 / 60, seconds % 60);
                    MessageBox.Show(msg);
                }
                else
                {
                    MessageBox.Show("Forever");
                }
            }
            else
            {
                MessageBox.Show(_(error.ToString()));
            }
        }
    }
}
