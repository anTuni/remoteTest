﻿package com.tnh;


import java.nio.charset.StandardCharsets;

import com.sun.jna.*;

public interface BtsApiDll  extends Library {
    BtsApiDll instance = (BtsApiDll)Native.loadLibrary("D:/MyProjects/BtsApiDemo/Library/x64/BtsApi.dll", BtsApiDll.class);

    public static String CStrToString(byte[] c_str) {
        int len = 0;
        for (byte b : c_str) {
            if (b == 0) {
                break;
            }
            len++;
        }
        byte[] buffer = new byte[len];
        for (int i = 0; i < len; i++) {
            buffer[i] = c_str[i];
        }
        return new String(buffer, StandardCharsets.UTF_8);
    }

    public class DeviceInfo extends Structure {
        public byte[] model = new  byte[16];
        public byte[] optical = new byte[16];
        public byte[] sn = new byte[16];
        public byte[] software_version = new byte[16];
        public byte[] hardware_version = new byte[16];
        public byte[] white_board_number = new byte[16];    // white board number
		public byte[] black_bucket_number = new byte[16];   // not used
		public byte[] reserved = new byte[8];

        public String getModel() {
            return BtsApiDll.CStrToString(model);
        }
        public String getOptical() {
            return BtsApiDll.CStrToString(optical);
        }

        public String getSn() {
            return BtsApiDll.CStrToString(sn);
        }
        public String getSoftwareVersion() {
            return BtsApiDll.CStrToString(software_version);
        }
        public String getHardwareVersion() {
            return BtsApiDll.CStrToString(hardware_version);
        }
        public String getWhiteBoardNumber() {
            return BtsApiDll.CStrToString(white_board_number);
        }
    }

    /**
     * 打开连接
     * @param portName 串口名
     * @return 成功返回设备句柄，失败返回空指针
     */
    public Pointer btsOpen(String portName);

    /**
     * 关闭连接句柄
     * @param handle 已打开的设备句柄
     */
    public void btsClose(Pointer handle);

    /**
     * 获取仪器信息
     * @param handle 已打开的设备句柄
     * @param info 存储仪器信息
     * @return 错误码
     */
    public int btsGetDeviceInfo(Pointer handle, DeviceInfo info);
}