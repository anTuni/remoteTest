package com.tnh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.sun.jna.*;


class Command {
    public String cmd;
    public String help;
    public Runnable callback;

    public Command(String cmd, String help, Runnable callback) {
        this.cmd = cmd;
        this.help = help;
        this.callback = callback;
    }

    public void run() {
        if (callback != null) {
            callback.run();
        }
    }
}

/**
 * Hello world!
 *
 */
public class App 
{

    private Pointer handle;
    private Command[] commands;

    private App()
    {
        commands = new Command[] {
            new Command("h", "show this help", ()-> showHelps()),
            new Command("q", "quit this application", ()-> System.exit(0) ),
            new Command("o", "open the device", ()-> open()),
            new Command("c", "close the device", ()-> close()),
            new Command("i", "get deive information", ()-> getDeviceInfo()),
        };
    }

    public static void main( String[] args )
    {
        App app = new App();
        app.run();
    }

    private void showHelps() {
        for (Command command : commands) {
            System.out.println(command.cmd + " --- " + command.help);
        }
    }

    private void open() {
        handle = BtsApiDll.instance.btsOpen(null);
        if (handle != null) {
            System.out.print("Open device successfully");
        } else {
            System.out.print("Failed to open the device");
        }
    }

    private void close() {
        if (handle != null) {
            BtsApiDll.instance.btsClose(handle);
            handle = null;
        }
        System.out.print("The device has been closed");
    }

    private void getDeviceInfo() {
        if (handle != null) {
            BtsApiDll.DeviceInfo info = new BtsApiDll.DeviceInfo();
            if (BtsApiDll.instance.btsGetDeviceInfo(handle, info) == 0) {
                System.out.println("Device info:");
                System.out.println("Model: " + info.getModel());open();
                System.out.println("SN: " + info.getSn());
                System.out.println("Optical: " + info.getOptical());
                System.out.println("SoftwareVersion: " + info.getSoftwareVersion());
                System.out.println("HardwareVersion: " + info.getHardwareVersion());
                System.out.println("WhiteBoardNumber: " + info.getWhiteBoardNumber());
            } else {
                System.out.println("Failed to get the device information.");
            }
        }
    }

    private void run() {
        showHelps();

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        while (true) {
            System.out.print("\n>> ");

            String line;
            try {
                line = br.readLine().strip();
            } catch (IOException e) {
                e.printStackTrace();
                continue;
            }

            for (Command command : commands) {
                if (line.compareToIgnoreCase(command.cmd) == 0) {
                    command.run();
                }
            }
        }
    }
}
