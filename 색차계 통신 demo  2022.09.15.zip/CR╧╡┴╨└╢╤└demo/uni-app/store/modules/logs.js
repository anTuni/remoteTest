import {
	BLE_LOGS
} from '@/common/storageTypes.js'
import {
	getTime
} from '@/common/utils/utils.js'

let cache = uni.getStorageSync(BLE_LOGS);
console.log(cache);

let ble_logs = cache || [];


let state = {
	bleLogs: ble_logs
}
let getters = {

}
let mutations = {
	ADDBLELOG(state, log = null) {
		if (!log) {
			return
		}
		let time = getTime();
		let index = state.bleLogs.length + 1;
		log.createTime = time;
		log.index = index;
		state.bleLogs.push(log)
		uni.setStorageSync(BLE_LOGS, state.bleLogs);
	},
	CLEARBLELOGS(state) {
		state.bleLogs = []
		uni.setStorageSync(BLE_LOGS, state.bleLogs);
	}
}
let actions = {

}

export default {
	namespaced: true,
	state,
	getters,
	mutations,
	actions,
}
