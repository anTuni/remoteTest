/**
 * author: LiHan
 * description: 全局蓝牙Vuex类
 * @createTime: 2022-07-02 16:36:55
 */

import Command from '@/common/ble/core/Command.js'
import {
	CURRENT_DEVICE,
	NOTIFY_CACHE,
	BLE_LOGS
} from '@/common/storageTypes.js';
import {
	RESPONSE_TYPE
} from '@/common/ble/static/constant.js'

const executor = Command.getInstance().getExecutor('TS');
const DEVICE_HISTORY_LENGTH = 5;
const IS_CONNECTED = 1;
// #ifndef MP-WEIXIN
//发送数据每包最长字节长度
const MTU = 64;
const ANDROID_SEND_DELAY = 1000;
// #endif
// #ifdef MP-WEIXIN
const MTU = 20;
// #endif
const CONNECT_TIMEOUT = 5000; //蓝牙连接超时时间


let currentDevice = JSON.parse(uni.getStorageSync(CURRENT_DEVICE) || '{}'); //缓存的历史设备数组
console.log(`currentDevice:${JSON.stringify(currentDevice)}`);
let curDevId = currentDevice.deviceId || '';
let curBleInfo = currentDevice.bleInfo || {
	//可写的service.uuid
	writeId: "",
	//可写的characteristic.uuid
	writeCv: "",
	notifyId: "",
	notifyCv: "",
	readId: "",
	readCv: ""
};
// uni.removeStorageSync(NOTIFY_CACHE);

//读取缓存的notification数据
let notifyCache = JSON.parse(uni.getStorageSync(NOTIFY_CACHE) || '[]');

let state = {
	connected: false,
	isSearching: false,
	isOpenBle: false,
	scanTimer: '', //用来缓存计时器id
	curDevId,
	//当前设备的连接信息
	curBleInfo,
	loading: false,
	executor: executor, //蓝牙命令执行器
	cmdType: 'getInstrumentModel',
	notifyCache: notifyCache,
	protocolType: '',
	onNotify: null //RESPONSE_TYPE.NOTIFICATION的回调
}
let getters = {
	currentCmd(state) {
		if (executor && executor.hasOwnProperty(state.cmdType)) {
			return executor[state.cmdType]
		}
		return null;
	},
	//是否连接
	isConnected(state) {
		let ble = state.curBleInfo;
		return state.connected && state.curDevId && ble.writeId && ble.writeCv && ble.notifyId && ble.notifyCv &&
			ble.readId && ble.readCv
	},
}
let mutations = {
	//添加蓝牙设备并设为当前设备
	ADDDEVICE(state, {
		deviceId,
		bleInfo,
	} = {}) {
		if (deviceId) {
			state.curDevId = deviceId;
			state.curBleInfo = bleInfo;
			uni.setStorageSync(CURRENT_DEVICE, JSON.stringify({
				deviceId,
				bleInfo
			}));
		}
	},
	REMOVECURRENTDEVICE(state) {
		if (state.curDevId) {
			state.curDevId = '';
			state.curBleInfo = {
				//可写的service.uuid
				writeId: "",
				//可写的characteristic.uuid
				writeCv: "",
				notifyId: "",
				notifyCv: "",
				readId: "",
				readCv: ""
			}
			uni.removeStorageSync(CURRENT_DEVICE)
		}
	},
	//设置连接状态
	SETCONNECTION(state, isConnected) {
		state.connected = isConnected;
	},
	SETSEARCHING(state, isSearching) {
		//停止搜索则清除搜索计时器
		if (!isSearching && state.scanTimer) {
			clearTimeout(state.scanTimer);
			state.scanTimer = '';
		}
		state.isSearching = isSearching;
	},
	SETLOADING(state, isLoading) {
		/**
		 * 设置读取状态,isLoading可以为Boolean值或者Object
		 */
		let mask = false,
			title = '数据传输中';
		if ('object' === typeof isLoading) {
			if (isLoading.hasOwnProperty('mask')) {
				mask = isLoading.mask
			}
			if (isLoading.hasOwnProperty('title')) {
				title = isLoading.title
			}
			if (isLoading.hasOwnProperty('isLoading')) {
				isLoading = isLoading.isLoading
			} else {
				isLoading = false
			}
		}
		if (isLoading) {
			//如果当前已在loading状态,先结束之前的loading，然后根据设置开启新的loading动画
			if (state.loading) {
				uni.hideLoading()
			}
			// console.log(`isLoading:${JSON.stringify(isLoading)}`);
			uni.showLoading({
				title,
				mask
			})
		} else {
			if (state.loading) {
				uni.hideLoading()
			}
		}
		state.loading = isLoading;
	},
	SETTIMER(state, timer) {
		state.scanTimer = timer;
	},
	SETADAPTERSTATUS(state, isOpen) {
		state.isOpenBle = isOpen;
	},
	SETBLESTATUS(state, status) {
		//停止搜索则清除搜索计时器
		if (status && status.hasOwnProperty('isSearching') && !status.isSearching && state.scanTimer) {
			clearTimeout(state.scanTimer);
			state.scanTimer = '';
		}
		for (let prop in state) {
			if (state.hasOwnProperty(prop) && status.hasOwnProperty(prop)) {
				state[prop] = status[prop]
			}
		}
	},
	SETCMDTYPE(state, type) {
		console.log(`SETCMDTYPE=>type:${JSON.stringify(type)}`);
		if (state.type != type && state.executor && state.executor.hasOwnProperty(type)) {
			state.cmdType = type;
			console.log(`state.cmdType:${JSON.stringify(state.cmdType)}`);
		}
	},
	ADDNOTIFICATION(state, data) {
		if (data && Object.keys(data).length) {
			state.notifyCache.unshift(data);
			console.log(`state.notifyCache:${JSON.stringify(state.notifyCache.length)}`);

			uni.setStorageSync(NOTIFY_CACHE, JSON.stringify(state.notifyCache))
		}
	},
	DELETENOTIFICATION(state, index) {
		if (index === 'all') {
			state.notifyCache = [];
		} else if (Array.isArray(index)) {
			state.notifyCache = state.notifyCache.filter((_, i) => !index.includes(i));
		} else if (state.notifyCache.length > Number(index)) {
			state.notifyCache.splice(index, 1)
		}
		uni.setStorageSync(NOTIFY_CACHE, JSON.stringify(state.notifyCache))
	},
	SETONNOTIFY(state, onNotify) {
		if (onNotify && 'function' === typeof onNotify && state.onNotify != onNotify) {
			state.onNotify = onNotify;
		}
	}
}
let actions = {
	doRequest({
		state,
		dispatch,
		commit
	}, {
		cmdName,
		args = undefined,
		timeout = 3000,
		loadMsg
	} = {}) {
		console.log(`{cmdName,args,timeout,loadMsg}:${JSON.stringify({cmdName,args,timeout,loadMsg})}`);
		let executor = state.executor;
		let cmd = executor[cmdName];
		let promise = Promise.resolve();
		if (cmd) {
			let buffer = (args && args.length ? cmd.req(...args) : cmd.req());
			// console.log(`buffer:${JSON.stringify(buffer.byteLength)}`);
			// console.log(buffer);
			let setResponseType = cmd.setResponseType;
			promise = promise.then(_ => dispatch('writeBLECharacteristic', {
				buffer,
				//发送请求后将响应格式置为RETURN
				afterReq: (type = RESPONSE_TYPE.RETURN) => {
					commit('SETCMDTYPE', cmdName);
					setResponseType(type);
				},
				//响应的执行器
				resExecutor: cmd.res,
				timeout,
				loadMsg
			}));
		} else {
			promise = promise.then(_ => Promise.reject({
				errMsg: '无效的蓝牙命令'
			}));
		}
		return promise.catch(err => {
			console.log(`doRequest=>${cmdName}出错:${JSON.stringify(err)}`);

		})
	},
	async writeBLECharacteristic({
		commit,
		dispatch,
		state,
		getters
	}, {
		buffer, //命令的字节码
		timeout = 10000,
		afterReq, //发送请求的回调,需要在这个时期把Executor解析状态从NOTIFICATION置为RETURN，以确保后续第一条完整响应作为RETURN来解析
		resExecutor = getters.currentCmd.res,
		loadMsg,
		deviceId = state.curDevId,
		serviceId = state.curBleInfo.writeId,
		characteristicId = state.curBleInfo.writeCv
	} = {}) {
		let timeoutId = null;
		commit('SETLOADING', {
			isLoading: true,
			mask: true,
			title: loadMsg || undefined
		});
		const clock = new Promise((resolve, reject) => {
			timeoutId = setTimeout(() => {
				timeoutId = null;
				reject({
					errMsg: '请求超时了!'
				})
			}, timeout);
		});
		// console.log(`characteristicId1:${JSON.stringify(characteristicId)}`);

		const req = dispatch('printbuffs', {
			buffer,
			deviceId,
			serviceId,
			characteristicId
		}).then(_ => {
			if (afterReq) {
				afterReq()
			}
		}).then(_ => dispatch('handlerBLECvChange', {
			executor: resExecutor
		}));
		return Promise.race([clock, req]).then(res => {
			commit('SETLOADING');
			//发送并读取成功,清除计时器
			if (timeoutId) {
				clearTimeout(timeoutId)
			}
			return res;
		}, msg => {
			if (afterReq) {
				// console.log(`111:${JSON.stringify(111)}`);
				afterReq(RESPONSE_TYPE.NOTIFICATION)
			}
			commit('SETLOADING');
			if (timeoutId) {
				clearTimeout(timeoutId)
			}
			console.log(`writeBLECharacteristic超时/出错:${JSON.stringify(msg)}`);
			return Promise.reject({
				errMsg: `writeBLECharacteristic超时/出错:${JSON.stringify(msg)}`
			});
		})
	},
	printbuffs({
		dispatch,
		state
	}, {
		buffer,
		deviceId = state.curDevId,
		serviceId = state.curBleInfo.writeId,
		characteristicId = state.curBleInfo.writeCv
	} = {}) {
		//根据请求长度和MTU决定是否分包发送
		let promise = Promise.resolve();
		for (let i = 0, j = 0, length = buffer.byteLength; i < length; i += MTU,
			j++) {
			let subPackage = buffer.slice(i, i + MTU <= length ? (i + MTU) :
				length);
			promise = promise.then(_ => dispatch('writeBLECharacteristicValue', {
				buffer: subPackage,
				deviceId,
				serviceId,
				characteristicId
			}));
		}
		return promise;
	},
	writeBLECharacteristicValue({
		state,
		getters
	}, {
		buffer,
		deviceId = state.curDevId,
		serviceId = state.curBleInfo.writeId,
		characteristicId = state.curBleInfo.writeCv
	} = {}) {
		if (!getters.isConnected) {
			return Promise.reject({
				errMsg: '连接异常,命令发送中断!'
			})
		}
		// console.log('deviceId', deviceId);
		// console.log('serviceId', serviceId);
		// console.log('characteristicId', characteristicId);
		return uni.writeBLECharacteristicValue({
			deviceId,
			serviceId,
			characteristicId,
			value: (buffer instanceof Uint8Array ? buffer.buffer : buffer),
		});
	},
	notifyBLECharacteristicValueChange({
		state,
		getters
	}, {
		deviceId = state.curDevId,
		serviceId = state.curBleInfo.notifyId,
		characteristicId = state.curBleInfo.notifyCv
	} = {}) {
		if (!getters.isConnected) {
			return Promise.reject({
				errMsg: 'notifyBLECharacteristicValueChange时连接异常,命令发送中断!'
			})
		}
		console.log(`开始监听:${JSON.stringify({deviceId,serviceId,characteristicId})}`);
		return uni.notifyBLECharacteristicValueChange({
			state: true,
			deviceId,
			serviceId,
			characteristicId
		})
	},
	// ====================================
	//同步方式处理响应结果
	cvSuccessHandlerSync({
		commit,
		dispatch,
		state
	}, {
		result,
		success,
		onNotify = state.onNotify
	} = {}) {
		console.log(`读取响应为result:${JSON.stringify(result)}`);
		//如果响应为NOTIFICATION，则需要通知信息做处理
		if (result.resType == RESPONSE_TYPE.NOTIFICATION) {
			// dispatch('parseNotification', result)
			// let result=(result)
			commit('ADDNOTIFICATION', result.data);
			if (onNotify) {
				commit('SETONNOTIFY', onNotify);
				onNotify(result);
			}
		}
		if (success) {
			return success(result);
		} else {
			return result;
		}
	},
	/**
	 * onBLECharacteristicValueChange一次回调不一定能读完一条响应，需要进行封装
	 * 针对特征值变化回调api的promise的包装方法，不取返回值时可以用于同步回调
	 * 当用于请求以后要获取RESPONSE_TYPE.RETURN类型响应的时候可以用返回的promise来获取回调状态(因为请求的回复有比较稳定的预期)
	 * 当用于监视设备发送的RESPONSE_TYPE.NOTIFICATION类型的通知响应的时候，建议不要获取返回值，而是通过success,fail,complete获取回调(因为通知响应不可预期)
	 * @param {Function} executor - 响应执行对象方法
	 * @param {Function} onNotify - RESPONSE_TYPE.NOTIFICATION的同步回调
	 * @param {Function} success - 响应解析成功回调
	 * @param {Function} fail - 响应解析失败回调
	 * @param {Function} complete- 
	 */
	handlerBLECvChange({
		commit,
		dispatch,
		getters
	}, {
		executor = getters.currentCmd.res,
		onNotify,
		success = () => {},
		fail,
		complete
	} = {}) {
		let onSuccess = null;
		let promise = new Promise((resolve, reject) => {
			onSuccess = function(res) {
				resolve(res)
			};
		});
		if (onNotify) {
			commit('SETONNOTIFY', onNotify);
		}
		console.log(`开始读取监听==>executor:${ typeof executor }`);
		uni.onBLECharacteristicValueChange(chVal => {
			console.log(
				`characteristic ${chVal.characteristicId} has changed, now is ${chVal.value}`
			);
			executor({
				buffer: chVal.value,
				success: result => {
					//成功读取一条完整响应
					dispatch('cvSuccessHandlerSync', {
						result,
						success,
						onNotify
					});
					if (result.resType === RESPONSE_TYPE.RETURN) {
						onSuccess(result)
					}
				},
				fail,
				complete
			})
		})
		return promise;
	},
	async createBleConnection({
		state,
		commit,
		dispatch
	}, {
		deviceId = state.curDevId,
		onNotify
	} = {}) {
		//1.获取当前蓝牙适配器状态
		let res1 = await uni.getBluetoothAdapterState();
		console.log(`蓝牙适配器状态获取成功=>${JSON.stringify(res1)}`)
		if (!res1) {
			return Promise.reject({
				errMsg: 'getBluetoothAdapterState失败'
			})
		}
		let promise = Promise.resolve();
		if (res1 && res1[0]) {
			//一、蓝牙适配器没有打开，则先打开蓝牙适配器
			promise = promise.then(_ => dispatch('openBluetoothAdapter'))
		} else if (res1 && !res1[0]) {
			//二、当前蓝牙适配器已经打开,可以成功获取当前蓝牙适配器状态
			commit('SETBLESTATUS', {
				isOpenBle: true,
				isSearching: res1[1].discovering
			});
			if (res1[1].discovering) {
				//1.如果蓝牙搜索中，则先停止蓝牙搜索
				promise = promise.then(_ => dispatch('stopBluetoothDevicesDiscovery'))
			}
			//2.获取当前蓝牙连接状态，当前是否蓝牙连接
			promise = promise.then(_ => uni.getConnectedBluetoothDevices({})).then(res2 => {
				console.log(`res2:${JSON.stringify(res2)}`);
				let promise2 = Promise.resolve();
				//1)当前已有蓝牙连接
				if (res2 && res2[1] && res2[1].devices && res2[1].devices.length) {
					//a.已连接当前设备
					if (res2[1].devices.includes(deviceId)) {
						commit('SETCONNECTION', true);
						return Promise.resolve(IS_CONNECTED);
					}
					//b.连接的不是当前设备,则先断开当前蓝牙设备
					promise2 = promise2.then(_ => dispatch('closeBleConnection', res2[1].devices[0]))
				}
				//2)当前未有蓝牙连接
				return promise2
			})
		}
		//三.除开已经连接当前设备的情况,连接指定蓝牙设备
		promise = promise.then(status => {
			if (status === IS_CONNECTED) {
				console.log(`已连接当前设备`);
				return Promise.resolve();
			} else {
				return dispatch('createBLEConnection', deviceId).then(_ => dispatch(
					'getBLEDeviceServices', deviceId)).then(serviceList => dispatch(
					'getBLEDeviceCharacteristics', {
						deviceId,
						serviceList
					}))
			}
		})
		promise = promise.then(_ => {
			dispatch('notifyBLECharacteristicValueChange');
		}).then(_ => {
			dispatch('handlerBLECvChange', {
				onNotify
			})
		});
		// #ifdef APP-PLUS
		//安卓平台上，在调用 notifyBLECharacteristicValueChange 成功后立即调用 writeBLECharacteristicValue 接口，在部分机型上会发生 10008 系统错误
		promise = promise.then(_ => new Promise((resolve, reject) => {
			console.log(`>>>开始延时${ANDROID_SEND_DELAY}毫秒`);
			setTimeout(() => {
				console.log(`延时${ANDROID_SEND_DELAY}毫秒==>`);
				resolve();
			}, ANDROID_SEND_DELAY)
		}));
		// #endif
		return promise.catch(err => {
			console.log(`蓝牙连接发生错误:${JSON.stringify(err)}`);
			return Promise.reject(`蓝牙连接发生错误:${JSON.stringify(err)}`)
		});
	},
	async getConnection({
		state,
		commit,
		dispatch
	}, {
		deviceId = state.curDevId,
		timeout = CONNECT_TIMEOUT,
		loadMsg,
		onNotify
	} = {}) {
		let timeoutId = null;
		commit('SETLOADING', {
			isLoading: true,
			mask: true,
			title: loadMsg || undefined
		});
		const clock = new Promise((resolve, reject) => {
			timeoutId = setTimeout(() => {
				timeoutId = null;
				reject({
					errMsg: '蓝牙连接超时了!'
				})
			}, timeout);
		});
		const req = dispatch('createBleConnection', {
			deviceId,
			onNotify
		});
		return Promise.race([clock, req]).then(res => {
			commit('SETLOADING');
			//发送并读取成功,清除计时器
			if (timeoutId) {
				clearTimeout(timeoutId)
			}
			return res;
		}, msg => {
			commit('SETLOADING');
			if (timeoutId) {
				clearTimeout(timeoutId)
			}
			dispatch('closeBleConnection');
			console.log(`getConnection超时/出错:${JSON.stringify(msg)}`);
			return Promise.reject({
				errMsg: 'getConnection超时'
			});
		})
	},
	async startBleScan({
		commit,
		dispatch,
	}, {
		onDeviceFoundCallback,
		timeout = 5000
	} = {}) {
		/**
		 * 开始蓝牙扫描,onDeviceFoundCallback为成功扫描到设备的回调函数
		 * timeout为扫描持续时间
		 */
		//微信小程序中,没有重启蓝牙适配器的话,不再能搜索到之前已经扫描过的设备
		//为了解决这个问题,选择在每次扫描前确保已经刷新蓝牙适配器的状态
		let res1 = await uni.getBluetoothAdapterState();
		console.log(`蓝牙适配器状态获取成功=>${JSON.stringify(res1)}`)
		if (!res1) {
			return Promise.reject({
				errMsg: 'getBluetoothAdapterState失败'
			})
		}
		let promise = Promise.resolve();
		if (res1 && !res1[0]) {
			//当前蓝牙适配器已经打开,可以成功获取当前蓝牙适配器状态
			commit('SETBLESTATUS', {
				isOpenBle: true,
				isSearching: res1[1].discovering
			});
			if (res1[1].discovering) {
				//ifdef MP-WEIXIN
				//如果在微信小程序中蓝牙适配器已经打开，则要考虑重启蓝牙适配器（因为微信小程序中不重启蓝牙适配器会搜索不到之前搜到过的设备）
				//所以如果蓝牙适配器处于搜索状态,先关闭搜索状态
				promise = promise.then(_ => dispatch('stopBluetoothDevicesDiscovery'))
				//endif
				//ifndef MP-WEIXIN
				//非微信小程序中，不需要重启蓝牙适配器,直接扫描即可
				// return promise.then(_ => {
				// 	uni.onBluetoothDeviceFound(onDeviceFoundCallback);
				// 	dispatch('startScanTimer', timeout);
				// 	return Promise.resolve()
				// }).catch(err => {
				// 	console.log(`蓝牙扫描初始化发生错误:${JSON.stringify(err)}`);
				// })
				//endif
			}
			//当前蓝牙适配器开启，但是不在搜索状态
			//如果当前蓝牙适配器在连接状态，断开连接再开启搜索
			promise = promise.then(_ => dispatch('closeBleConnection'));
			//ifdef MP-WEIXIN
			//如果为微信小程序，则需要关闭蓝牙适配器然后重启
			promise = promise.then(_ => dispatch('closeBluetoothAdapter')).then(_ => dispatch(
				'openBluetoothAdapter'))
			//endif
		} else if (res1 && res1[0]) {
			//蓝牙适配器没有打开，则先打开蓝牙适配器
			promise = promise.then(_ => dispatch('openBluetoothAdapter'))
			// return this.doOpenBluetoothAdapterAndScan();
		}
		//开启搜索
		promise = promise.then(_ => dispatch('startBluetoothDevicesDiscovery', {
			onDeviceFoundCallback,
			timeout
		}))
		return promise.catch(err => {
			console.log(`蓝牙搜索初始化失败:${JSON.stringify(err)}`);
		})
	},
	async getBLEDeviceCharacteristics({
		commit,
		dispatch,
		state
	}, {
		deviceId = state.curDevId,
		serviceList,
	} = {}) {
		// 遍历serviceList,获取deviceId连接的三种特征值
		let BleInfo = {};
		for (let i = 0; i < serviceList.length; i++) {
			let serviceId = serviceList[i].uuid;
			// console.log(`{deviceId,serviceId}:${JSON.stringify({deviceId,serviceId})}`);

			let res = await uni.getBLEDeviceCharacteristics({
				deviceId,
				serviceId
			})
			// console.log(`res:${JSON.stringify(res)}`);
			if (res && res[1] && res[1].characteristics && res[1].characteristics.length) {
				for (let _obj of res[1].characteristics) {
					let cvProp = _obj.properties;
					let cvId = _obj.uuid;
					if (!BleInfo.notifyId && (cvProp.notify)) {
						BleInfo.notifyCv = cvId;
						BleInfo.notifyId = serviceId;
					}
					if (!BleInfo.writeId && cvProp.write) {
						BleInfo.writeCv = cvId;
						BleInfo.writeId = serviceId;
					}
					if (!BleInfo.readId && cvProp.read) {
						BleInfo.readCv = cvId;
						BleInfo.readId = serviceId;
					}
				}
			}
			if (BleInfo.writeId && BleInfo.notifyId && BleInfo.readId) {
				//蓝牙特征值读取完成
				return Promise.resolve().then(_ => {
					console.log(`获取服务后的curBleInfo:${JSON.stringify(BleInfo)}`);
					commit('ADDDEVICE', {
						deviceId,
						bleInfo: BleInfo
					})
				}).catch(err => {
					console.log(`读取特征值发生错误:${JSON.stringify(err)}`);

				})
			}
		}
		return Promise.reject({
			errMsg: '未成功获取所有特征值'
		})
	},
	getBLEDeviceServices({
		commit,
		state
	}, targetId) {
		let deviceId = targetId || state.curDevId;
		if (!deviceId) {
			return Promise.reject({
				errMsg: 'getBLEDeviceServices中deviceId不能为空'
			})
		}
		let _serviceList = [];
		// console.log(`getBLEDeviceServices=>deviceId:${JSON.stringify(deviceId)}`);
		//蓝牙建立连接后立刻获取设备服务列表的话,可能会出错,延时1秒可以避免这种情况出现
		return new Promise((resolve, reject) => {
			setTimeout(_ => resolve(), 1000);
		}).then(_ => uni
			.getBLEDeviceServices({
				deviceId
			})).then(res => {
			console.log(`res:${JSON.stringify(res)}`);
			for (let service of res[1].services) {
				if (service.isPrimary) {
					_serviceList.push(service);
				}
			}
			return Promise.resolve(_serviceList)
		}).catch(err => {
			console.log(`获取蓝牙服务列表失败:${JSON.stringify(err)}`);
		})
	},
	createBLEConnection({
		commit,
		state
	}, targetId) {
		let deviceId = targetId || state.curDevId;
		return uni.createBLEConnection({
			deviceId: deviceId
		}).then(_ => {
			commit('SETCONNECTION', true);
		}).catch(err => {
			console.log(`createBLEConnection失败:${JSON.stringify(err)}`);
		})
	},
	startScanTimer({
		commit,
		dispatch
	}, timeout = 5000) {
		console.log(`timeout:${JSON.stringify(timeout)}`);

		let timer = setTimeout(() => {
			dispatch('stopBluetoothDevicesDiscovery');
		}, timeout);
		commit('SETTIMER', timer);
	},
	stopBluetoothDevicesDiscovery({
		commit
	}) {
		return uni.stopBluetoothDevicesDiscovery({}).then(_ => {
			console.log(`停止蓝牙搜索...`);
			commit('SETSEARCHING', false);
			commit('SETLOADING', false);
			return Promise.resolve();
		}).catch(err => {
			console.log(`停止蓝牙扫描发生错误:${JSON.stringify(err)}`);
		});
	},
	startBluetoothDevicesDiscovery({
		commit,
		dispatch
	}, {
		onDeviceFoundCallback,
		timeout
	}) {
		return uni.startBluetoothDevicesDiscovery({}).then(_ => {
			commit('SETSEARCHING', true);
			commit('SETLOADING', {
				isLoading: true,
				title: `蓝牙扫描中...`
			})
			uni.onBluetoothDeviceFound(onDeviceFoundCallback);
			if (timeout) {
				dispatch('startScanTimer', timeout);
			}
			return Promise.resolve()
		}).catch(err => {
			console.log(`开启蓝牙扫描时出错:${JSON.stringify(err)}`);
		})
	},
	closeBluetoothAdapter({
		commit
	}) {
		return uni.closeBluetoothAdapter({}).then(_ => {
			console.log(`closeBluetoothAdapter`);
			commit('SETADAPTERSTATUS', false)
			return Promise.resolve();
		}).catch(err => {
			console.log(`蓝牙适配器关闭失败:${JSON.stringify(err)}`);
		})
	},
	closeBleConnection({
		commit,
		state
	}, deviceId = state.curDevId) {
		//如果指定deviceId,则断开与指定deviceId的连接
		let targetId = deviceId;
		let promise = Promise.resolve(targetId);
		if (!targetId) {
			//没有指定deviceId，则查看当前是否处于蓝牙连接中，是的话获取连接的deviceId
			promise = promise.then(_ => uni.getConnectedBluetoothDevices({})).then(res => {
				console.log(`蓝牙连接状态=>${JSON.stringify(res)}`)
				if (res[1] && res[1].devices && res[1].devices.length) {
					targetId = res[1].devices[0].deviceId;
					console.log(`targetId :${JSON.stringify(targetId )}`);
					if (!state.connected) {
						commit('SETCONNECTION', true);
					}
				}
				return Promise.resolve(targetId);
			})
		}
		return promise.then(id => {
			if (!id) {
				return Promise.resolve();
			}
			return uni.closeBLEConnection({
				targetId
			}).then(_ => commit('SETCONNECTION', false))
		}).catch(err => {
			console.log(`断开蓝牙连接时发生错误:${JSON.stringify(err)}`);
		})
	},
	openBluetoothAdapter({
		commit,
		state
	}) {
		let promise = Promise.resolve();
		promise = promise.then(_ => uni.openBluetoothAdapter({})).then(_ => {

			commit('SETADAPTERSTATUS', true);
			//设定蓝牙状态监视
			console.log(`openBluetoothAdapter=>onBluetoothAdapterStateChange`);
			uni.onBluetoothAdapterStateChange(function(res) {
				//监视蓝牙适配器的连接状态
				let title = '';
				if (res.available != state.isOpenBle) {
					title += '蓝牙适配器' + `:${res.available?'开启':'关闭'}`;
				}
				if (res.discovering != state.isSearching) {
					title +=
						`${res.discovering?'开始搜索':'停止搜索'}.`;
				}
				console.log(`SETBLESTATUS res:${JSON.stringify(res)}`);
				commit('SETBLESTATUS', {
					isOpenBle: res.available,
					isSearching: res.discovering
				});
				if (title) {
					uni.showToast({
						title,
						icon: 'none'
					})
				}

			});
			console.log(`openBluetoothAdapter=>onBLEConnectionStateChange`);
			uni.onBLEConnectionStateChange(function(res) {
				// 该方法回调中可以用于处理连接意外断开等异常情况
				let title = '';
				if (res.connected != state.connected) {
					title += (res.connected ? `蓝牙连接` : `断开连接`);
				}
				if (title) {
					uni.showToast({
						title,
						icon: 'none'
					})
				}
				console.log(`res:${JSON.stringify(res)}`);
				commit('SETCONNECTION', res.connected);
			});
			return Promise.resolve()
		});
		return promise.catch(err => {
			console.log(`蓝牙适配器初始化失败:${JSON.stringify(err)}`);
		})
	}
}

export default {
	namespaced: true,
	state,
	getters,
	mutations,
	actions,
}
