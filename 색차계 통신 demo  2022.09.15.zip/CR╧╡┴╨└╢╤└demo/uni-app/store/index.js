import bluetooth from '@/store/modules/bluetooth.js'
import logs from '@/store/modules/logs.js'

// #ifndef VUE3
import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)
const store = new Vuex.Store({
	modules: {
		bluetooth,
		logs
	},
	strict: true
})
// #endif

// #ifdef VUE3
import {createStore} from 'vuex'
const store = createStore({
	modules: {
		bluetooth,
		logs
	}
})
// #endif

export default store