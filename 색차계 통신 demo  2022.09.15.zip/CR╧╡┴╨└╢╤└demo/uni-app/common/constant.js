/**
 * author: LiHan
 * description: 常量和枚举类
 * @createTime: 2022-07-01 11:26:52
 */
export const UUIDS_FILTERS = Object.freeze({
	'BLE4': '000018F0-0000-1000-8000-00805F9B34FB',
	'BLE5': '0000E0FF-3C17-D293-8E48-14FE2E4DA212'
});