/**
 * 本地储存键 types
 * **/
let prefix = 'ts';
const keys = prefix + '_';// 命名空间


//设备管理
export const CURRENT_DEVICE = `${keys}current_device`; //当前连接设备
//日志管理
export const BLE_LOGS = `${keys}ble_logs`; //蓝牙操作历史
//设备通知数据缓存
export const NOTIFY_CACHE=`${keys}notify_cache`; 