/**
 * author: LiHan
 * description: 蓝牙协议设定
 * @createTime: 2022-05-20 14:40:22
 */
import store from '@/store/index.js';
import {
	ts_protocol
} from './ts_protocol.js'



export const protocols = [ts_protocol];
