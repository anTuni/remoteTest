/**
 * author: LiHan
 * description: Ts系列蓝牙协议
 * @createTime: 2022-07-05 08:58:40
 */
import {
	uint16ToUint8Array,
	hexString2Uint8Array,
	uint8ArrayToHex
} from '../utils/utils.js'
import {
	ENDIAN_TYPE,
	OBSERVER,
	SC_MODE,
	CHECK_RESULT,
	VALID_WAVE_NUM
} from './constant.js'
import {
	loadInt,
	loadString,
	loadFloat,
	loadByte,
	loadUint16,
	loadUintArrayByFlag,
	requestByByteFlag,
	requestByUint32Parameters,
	getSubUint8Array
} from '@/common/ble/utils/parseUtils.js'



export const TS_RECORD_NAME_LENGTH = 9;
export const TS_DATETIME_LENGTH = 8;


//根据长度解析notification类型响应
export function ts_notificationParser(buffer) {
	if (buffer.length >= 4 && buffer.length == 260) {
		let nameStart = Number(buffer[12].toString());
		let data = buffer.slice(4);
		console.log(`nameStart:${JSON.stringify(nameStart)}`);
		switch (nameStart) {
			case 84:
				//名字T开头,解析为标样
				return loadStandardResInTs(data);
			case 115:
				//名字s开头,解析为试样
				return loadSampleResInTs(data);
		}
	}
	return null;
}

//TS协议测量口径
export const TS_CALIBER = Object.freeze({
	'PHI_4': 0, // 4mm
	'PHI_8': 1, // 8mm
	'PHI_AUTO': 2, // 自动模式
	'PHI_1X3': 3 // 1*3mm
})
//TS协议标准光源
export const TS_ILLUMINANT = Object.freeze({
	'D65': 0,
	'D50': 1,
	'A': 2,
	'C': 3,
	'D55': 4,
	'D75': 5,
	'F1': 6,
	'F2': 7,
	'F3': 8,
	'F4': 9,
	'F5': 10,
	'F6': 11,
	'F7': 12,
	'F8': 13,
	'F9': 14,
	'F10': 15,
	'F11': 16,
	'F12': 17
})
export const TS_COLOR_SPACE = Object.freeze({
	'CIELab': 0,
	'HunterLab': 1,
	'CIEXYZ': 2,
	'sRGB': 3,
	'CIEYxy': 4,
	'Munsell': 5,
	'CIELCh': 6,
	'βxy': 7,
	'CIELuv': 8,
	'DINLab99': 9
})
//颜色指标
export const TS_COLOR_INDEX = Object.freeze({
	'COLOR_INDEX_INVALID': 0, //不选任何选项
	'YELLOWNESS': 1, // 黄度指数
	'WHITENESS': 2, // 白度指数
	'STRENGTH': 3, // 力份
	'METAMERISM_INDIEX': 4, // 同色异谱指数
	'OPACITY': 5, // 遮盖度
	'HUE_CLASSIFY_555': 6, //555色调分类
	'STAINING_FASTNESS': 7, // 沾色牢度    
	'GARDNER_INDEX': 8, //透射Garder指数
	'COLOR_FASTNESS': 9, // 变色牢度
	'PT_CO_INDEX': 10, //pt co指数
	'GLOSS_8': 11 //8 度光泽度
})
// 色差公式
export const TS_COLOR_DIFF_FORMULA = Object.freeze({
	'CIEDE': 0, // ΔE*ab
	'CIEDE94': 1, // ΔE*94
	'CIEDE2000': 2, // ΔE*2000 ΔE*00
	'DECMC11': 3, // ΔE*cmc(1:1)
	'DECMC21': 4, // ΔE*cmc(2:1)
	'DECMC': 5, // ΔE*cmc(l:c)
	'DIN_E99': 6, // DIN E99
	'DEHUNTER': 7, // dE(Hunter)
})
// uv模式
export const TS_UV_MODE = Object.freeze({
	'UV_CUT_NONE': 0,
	'UV_CUT_400': 1,
	'UV_CUT_420': 2
})

// 校正
export const TS_CALIBRATE = Object.freeze({
	'CALIBRATE_BLACK': 0, //黑校
	'CALIBRATE_WHITE': 1 //白校
})
// 测量
export const TS_MEASURE_TYPE = Object.freeze({
	'MEASURE_STANDARD': 0, //标样测量
	'MEASURE_TRIAL': 1 //试样测量
})
// 数据类型
export const TS_DATA_TYPE = Object.freeze({
	'SPECTRUM': 0, //反射光谱
	'LAB': 1, //Lab值
	'XYZ': 2 //xyz值
})

export const TS_U16FLAG = Object.freeze({
	'OPTICAL_MODE': {
		start: 0,
		len: 1
	},
	'SC_MODE': {
		start: 1,
		len: 2
	},
	'UV_MODE': {
		start: 3,
		len: 2
	},
	'CALIBER': {
		start: 5,
		len: 3
	},
	'LENS_POS': {
		start: 8,
		len: 3
	},
	'DATA_TYPE': {
		start: 11,
		len: 2
	},
	'LOCK': {
		start: 13,
		len: 1
	}
})




export const ts_protocol = {
	name: 'TS',
	defaults: {
		req: {
			endian: ENDIAN_TYPE.LITTLE_ENDIAN
		},
		command: {
			res: {
				chk: buffer => {
					/**
					 * 返回值:0代表未完成,1代表校验成功,2代表校验失败
					 */
					let data = (buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer));
					// let logRes=
					console.log(`响应缓存为:${JSON.stringify(uint8ArrayToHex(data,' '))}`);
					if (!data || !data.length) {
						return CHECK_RESULT.PENDING;
					}
					let len = data[2] + (data[3] << 8),
						length = data.length - 4;
					console.log(`len位值为:${JSON.stringify(len)}`);
					console.log(`收到响应长度length为:${JSON.stringify(length)}`);
					return len > length ? CHECK_RESULT.PENDING : len == length ? CHECK_RESULT.RESOLVE :
						CHECK_RESULT.REJECT;
				},
				pre: (buffer, command, cache, requestArgs) => {
					let data = (buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer));
					console.log(
						`命令响应data部分为:${JSON.stringify(uint8ArrayToHex(data.slice(4),' '))}`
					);
					console.log(`command.req.cmdType.pre():${JSON.stringify(command.req.cmdType.pre())}`);
					return data.slice(4);
				},
			}
		}

	},
	req: {
		cmdType: {
			index: 0,
			handler: (pre, cmd) => hexString2Uint8Array(pre.toLowerCase(), cmd.req.cmdType.endian)
		},
		len: {
			index: 1,
			phase: 1,
			handler: function(pre, cmd, cache) {
				let datas = cache.data;
				if (datas && datas.length) {
					return uint16ToUint8Array(datas.length, cmd.req.len.endian)
				}
				return uint16ToUint8Array(0, cmd.req.len.endian)
			}
		},
		data: {
			index: 2,
			// args: [0],
			handler: pre => pre ? pre : new Uint8Array(0)
		}
	},
	command: {
		//是否校正
		isCalibrated: {
			req: {
				cmdType: _ => '02 00'
			},
			res: data => (data[0] ? true : false)
		},
		//获取标样总数
		getStandardAmount: {
			req: {
				cmdType: _ => '02 01'
			},
			res: data => loadInt(data, 0, data.length / 4)[0]
		},
		//获取试样总数
		getSampleAmount: {
			req: {
				cmdType: _ => '02 02'
			},
			res: buffer => {
				let data = (buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer));
				return parseInt(data.slice(2, 3).toString()) + (parseInt(data.slice(3, 4).toString()) << 8) + (
					parseInt(data.slice(0, 1).toString()) << 16) + (parseInt(data.slice(1, 2).toString()) <<
					24);
			}
		},
		//仪器型号
		getInstrumentModel: {
			req: {
				cmdType: _ => '02 03'
			},
			res: data => loadString(data, 0, data.length)
		},
		//硬件版本
		getHardwareVersion: {
			req: {
				cmdType: _ => '02 06'
			},
			res: data => loadString(data, 0, data.length)
		},
		//软件版本
		getSoftwareVersion: {
			req: {
				cmdType: _ => '02 07'
			},
			res: data => loadString(data, 0, data.length)
		},
		//获取白板编号
		getWhiteBoardSN: {
			req: {
				cmdType: _ => '02 0c'
			},
			res: data => loadString(data, 0, data.length)
		},
		//校正
		doCalibrate: {
			req: {
				cmdType: _ => '01 03',
				data: {
					args: [0],
					pre: pre => requestByByteFlag(pre, TS_CALIBRATE)
				}
			},
			res: data => loadString(data, 0, data.length)
		},
		//测量
		doMeasure: {
			req: {
				cmdType: _ => '01 04',
				data: {
					args: [0],
					pre: pre => requestByByteFlag(pre, TS_MEASURE_TYPE)
				}
			},
			res: (data, cmd, cache, args) => {
				// console.log(`{data,cmd,cache,args}:${JSON.stringify({data,cmd,cache,args})}`);
				let type = args[0];
				console.log(`type:${JSON.stringify(type)}`);
				if (type == TS_MEASURE_TYPE.MEASURE_TRIAL) {
					return loadSampleResInTs(data)
				} else {
					//标样测量数据
					return loadStandardResInTs(data)
				}
			}
		}
	}
}



/**
 * ts协议标样测量数据
 */
function loadStandardResInTs(buffer) {
	let data = (buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer));
	let offset = 0;
	let u16Cut = loadUint16({
		buffer: data
	});
	// console.log(`u16Cut=>${JSON.stringify(u16Cut)}`);
	let u16FlagsValue = new Uint16Array([u16Cut[0]]);
	let flags = loadUintArrayByFlag(u16FlagsValue, TS_U16FLAG);
	offset += 2;
	let observer = loadByte(data, offset++, 1)[0];
	let illuminant = loadByte(data, offset++, 1)[0];
	let id = loadInt(data, offset, 1)[0];
	offset += 4;
	let name = loadString(data, offset, TS_RECORD_NAME_LENGTH);
	offset += TS_RECORD_NAME_LENGTH;
	let time = ts_loadDateTime(data, offset);
	offset += TS_DATETIME_LENGTH;
	// console.log(`offset:${JSON.stringify(offset)}`);

	let record = loadRecordData(data.slice(offset));

	let result = {
		measureType: TS_MEASURE_TYPE.MEASURE_STANDARD,
		// reflectType: flags.OPTICAL_MODE, //0 ['OPTICAL_REF', 'OPTICAL_TRA'],
		// sciMode: flags.SC_MODE, // 1-2: SCI/SCE, {0：SCI  1：SCE  2：SCI+SCE}
		// uvMode: flags.UV_MODE, //3-4: ['UV_NONE', 'UV_400', 'UV_420'],
		// diameter: flags.CALIBER, //5-7: 口径号 ['PHI_4', 'PHI_8', 'PHI_AUTO'],
		// resType: flags.DATA_TYPE, // 8-9: 为0表示sci、sce反射率数据（当测量命令要求传反射率数据，此标志位值为0）1表示用户输入的反射率数据, 2表示Lab数据，（当测量命令要求传Lab数据，此标志位值为2）3表示XYZ数据（当测量命令要求传XYZ数据，此标志位值为3）
		standardId: id,
		name,
		// time,
		// lenPos: flags.LENS_POS,
		// opticalStructureType: flags., // 14-15: 光路结构标志 0表示d/8, 1表示8/d, 2表示45/0此标志位优先级高于SCI/SCE（0-1）标志位，如果光路结构标志是45/0，只有一组反射率数据，则数据结构中第一组数据为45/0的数据
		// observer, // 观察者角度
		// illuminant, // 光源
		...record
	}
	console.log(`标样测量结果解析为:${JSON.stringify(result)}`);
	return result;

}

/**
 * 读取ts协议试样测量数据
 * @param {Uint8Array||Buffer} buffer 
 */
function loadSampleResInTs(buffer) {
	let data = (buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer));
	let offset = 0;
	let u16Cut = loadUint16({
		buffer: data
	});
	console.log(`u16Cut=>${JSON.stringify(u16Cut)}`);
	let u16FlagsValue = new Uint16Array([u16Cut[0]]);
	let flags = loadUintArrayByFlag(u16FlagsValue, TS_U16FLAG);
	offset += 2;
	let observer = loadByte(data, offset++, 1)[0];
	let illuminant = loadByte(data, offset++, 1)[0];
	let id = loadInt(data, offset, 1)[0];
	offset += 4;
	let name = loadString(data, offset, TS_RECORD_NAME_LENGTH);
	offset += TS_RECORD_NAME_LENGTH;
	let time = ts_loadDateTime(data, offset);
	offset += TS_DATETIME_LENGTH;
	let standardId = loadInt(data, offset, 1)[0];
	offset += 4;
	// console.log(`offset:${JSON.stringify(offset)}`);

	let record = loadRecordData(data.slice(offset));

	let result = {
		measureType: TS_MEASURE_TYPE.MEASURE_TRIAL,
		// reflectType: flags.OPTICAL_MODE, //0 ['OPTICAL_REF', 'OPTICAL_TRA'],
		// sciMode: flags.SC_MODE, // 1-2: SCI/SCE, {0：SCI  1：SCE  2：SCI+SCE}
		// uvMode: flags.UV_MODE, //3-4: ['UV_NONE', 'UV_400', 'UV_420'],
		// diameter: flags.CALIBER, //5-7: 口径号 ['PHI_4', 'PHI_8', 'PHI_AUTO'],
		// resType: flags.DATA_TYPE, // 8-9: 为0表示sci、sce反射率数据（当测量命令要求传反射率数据，此标志位值为0）1表示用户输入的反射率数据, 2表示Lab数据，（当测量命令要求传Lab数据，此标志位值为2）3表示XYZ数据（当测量命令要求传XYZ数据，此标志位值为3）
		standardId,
		sampleId: id,
		name,
		// time,
		// lenPos: flags.LENS_POS,
		// observer, // 观察者角度
		// illuminant, // 光源
		...record
	}
	console.log(`试样测量结果解析为:${JSON.stringify(result)}`);
	return result;
}



//将反射光谱数组增加到指定长度(32)
function decorateSpectrum(spectrum, length = 32) {
	if (spectrum && spectrum.length > 30 && length > spectrum.length) {
		let len = spectrum.length;
		for (var i = len; i < length; i++) {
			spectrum.push(spectrum[len - 1]);
		}
	}
	return spectrum;
}

function loadRecordData(buffer, sc_mode = SC_MODE.SCI, decorate = false) {
	// console.log(
	// 	`loadRecordData为:${JSON.stringify(uint8ArrayToHex(buffer,' '))}`
	// );
	// console.log(`buffer:${JSON.stringify(buffer)}`);
	let dataArr1 = loadFloatByUnsignedShort({
		buffer,
		index: VALID_WAVE_NUM
	});
	let dataArr2 = loadFloatByUnsignedShort({
		buffer,
		index: VALID_WAVE_NUM,
		offset: VALID_WAVE_NUM * 2
	});
	if (decorate) {
		dataArr1 = decorateSpectrum(dataArr1);
		dataArr2 = decorateSpectrum(dataArr2);
	}
	let dataRemain = getSubUint8Array(buffer, VALID_WAVE_NUM * 4);
	// console.log(`dataRemain:${JSON.stringify(dataRemain)}`);
	if (sc_mode === SC_MODE.SCI_AND_SCE) {
		return {
			dataArr1,
			dataArr2,
			// tolerance
		}
	} else if (sc_mode === SC_MODE.SCI) {
		return {
			dataArr1,
			// tolerance
		}
	} else {
		return {
			dataArr1: dataArr2,
			// tolerance
		}
	}

}

function loadFloatByUnsignedShort({
	buffer,
	index = 1,
	offset = 0
} = {}) {
	let data = (buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer.buffer));
	let dataRemain = data.slice(offset);
	let arr = [];
	let num = 0.0;
	for (let i = 0; i < index; ++i) {
		let u8Array = dataRemain.slice(0, 2);
		let num = parseInt(u8Array[0].toString()) + (parseInt(u8Array[1].toString()) << 8);
		// console.log('num=>', num);
		arr.push(num / 100);
		dataRemain = dataRemain.slice(2);
	}
	return arr;
}




function ts_loadDateTime(buffer, offset) {
	let data = (buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer));
	data = data.slice(offset);
	let year = loadUint16(data, 0, 1);
	let bytes = loadByte(data, 2, 6);
	let dateTime =
		`${String(year).padStart(4,'0')}-${String(bytes[0]).padStart(2,'0')}-${String(bytes[1]).padStart(2,'0')} ${String(bytes[2]).padStart(2,'0')}:${String(bytes[3]).padStart(2,'0')}:${String(bytes[4]).padStart(2,'0')}`;
	// console.log(`dateTime:${JSON.stringify(dateTime)}`);
	return dateTime;
}
