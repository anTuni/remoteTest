/**
 * author: LiHan
 * description: 蓝牙中常量与枚举
 * @createTime: 2022-05-05 11:35:40
 */
//Ts协议测量记录名称长度
export const VALID_WAVE_BEGIN = 400;
export const VALID_WAVE_END = 700;
export const VALID_WAVE_STEP = 10;
export const VALID_WAVE_NUM = ((VALID_WAVE_END - VALID_WAVE_BEGIN) / VALID_WAVE_STEP + 1); // 31
//蓝牙uuid特征码
export const TNH_BLE_UUID = '0000E0FF-3C17-D293-8E48-14FE2E4DA212'

//含光方式
export const SC_MODE = Object.freeze({
	'SCI': 0,
	'SCE': 1,
	'SCI_AND_SCE': 2
})
//反射/透射
export const OPTICAL_MODE = Object.freeze({
	'OPTICAL_MODE_REF': 0, // 反射
	'OPTICAL_MODE_TRA': 1, // 透射
})
//测量口径
export const CALIBER = Object.freeze({
	'PHI_4': 0, // 4mm
	'PHI_8': 1, // 8mm
	'PHI_15': 2, // 15mm
	'PHI_25': 3 // 25.4mm
})
// 透镜位置
export const LENS_POS = Object.freeze({
	'LENS_POS_4': 0, // 4mm
	'LENS_POS_8': 1, // 8mm
	'LENS_POS_15': 2, // 15mm
	'LENS_POS_25': 3, // 25.4mm
	// LENS_POS_NUM,
	// INVALID_LENS_POS,
})
//透镜工作模式
export const LENS_MODE = Object.freeze({
	'LENS_MODE_AUTO': 0, // 自动模式，透镜随口径同步切换
	'LENS_MODE_MANUAL': 1, // 手动模式，透镜位置需要设置
})
// UV模式
export const UV_MODE = Object.freeze({
	'UV_CUT_NONE': 0,
	'UV_CUT_400': 1,
	'UV_CUT_420': 2,
	'UV_CUT_460': 3,
})
// //记录中保存的数据类型
// export const RECORD_DATA_TYPE = Object.freeze({
// 	'RECORD_DATA_TYPE_REF': 0, // 反射率数据
// 	'RECORD_DATA_TYPE_USER': 1, // 用户输入数据，只保存xyz格式
// })

//存储模式 big-endian、little-endian
export const ENDIAN_TYPE = Object.freeze({
	'LITTLE_ENDIAN': 0, // 小端模式
	'BIG_ENDIAN': 1 // 大端模式
})

export const OBSERVER = Object.freeze({
	'2°': 0, //CIE1931
	'10°': 1 //CIE1964
})



// 校正
export const CALIBRATE = Object.freeze({
	'CALIBRATE_BLACK': 0, //黑校
	'CALIBRATE_WHITE': 1 //白校
})



// 数据类型
export const DATA_TYPE = Object.freeze({
	'SPECTRUM': 0, //反射光谱
	'LAB': 1, //Lab值
	'XYZ': 2 //xyz值
})

//=================标志位======================

/**
 * 协议响应校验结果
 */
export const CHECK_RESULT = Object.freeze({
	'PENDING': 0, //待定
	'RESOLVE': 1, //校验成功
	'REJECT': 2 //校验失败
})

export const MEASURE_TYPE = Object.freeze({
	'MEASURE_STANDARD': 0, //标样测量
	'MEASURE_TRIAL': 1 //试样测量
})

export const RESPONSE_TYPE = Object.freeze({
	'NOTIFICATION': 0,//设备通知
	'RETURN': 1//请求的响应
})