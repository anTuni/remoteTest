/**
 * author: LiHan
 * description: 蓝牙命令执行器的工厂方法
 * @createTime: 2022-07-03 09:45:38
 */
"use strict"
import {
	CHECK_RESULT,
	RESPONSE_TYPE
} from '../static/constant.js'
import {
	uint8ArrayToHex
} from '../utils/utils.js'
import {
	ts_notificationParser
} from '../static/ts_protocol.js'

import store from '@/store/index.js';

/**
 * executorFactory根据command对象生成executor对象的工厂方法:command=>{cmd,req,res}
 * 蓝牙响应的执行工厂方法
 * @return {Function} 返回executorFactory工厂方法的生产者
 */
export default function executorFactoryProducer() {
	// 用于缓存命令的请求入参供响应解析时使用
	// (不考虑并行蓝牙读取的话，可以用同一个executorFactory生产所有executor,从而让所有executor对象共用一个reqArgsCache缓存)
	let reqArgsCache = null;
	// 响应请求的方式
	let resType = RESPONSE_TYPE.NOTIFICATION;
	let setResponseType = function(responseType) {
		if (resType != responseType) {
			resType = responseType
			console.log(`resType被设置为:${JSON.stringify(responseType)}`);
		}
	}
	/**
	 * 请求执行方法的工厂函数
	 * @param {Object} command 
	 * 
	 */
	function requestExecutorFactory(command) {
		let cache = {},
			req = {
				...command.req
			};
		//按照 1.phase 2.index优先级来对字段进行排序
		let fieldsEntries = Object.entries(req).sort((entryA, entryB) => {
			let fieldA = entryA[1],
				fieldB = entryB[1],
				phaseA = fieldA.phase || 0,
				phaseB = fieldB.phase || 0;
			if (phaseA - phaseB != 0) {
				return phaseA - phaseB
			} else {
				return fieldA.index - fieldB.index
			}
		});

		/**
		 * 根据字段信息和输入参数来生成该字段的字节码
		 * @param {Object} field 
		 * @param {Array} inputArgs 
		 */
		function fieldExecutor(field, inputArgs) {
			let fieldResult = new Uint8Array(0);
			let {
				pre,
				handler,
				after
			} = field; //获取字段的处理函数
			let args = inputArgs;
			//依次处理函数
			[pre, handler, after].forEach(fun => {
				if (fun) {
					fieldResult = fun.apply(field, args);
					//上游方法的结果+req+cache作为下游方法的参数
					args = [fieldResult, command, cache];
				}
			})
			console.log(`fieldResult:${JSON.stringify(fieldResult)}`);
			return fieldResult;
		}
		//组装请求
		function assembleRequest() {
			//把cache中的字段按照index顺序进行排序
			let cacheSort = Object.entries(cache).sort((a, b) => req[a[0]].index - req[b[0]].index).map(e => e[1]);
			// console.log(`cacheSort:${JSON.stringify(cacheSort)}`);
			//排好序的字段进行组装
			let casheAssemble = cacheSort.reduce((pre, cur) => new Uint8Array([...pre, ...cur]), new Uint8Array(0));
			return new Uint8Array([...casheAssemble]);
		}

		return function() {
			let args = Array.from(arguments);
			// console.log(`args:${JSON.stringify(args)}`);
			//缓存请求入参
			if (args.length) {
				reqArgsCache = [...args];
			}
			cache = {};
			//按照请求字段的phase/index顺序来依次生成然后按index前后顺序进行拼接
			for (let entry of fieldsEntries) {
				let inputArgs = [],
					[fieldName, field] = entry;
				console.log(`field:${JSON.stringify(field)}`);

				//字段需要外部输入参数来确定
				if (field.args && field.args.length) {
					inputArgs = args.filter((_, index) => field.args.includes(index));
				}
				inputArgs = inputArgs && inputArgs.length ? [inputArgs, command, cache] : [null, command, cache];
				// console.log(`inputArgs:${JSON.stringify(inputArgs)}`);

				cache[fieldName] = fieldExecutor(field, inputArgs);
			}
			let requestArray = assembleRequest();
			// store.commit('logs/ADDINTERVAL');
			let logReq = '请求为:' + uint8ArrayToHex(requestArray, ' ').toUpperCase();
			// store.commit('logs/ADDBLELOG', logReq);
			console.log(logReq);
			return requestArray.buffer;
		}
	}
	/**
	 * 响应执行方法的工厂函数
	 * @param {Object} command 
	 * @param {Function} executor 读取响应的方法,可接受形如
				{
					buffer,//每次新读取的数据
					reqArgs,//请求的入参
					success(res),
					fail(err),
					complete
				}的参数;如果回调方法success, fail , complete均没有赋值,则返回promise,可通过promise.then(res=>{},err=>{})方式调用
	 */
	function responseExecutorFactory(command) {
		// console.log(`command:${JSON.stringify(command)}`);
		// console.log(`typeof command.res.chk:${JSON.stringify(typeof command.res.chk)}`);

		let res = {
				...command.res
			},
			{
				chk,
				pre,
				handler,
				after
			} = res;
		let cache = new Uint8Array(0); //保存读取响应数据的缓存
		let flag = false; //确保回调函数每次命令周期只赋值一次
		let onSuccess = null,
			onFail = null,
			_promise = null,
			requestArgs = null;
		const init = function() {
			cache = new Uint8Array(0);
			flag = false;
			requestArgs = null;
			_promise = new Promise((resolve, reject) => {
				onSuccess = function() {
					// try {
					//收到为响应时
					let result = null;
					console.log(`当前收到响应类型为:${JSON.stringify(resType?'return':'notification')}`);

					if (resType == RESPONSE_TYPE.RETURN) {
						//读取响应数据
						//格式化resHandler的初始参数 (cache, command, cache, [requestArgs])
						//requestArgs为命令请求的入参,少数命令请求入参会影响响应的解析(eg.TS协议试样/标样的解析格式有所区别)
						let inputArgs = null;
						if (requestArgs && requestArgs.length) {
							inputArgs = [cache, command, cache, requestArgs]
						} else {
							inputArgs = [cache, command, cache]
						}
						[pre, handler, after].forEach(fun => {
							if (fun) {
								result = fun.apply(null, inputArgs);
								console.log(`result:${JSON.stringify(result)}`);
								//上游handler方法的结果result+command+cache[+requestArgs]作为下游handler方法的参数
								if (requestArgs && requestArgs.length) {
									inputArgs = [result, command, cache, requestArgs];
								} else {
									inputArgs = [result, command, cache]
								}
							}
						})
						// 响应校验成功 重置请求入参缓存
						reqArgsCache = null;
						//响应校验成功,则将响应类型重置为NOTIFICATION
						setResponseType(RESPONSE_TYPE.NOTIFICATION);
						if (result !== null) {
							result = {
								resType: RESPONSE_TYPE.RETURN,
								data: result
							}
						}
					} else {
						//当读取为设备主动notify的指令时
						result = ts_notificationParser(cache);
						if (result !== null) {
							result = {
								resType: RESPONSE_TYPE.NOTIFICATION,
								data: result
							}
						}
						console.log(`result:${JSON.stringify(result)}`);
					}
					resolve(result)
				};
				onFail = function() {
					// 响应校验成功 重置请求入参缓存
					reqArgsCache = null;
					//校验失败，返回失败时缓存数据
					reject({
						error: {
							errMsg: '数据校验失败,响应读取有误',
						},
						cache
					})
				}
			});
		};
		init();
		return option => {
			let {
				buffer,
				success,
				fail,
				complete
			} = option || {};
			if (buffer) {
				store.commit('bluetooth/SETLOADING', true);
				let data = (buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer));
				// console.log('data=>', uint8ArrayToHex(data, ' ').toUpperCase());
				//移动端的响应回调方法(eg:uni.onBLECharacteristicValueChange(func))一次读取的响应数据长度有限，不一定能一次回调就读完所有响应，需要缓存在cache中
				//如果cache中有缓存数据，则合并数据以后进行校验
				cache = (cache.length ? new Uint8Array([...cache, ...data]) : new Uint8Array([...data]));
			}
			// console.log('cache=>', uint8ArrayToHex(cache, ' ').toUpperCase());
			//如果本次命令周期还没有赋值回调函数，则在闭包的promise中保存回调信息
			let asyncFlag = success || fail || complete;
			if (asyncFlag) {
				if (!flag) {
					flag = true;
					_promise = _promise.then(res => {
						let resLog = (resType == RESPONSE_TYPE.NOTIFICATION ? '上传数据' : '响应命令');
						if (resType == RESPONSE_TYPE.RETURN) {
							resLog += command.name
						}
						resLog += `结果为:${JSON.stringify(res)}`;
						// store.commit('logs/ADDBLELINE', resLog);
						console.log(resLog);
						if (success) {
							success(res);
						}
					}, err => {
						if (fail) {
							fail(err);
						}
					}).finally(() => {
						if (complete) {
							complete();
						}
					})
				}
			}
			let promise = _promise;
			let chkResult = chk(cache);
			console.log(`chkResult:${JSON.stringify(chkResult)}`);
			let logRes = '';
			if (chkResult === CHECK_RESULT.RESOLVE) {
				//如果验证成功，则本条命令响应读取结束
				logRes = '校验成功:' + uint8ArrayToHex(cache, ' ').toUpperCase();
				// store.commit('logs/ADDBLELOG', logRes);
				if (reqArgsCache && reqArgsCache.length) {
					requestArgs = [...reqArgsCache];
				}
				onSuccess();
				//重置状态
				init();
				store.commit('bluetooth/SETLOADING');
			} else if (chkResult === CHECK_RESULT.REJECT) {
				logRes = '校验失败:' + uint8ArrayToHex(cache, ' ').toUpperCase();
				// store.commit('logs/ADDBLELOG', logRes);
				//如果校验失败
				onFail();
				init();
				store.commit('bluetooth/SETLOADING');
			}
			if (!asyncFlag) {
				//如果success, fail , complete均没有赋值,则返回promise
				return promise;
			}
		};
	}

	return command => ({
		cmd: command,
		req: requestExecutorFactory(command),
		res: responseExecutorFactory(command),
		setResponseType
	})
}
