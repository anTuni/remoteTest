/**
 * author: LiHan
 * description: 蓝牙命令类,用于获取发送的二进制码和验证,解析响应
 * @createTime: 2022-05-06 10:32:24
 */

import {
	isPlainObject,
	isFunction
} from '../../utils/utils.js'
import clone from '../../utils/clone.js'
import {
	protocols
} from '../static/protocols.js'
import {
	deepMerge
} from '../../utils/utils.js'
import executorFactoryProducer from './executorFactoryProducer.js'

// import requsetExecutorFactory from './requestExecutorFactory.js'
// import responseExecutorFactory from './responseExecutorFactory.js'
// import logs from '../../../store/modules/logs.js'

export default class Command {

	constructor(myProtocols = []) {
		if (!Array.isArray(myProtocols)) {
			console.warn('Command构造函数中添加协议参数应为一个数组')
		}
		console.log(`protocols:${JSON.stringify(protocols)}`);

		this._protocols = [...protocols, ...myProtocols];
		this.instance = null;
		let protos = this._protocols;
		//1.读取设备或者产品系列都有的协议设定
		// protocols=mergeProtocol(this.protocols,userProtocols);
		let result = {};
		let executorFactory = executorFactoryProducer();
		for (let proto of protos) {
			// console.log(`typeof proto.defaults.res.chk:${JSON.stringify(typeof proto.defaults.command.res.chk)}`);

			//2.将proto中可能的简化写法转换为标准写法
			proto = formatProtocol(proto)
			// console.log(`proto:${JSON.stringify(proto)}`);
			//3.初始化协议设定,读取defaults中的默认设置
			proto = loadDefaults(proto);
			let {
				name,
				defaults,
				req,
				command
			} = proto;
			//按协议名称name来储存协议的信息
			if (!result[name]) {
				result[name] = {}
			}
			//3.遍历命令数组获取命令对象
			for (let cmdEntry of Object.entries(command)) {
				let [cmdName, cmd] = cmdEntry;
				// console.log(`cmd.req:${JSON.stringify(cmd.req)}`);
				let request = deepMerge(req, cmd.req);
				// console.log(`request:${JSON.stringify(request)}`);
				let command = {
					name: cmdName,
					req: request,
					res: cmd.res
				};
				// console.log(`req:${JSON.stringify(req)}`);
				// let reqExecutor = requsetExecutorFactory(command);
				// let resExecutor = responseExecutorFactory(command);
				// result[name][cmdName] = {
				// 	cmd: command,
				// 	req: reqExecutor,
				// 	res: resExecutor
				// };
				result[name][cmdName] = executorFactory(command);
			}
		}
		this.executor = result;
	}
	static getInstance(myProtocols = []) {
		if (!this.instance) {
			this.instance = new Command(myProtocols = []);
		}
		return this.instance;
	}
}

Command.prototype.getExecutor = function(protocolType) {
	return (protocolType ? this.executor[protocolType] : this.executor);
}



/**
 * 将协议可能的简写模式转换为标准模式
 * @param {Object} protocol 
 */
function formatProtocol(protocol) {
	for (let cmdEntry of Object.entries(protocol.command || [])) {
		let [cmdName, cmd] = cmdEntry;
		//req中的字段如果只含有一个方法，默认为pre方法
		//eg: 把req:{${fieldName}:fun}解析为req:{${fieldName}:{pre:fun}}
		let reqEntries = Object.entries(cmd.req);
		for (let fEntry of reqEntries) {
			let [fieldName, field] = fEntry;
			if (isFunction(field)) {
				cmd.req[fieldName] = {
					pre: field
				}
				// console.log(`cmd.req:${JSON.stringify(cmd.req)}`);
			}
		}
		//res字段如果只含有一个方法，默认为hanlder方法
		//eg:把res:fun 解析为res:{handler:fun}
		if (isFunction(cmd.res)) {
			cmd.res = {
				handler: cmd.res
			}
		}
	}
	return protocol;
}


/**
 * 读取协议的默认设置,默认设置对象中的key:val对设定如下:
 * val为protocol对象中key属性下的所有子属性的默认属性值。
 * eg:defaults: {
		req: {
			endian: ENDIAN_TYPE.LITTLE_ENDIAN
		}}表示protocol中req属性中所有字段[cmdType,len,data]都有默认的属性和值endian: ENDIAN_TYPE.LITTLE_ENDIAN
 * @param {Object} protocol 
 * @param {Object} defaults 
 */
function loadDefaults(protocol, defaults) {
	if (!defaults && protocol.defaults) {
		defaults = protocol.defaults;
	}
	if (!defaults) {
		return
	}
	for (let key in defaults) {
		if (hasOwnProperty(defaults, key) && hasOwnProperty(protocol, key)) {
			console.log(`key:${JSON.stringify(key)}`);
			let mergeProp = setDefaultConfig(protocol[key], defaults[key]);



			protocol[key] = mergeProp;
		}
	}
	// console.log(`protocol:${JSON.stringify(protocol)}`);
	return protocol;
}

/**
 * 是否有属性名为propName的枚举属性
 * @param {Object} obj 
 * @param {String} propName 
 */
function hasOwnProperty(obj, propName) {
	return Object.prototype.hasOwnProperty.call(obj, propName)
}
/**
 * 对目标tar的子属性字段field，用defaults作为field的默认属性进行深融合
 * @param {Object} tar 
 * @param {Object} defaultConfig 
 */
function setDefaultConfig(tar,
	defaultConfig) {
	let result = {};
	for (let entry of Object.entries(tar)) {
		//获取tar的子属性字段名称和子属性字段
		let [fieldName, field] = entry;
		// console.log(`fieldName:${JSON.stringify(fieldName)}`);
		//将default中的属性作为默认属性
		let mergeProp = deepMerge(defaultConfig, field);
		if (mergeProp.res) {
			// console.log(`mergeProp:${JSON.stringify(mergeProp)}`);
			// console.log(`typeof mergeProp.res.chk:${JSON.stringify(typeof mergeProp.res.chk)}`);
		}

		result[fieldName] = mergeProp;
	}
	return result;
}
