/**
 * author: LiHan
 * description: 通过类似建造者的模式来进行响应解析的解析类
 * @createTime: 2022-07-03 17:13:45
 */

export default class ParserBuilder {


	constructor(uArray, offset = 0, result = {}) {
		this._uArray = uArray;
		this.offset = offset;
		this.result = result;
	}

}
/**
 * 要求names数组长度等于n或者等于1，等于1且n>1表示为数组名称
 * @param {Function} convertFun 
 * @param {Array} names 
 * @param {Number} n 
 */
ParserBuilder.prototype.parse = function(convertFun, len, names, n = 1) {
	if (names.lenth > n) {
		throw new Error('parse times n should  outnumber names');
		return this;
	}
	if(Array.isArray(names)&& names.length===1&&n>1){
		this.result[names[0]]=[];
	}
	for (let i = 0; i < n; i++) {
		let name = ('string' === typeof names ? names : names[i]);
		this.result[name]=convertFun(this._uArray, this.offset);
		this.offset += len;
	}
	return this;

}
