/**
 * author: LiHan
 * description: 协议命令的定义
 * @createTime: 2022-05-02 06:47:53
 */

//TS协议命令
export const TsCommands = {
	//是否校正
	isCalibrated: {
		req: {
			cmdType:{
				pre:_=>'02 00'
			}
		}
	},
	//获取标样总数
	getStandardAmount: {
		req: {
			cmdType:{
				pre:_=>'02 01'
			}  
		}
	},
	//获取试样总数
	getSampleAmount: {
		req: {
			cmdType:{
				pre:_=>'02 02'
			} 
		}
	},
	//仪器型号
	getInstrumentModel: {
		req: {
			cmdType:{
				pre:_=>'02 03'
			}  
		}
	},
	//获取仪器序列号
	getSerialNumber: {
		req: {
			cmdType:{
				pre:_=>'02 04'
			}  
		}
	},
	//硬件版本
	getHardwareVersion: {
		req: {
			cmdType:{
				pre:_=>'02 06'
			}  
		}
	},
	//软件版本
	getSoftwareVersion: {
		req: {
			cmdType:{
				pre:_=>'02 07'
			}  
		}
	},
	//获取光学结构
	getOpticalStructure: {
		req: {
			cmdType:{
				pre:_=>'02 0b'
			}  
		}
	},
	//获取白板编号
	getWhiteBoardSN: {
		req: {
			cmdType:{
				pre:_=>'02 0c'
			}  
		}
	},
	//获取白板反射率
	getWhiteBoardReflectance: {
		req: {
			cmdType:{
				pre:_=>'02 0d'
			}  
		}
	},
	//获取标准光源设置
	getIlluminant: {
		req: {
			cmdType:{
				pre: _=>'02 0e'
			} 
		}
	},
	//获取标准观察者设置
	getObserver: {
		req: {
			cmdType:{
				pre:_=>'02 0f'
			}  
		}
	},
	//获取口径设置
	getCaliber: {
		req: {
			cmdType:{
				pre:_=>'02 10'
			}  
		}
	},
	//获取SC模式设置
	getScMode: {
		req: {
			cmdType:{
				pre:_=>'02 11'
			}  
		}
	},
	//获取颜色空间设置
	getColorSpace: {
		req: {
			cmdType:{
				pre:_=>'02 12'
			}  
		}
	},
	//获取颜色指数设置
	getColorIndex: {
		req: {
			cmdType:{
				pre:_=>'02 13'
			}  
		}
	},
	//获取色差公式设置
	getColorDiffFormula: {
		req: {
			cmdType:{
				pre:_=>'02 14'
			}  
		}
	},
	//获取容差设置
	getTolerance: {
		req: {
			cmdType:{
				pre:_=>'02 15'
			}  
		}
	},
	//获取仪器当前时间
	getDateTime: {
		req: {
			cmdType:{
				pre:_=>'02 16'
			}  
		}
	},
	//设置白板编号
	setWhiteBoardSN: {
		req: {
			cmdType:{
				pre:_=>'02 17'
			}  
		}
	},
	//设置白板反射率
	setWhiteBoardReflectance: {
		req: {
			cmdType:{
				pre:_=>'02 18'
			}  
		}
	},
	//设置标准光源
	setIlluminant: {
		req: {
			cmdType:{
				pre: _=>'02 19'
			} 
		}
	},
	//设置标准观察者
	setObserver: {
		req: {
			cmdType:{
				pre:_=>'02 1a'
			}  
		}
	},
	//设置口径类型
	setCaliber: {
		req: {
			cmdType:{
				pre:_=>'02 1b'
			}  
		}
	},
	//设置SC模式
	setScMode: {
		req: {
			cmdType:{
				pre:_=>'02 1c'
			}  
		}
	},
	//设置颜色空间
	setColorSpace: {
		req: {
			cmdType:{
				pre:_=>'02 1d'
			}  
		}
	},
	//设置颜色指数
	setColorIndex: {
		req: {
			cmdType:{
				pre:_=>'02 1e'
			}  
		}
	},
	//设置色差公式
	setColorDiffFormula: {
		req: {
			cmdType:{
				pre:_=>'02 1f'
			}  
		}
	},
	//设置仪器时间
	setDateTime: {
		req: {
			cmdType:{
				pre:_=>'02 21'
			}  
		}
	},
	//获取uv模式
	getUVMode: {
		req: {
			cmdType:{
				pre:_=>'02 22'
			}  
		}
	},
	//设置uv模式
	setUVMode: {
		req: {
			cmdType:{
				pre:_=>'02 23'
			}  
		}
	},
	//告知仪器已连接
	notifyConnect: {
		req: {
			cmdType:{
				pre:_=>'01 01'
			}  
		}
	},
	//告知仪器断开连接
	notifyDisconnect: {
		req: {
			cmdType:{
				pre:_=>'01 02'
			}  
		}
	},
	//校正
	doCalibrate: {
		req: {
			cmdType:{
				pre:_=>'01 03'
			}  
		}
	},
	//测量
	doMeasure: {
		req: {
			cmdType:{
				pre:_=>'01 04'
			}  
		}
	},
	//获取标样关联的试样个数
	getRelatedSampleAmount: {
		req: {
			cmdType:{
				pre: _=>'01 05'
			} 
		}
	},
	//上传标样
	uploadStandard: {
		req: {
			cmdType:{
				pre:_=>'01 06'
			}  
		}
	},
	//上传试样
	uploadSample: {
		req: {
			cmdType:{
				pre:_=>'01 07'
			}  
		}
	},
	//输入标样
	downloadStandard: {
		req: {
			cmdType:{
				pre:_=>'01 08'
			}  
		}
	},
	//删除标样
	deleteStandardByIndex: {
		req: {
			cmdType:{
				pre: _=>'01 09'
			} 
		}
	},
	//删除试样
	deleteSampleByIndex: {
		req: {
			cmdType:{
				pre: _=>'02 00'
			} 
		}
	},
}

//TS协议的响应命令枚举
export const TsResponse = {
	isCalibrated: '02 00', //是否校正
	getStandardAmount: '02 01', //获取标样总数
	getSampleAmount: '02 02', //获取试样总数
	getInstrumentModel: '02 03', //仪器型号
	getSerialNumber: '02 04', //获取仪器序列号
	getHardwareVersion: '02 06', //硬件版本
	getSoftwareVersion: '02 07', //软件版本
	getOpticalStructure: '02 0b', //获取光学结构
	getWhiteBoardSN: '02 0c', //获取白板编号
	getWhiteBoardReflectance: '02 0d', //获取白板反射率
	getIlluminant: '02 0e', //获取标准光源设置
	getObserver: '02 0f', //获取标准观察者设置
	getCaliber: '02 10', //获取口径设置
	getScMode: '02 11', //获取SC模式设置
	getColorSpace: '02 12', //获取颜色空间设置
	getColorIndex: '02 13', //获取颜色指数设置
	getColorDiffFormula: '02 14', //获取色差公式设置
	getTolerance: '02 15', //获取容差设置
	getDateTime: '02 16', //获取仪器当前时间
	setWhiteBoardSN: '02 17', //设置白板编号
	setWhiteBoardReflectance: '02 18', //设置白板反射率
	setIlluminant: '02 19', //设置标准光源
	setObserver: '02 1a', //设置标准观察者
	setCaliber: '02 1b', //设置口径类型
	setScMode: '02 1c', //设置SC模式
	setColorSpace: '02 1d', //设置颜色空间
	setColorIndex: '02 1e', //设置颜色指数
	setColorDiffFormula: '02 1f', //设置色差公式
	setDateTime: '02 21', //设置仪器时间
	getUVMode: '02 22', //获取uv模式
	setUVMode: '02 23', //设置uv模式
	notifyConnect: '01 01', //告知仪器已连接
	notifyDisconnect: '01 02', //告知仪器断开连接
	doCalibrate: '01 03', //校正
	doMeasure: '01 04', //测量
	getRelatedSampleAmount: '01 05', //获取标样关联的试样个数
	uploadStandard: '01 06', //上传标样
	uploadSample: '01 07', //上传试样
	downloadStandard: '01 08', //输入标样
	deleteStandardByIndex: '01 09', //删除标样
	deleteSampleByIndex: '02 00', //删除试样
}
