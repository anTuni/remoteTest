/**
 * author: LiHan
 * description: 读取响应和解析响应的工具类
 * @createTime: 2022-06-04 11:43:04
 */
import {
	ENDIAN_TYPE,
	TS_U16FLAG,
	TS_RECORD_NAME_LENGTH,
	VALID_WAVE_NUM
} from '../static/constant'
import {
	uint8ArrayToFloat32,
	uint8ArrayToHex
} from '@/common/ble/utils/utils.js'
import logs from '../../../store/modules/logs';
// import logs from '../../../store/modules/logs';

export function loadInt(data, start = 0, index = 1) {
	let buffer = (data instanceof Uint8Array ? data : new Uint8Array(data));
	let arr = [],
		v = 0;
	for (let i = 0; i < index; i++) {
		let sub = getSubUint8Array(buffer, start + 4 * i, 4);
		v = parseInt(sub.slice(0, 1).toString()) + (parseInt(sub.slice(1, 2).toString()) << 8) +
			(parseInt(sub.slice(2, 3).toString()) << 16) + (parseInt(sub.slice(3, 4).toString()) << 24);
		arr.push(v);
	}
	return arr;
}

export function getSubUint8Array(buffer, start = 0, len) {
	let data = (buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer));
	// console.log(`uint8ArrayToHex(data):${JSON.stringify(uint8ArrayToHex(data,' '))}`);
	return (len ? data.slice(start, start + len) : data.slice(start))
}

export function loadString(buffer, start = 0, index = 1, replace = ' ') {

	// console.log(`{start,index}:${JSON.stringify({start,index})}`);

	let charArray = loadCharArray(buffer, start, index);
	// console.log(`charArray:${JSON.stringify(charArray)}`);

	let result = '';
	// console.log(`res=>${JSON.stringify(res)}`);
	for (let char of charArray) {
		if (char != '\u0000') {
			result += char;
		} else {
			result += replace;
		}
	}
	// console.log(`result=>${JSON.stringify(result)}`);
	return result.trim();
}


export function loadCharArray(buffer, start = 0, index = 1) {
	let sub = getSubUint8Array(buffer, start, index);
	let charArray = [];
	let char = '';
	for (let i = 0; i < index; ++i) {
		char = String.fromCodePoint(sub.slice(i, i + 1));
		// console.log(`char:${JSON.stringify(char)}`);
		charArray.push(char);
	}
	return charArray;
}

/**
 * 读取Float类型响应数据
 * @param {Object} param0 
 */
export function loadFloat({
	buffer,
	start = 0,
	index = 1,
	// precision = 4,
	endian = ENDIAN_TYPE.LITTLE_ENDIAN
} = {}) {
	let data = (buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer));
	let arr = [];
	let num = 0.0;
	for (let i = 0; i < index; ++i) {
		// dataRemain.slice(0,4).forEach(e=>console.log(e));
		let float32 = 0;
		let u8Array = data.slice(start + 4 * i, start + 4 * (i + 1))
		if (endian) {
			u8Array = u8Array.reverse();
		}
		float32 = uint8ArrayToFloat32(u8Array);
		num = parseFloat(float32.toString());
		// console.log(`num:${JSON.stringify(num)}`);
		arr.push(num);
	}
	return arr;
}

export function loadFloatByUnsignedShort({
	buffer,
	start = 0,
	index = 1,
	endian = ENDIAN_TYPE.LITTLE_ENDIAN
}) {
	let data = (buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer));
	// let dataRemain = data.slice();
	let arr = [];
	let num = 0.0;
	for (let i = 0; i < index; ++i) {
		let short16 = data.slice(start + 2 * i, start + 2 * (i + 1));
		if (endian) {
			short16 = short16.reverse();
		}
		let num = parseInt(short16[0].toString()) + (parseInt(short16[1].toString()) << 8);
		// console.log('num=>', num);
		arr.push(num / 100);
	}
	return arr;
}

/**
 * 按Byte为单位读取响应字节码
 * @param {Uint8Array||Buffer} buffer 
 * @param {Int} start 
 * @param {Int} index 
 */
export function loadByte(buffer, start = 0, index = 1) {
	let data = (buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer));
	let arr = [],
		v = 0;
	for (let i = 0; i < index; ++i) {
		v = parseInt(data.slice(start + i, start + i + 1).toString());
		arr.push(v);
	}
	return arr
}


/**
 * 读取Uint16数据
 * @param {Object} param0 
 */
export function loadUint16({
	buffer,
	start = 0,
	index = 1,
	endian = ENDIAN_TYPE.LITTLE_ENDIAN
} = {}) {
	// console.log(`123:${JSON.stringify(123)}`);

	let data = (buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer));
	let dataRemain = data.slice();
	let arr = [];
	for (let i = 0; i < index; i++) {
		let subUint8Array = data.slice(start + 2 * i, start + 2 * (i + 1));
		let lowByte = subUint8Array[0],
			highByte = subUint8Array[1];
		// console.log(`{lowByte,highByte}:${JSON.stringify({lowByte,highByte})}`);
		let u16val = lowByte + (highByte << 8);
		if (endian) {
			u16val = (lowByte << 8) + highByte;
		}
		let uint16Array = new Uint16Array([u16val]);
		arr.push(parseInt(uint16Array.toString()))
	}
	// console.log(`arr:${JSON.stringify(arr)}`);

	return arr;
}





/**
 * 从uintXFlag按flag取标志位，返回的标志位解析后的对象
 * 
 * @param {UintArray} arr
 * @param {Object} Flag 
 * @returns {Object}
 */
export function loadUintArrayByFlag(arr, Flag) {
	console.log(`arr=>${JSON.stringify(arr)}`);
	// console.log(`flagArr=>${JSON.stringify(flagArr)}`);
	let v = parseInt(arr[0].toString());
	let result = {};
	for (let entry of Object.entries(Flag)) {
		let [name, info] = entry;
		let val = loadBitsFlag(v, info.start, info.len)
		result[name] = val;
	}
	return result;
}

/**
 * 从值为v的uintXFlag的序号为index的位置开始往高位（左边）取nbit的标志位，返回这个nbit长度标志位的值
 * @param {int} v 
 * @param {int} index 序号(从右到左递增)
 * @param {int} n 截取长度
 * @returns {number}
 */
export function loadBitsFlag(v, index = 0, n = 2) {
	return v >>> index & ((1 << n) - 1);
}



/**
 * 根据设定的标志对象来返回对应的设置标记字节
 * @param {String||Number} arg 
 * @param {Object} flagObj 
 */
export function requestByByteFlag(arg, flagObj) {
	console.log(`arg:${JSON.stringify(arg)}`);
	let input = Array.isArray(arg) ? arg[0] : arg;
	if ('number' === typeof input) {
		return new Uint8Array([input])
	} else if ('string' === typeof input && Object.hasOwnProperty(input)) {
		return new Uint8Array([flagObj[input]])
	}
	throw Error('未找到匹配的请求参数')
	return new Uint8Array(0)
}
/**
 * 使用32位模式数组来传递输入参数值,用最高位来代表是否使用序号(或者id)指定标样或者试样
 * @param {Number||TypeArray} value 表示输入参数的值
 * @param {Boolean} useIndex 是否使用序号（不使用序号则使用id来指定）
 */
export function requestByUint32Parameters(value, useIndex = 1) {
	// console.log(`value=>${JSON.stringify(value)}`);
	let u32 = new Uint32Array([0]);
	if ('number' === typeof value) {
		if (!useIndex) {
			value = value + (1 << 31);
		}
		u32 = new Uint32Array([value]);
	} else if (Array.isArray(value) && value.length) {
		u32 = new Uint32Array(value.length);
		for (let i = 0; i < value.length; i++) {
			let val = Number(value[i]);
			if (!useIndex) {
				val = val + (1 << 31);
			}
			u32[i] = val;
		}
	}
	return new Uint8Array(u32.buffer);
}
