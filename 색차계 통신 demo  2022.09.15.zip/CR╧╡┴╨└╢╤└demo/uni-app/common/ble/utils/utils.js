/**
 * author: LiHan
 * description: 蓝牙模块工具类
 * @createTime: 2022-05-01 14:43:20
 */


import {
	ENDIAN_TYPE
} from '../static/constant'


/**
 * 10进制值转换为32位相应大小端模式下的Uint8Array
 * @param {Number} n - 十进制的保存值
 * @param {Number} endian - 大小端存储
 */
export function uint32ToUint8Array(n, endian = ENDIAN_TYPE.LITTLE_ENDIAN) {
	if (endian) {
		return new Uint8Array(new Uint32Array([n]).buffer).reverse();
	} else {
		return new Uint8Array(new Uint32Array([n]).buffer)
	}
}



/**
 * 10进制值转换为16位相应大小端模式下的Uint8Array
 * @param {Number} n - 十进制的保存值
 * @param {Number} endian - 大小端存储
 */
export function uint16ToUint8Array(n, endian = ENDIAN_TYPE.LITTLE_ENDIAN) {
	if (endian) {
		return new Uint8Array(new Uint16Array([n]).buffer).reverse();
	} else {
		return new Uint8Array(new Uint16Array([n]).buffer)
	}
}

/**
 * 最多2位16进制字符串(0x${hexString})转为Uint8Array
 * @param {string} hexString - 格式类似`AA`的16进制字符串
 */
export function hex2Uint8Array(hexString) {
	return new Uint8Array(hexString.match(/.{1,2}/g).map(byte => parseInt(byte, 16)));
}

/**
 * 格式类似 `AA BB CC 11`的16进制字符串转为相应大小端的Uint8Array
 * @param {String} hexString - 格式类似 `AA BB`的16进制字符串
 * @param {Number} endian - 大小端存储
 */
export function hexString2Uint8Array(hexString, endian = ENDIAN_TYPE.LITTLE_ENDIAN) {
	let hexArray = hexString.split(' ');
	let u8Array = hexArray.map(e => hex2Uint8Array(e));
	if (endian) {
		u8Array = u8Array.reverse();
	}
	return new Uint8Array(u8Array.length).map((e, index) => u8Array[index]);

}

/**
 * uint8 数组转 hex 字符串
 * @param {Uint8Array} raw 
 * @param {String} joinStr 间隔字符
 */
export function uint8ArrayToHex(raw, joinStr = '') {
	const s = [];
	raw.forEach(i => {
		const b = i.toString(16);
		s.push(b.length > 1 ? b : `0${b}`);
	});
	return s.join(joinStr).toLowerCase();
}




/**
 * 4个Uint8 数组 转 Float32
 * @param {Uint8Array(4)} raw 
 */
export function uint8ArrayToFloat32(raw) {
	return new Float32Array(raw.buffer)[0];
}

export function uint8ArrayToDouble({
	data,
	offset = 0,
	endian = ENDIAN_TYPE.LITTLE_ENDIAN
} = {}) {
	let view = new DataView(new ArrayBuffer(8));
	data.slice(offset, offset + 8).forEach(function(b, i) {
		if (endian) {
			view.setUint8(i, b);
		} else {
			view.setUint8(7 - i, b);
		}
	});
	// console.log(`view.getFloat64():${JSON.stringify(view.getFloat64(0))}`);
	return view.getFloat64(0);
}


export function uint8ArrayToDoubles({
	data,
	offset = 0,
	index = 1,
	endian = ENDIAN_TYPE.LITTLE_ENDIAN
} = {}) {
	let arr = [];
	for (let i = 0; i < index; i++) {
		// console.log(`double${i}:=>${JSON.stringify(uint8ArrayToHex(data.slice(offset+i*8,offset+i*8+8)))}`);

		arr.push(uint8ArrayToDouble({
			data,
			offset: offset + i * 8,
			endian
		}));
	}
	return arr;
}
