/**
 * author: LiHan
 * description: 提供串行序列化的工具函数
 * @createTime: 2022-07-05 17:34:54
 */

import {
	ENDIAN_TYPE
} from '../static/constant'


export function serializeString(str, len = str.length, pad = '\u0000') {
	let result = new Uint8Array(len);
	for (let i = 0; i < len; i++) {
		if (i < str.length) {
			// console.log(`str[i]:${JSON.stringify(str[i])}`);
			result[i] = str.charCodeAt(i)
		} else {
			result[i] = pad.charCodeAt(0)
		}
	}
	// console.log(`result:${JSON.stringify(result)}`);
	return result;
}

export function serializeFloat32(value, endian = ENDIAN_TYPE.LITTLE_ENDIAN) {
	let float32 = new Float32Array([value]);
	// let buffer=new ArrayBuffer(float32.byteLength);
	let cache = new Uint8Array(float32.buffer);
	let result = new Uint8Array(4);
	for (let i = 0; i < 4; i++) {
		result[i] = (endian ? (cache[3 - i] & 0xff): (cache[i] & 0xff) )
	}
	return result;
}
