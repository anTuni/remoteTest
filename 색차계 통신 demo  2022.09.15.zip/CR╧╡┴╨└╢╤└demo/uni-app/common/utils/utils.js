/**
 * author: LiHan
 * description: 公共的工具类
 * @createTime: 2022-05-03 07:04:46
 */

'use strict'
var toString = Object.prototype.toString

/**
 * Determine if a value is an Array
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an Array, otherwise false
 */
export function isArray(val) {
	return toString.call(val) === '[object Array]'
}


/**
 * Determine if a value is an Object
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an Object, otherwise false
 */
export function isObject(val) {
	return val !== null && typeof val === 'object'
}

/**
 * Determine if a value is a Date
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Date, otherwise false
 */
export function isDate(val) {
	return toString.call(val) === '[object Date]'
}

/**
 * Determine if a value is a URLSearchParams object
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a URLSearchParams object, otherwise false
 */
export function isURLSearchParams(val) {
	return typeof URLSearchParams !== 'undefined' && val instanceof URLSearchParams
}


/**
 * Iterate over an Array or an Object invoking a function for each item.
 *
 * If `obj` is an Array callback will be called passing
 * the value, index, and complete array for each item.
 *
 * If 'obj' is an Object callback will be called passing
 * the value, key, and complete object for each property.
 *
 * @param {Object|Array} obj The object to iterate
 * @param {Function} fn The callback to invoke for each item
 */
export function forEach(obj, fn) {
	// Don't bother if no value provided
	if (obj === null || typeof obj === 'undefined') {
		return
	}

	// Force an array if not already something iterable
	if (typeof obj !== 'object') {
		/*eslint no-param-reassign:0*/
		obj = [obj]
	}

	if (isArray(obj)) {
		// Iterate over array values
		for (var i = 0, l = obj.length; i < l; i++) {
			fn.call(null, obj[i], i, obj)
		}
	} else {
		// Iterate over object keys
		//hasOwnProperty只能判断是否是属于自身的属性，无法找到原型身上的属性（hasOwnProperty()只在属性存在于实例中时才返回true）
		// in原型身上的属性也能找到（in操作符只要通过对象能访问到属性就返回true）
		for (var key in obj) {
			if (Object.prototype.hasOwnProperty.call(obj, key)) {
				fn.call(null, obj[key], key, obj)
			}
		}
	}
}

/**
 * 是否为boolean 值
 * @param val
 * @returns {boolean}
 */
export function isBoolean(val) {
	return typeof val === 'boolean'
}

/**
 * 是否为 函数
 * @param val
 * @returns {boolean}
 */
export function isFunction(val) {
	return typeof val === 'function'
}


/**
 * 是否为真正的对象 new Object
 * @param {any} obj - 检测的对象
 * @returns {boolean}
 */
export function isPlainObject(obj) {
	return Object.prototype.toString.call(obj) === '[object Object]'
}

/**
 * Function equal to merge with the difference being that no reference
 * to original objects is kept.
 *	递归融合属性(考虑属性可能为函数,函数的话直接覆盖而不是继续迭代)
 * @see merge
 * @param {Object} obj1 Object to merge
 * @returns {Object} Result of all merge properties
 */
export function customizedDeepMerge( /* obj1, obj2, obj3, ... */ ) {
	let result = {}
	// 给result的key赋值val
	function assignValue(val, key) {
		//如果result中key已有值，则根据val值刷新属性
		if (typeof result[key] === 'object' && typeof val === 'object') {
			result[key] = deepMerge(result[key], val)
		} else if (typeof val === 'object') {
			result[key] = deepMerge({}, val)
		} else {
			result[key] = val
		}
	}
	for (let i = 0, l = arguments.length; i < l; i++) {
		forEach(arguments[i], assignValue)
	}
	return result
}




/**
 * Function equal to merge with the difference being that no reference
 * to original objects is kept.
 *	递归融合属性
 * @see merge
 * @param {Object} obj1 Object to merge
 * @returns {Object} Result of all merge properties
 */
export function deepMerge( /* obj1, obj2, obj3, ... */ ) {

	let result = {};
	// 给result的key赋值val
	function assignValue(val, key) {
		//如果key为数值，而result对象本身不为数值，则将result对象变为数组
		if ('number' === typeof key && !Array.isArray(result)) {
			// console.log(key)
			// console.log(`val:${JSON.stringify(val)}`);
			result = [];
		}
		//如果result[key]和val都为对象的话，进行递归融合调用
		if (typeof result[key] === 'object' && typeof val === 'object') {
			result[key] = deepMerge(result[key], val)
			//如果result[key]不为对象而val为对象的话，用val对象的深clone来替代key属性原本的值
		} else if (typeof val === 'object') {
			result[key] = deepMerge({}, val)
		} else {
			//如果result[key]和val都不为对象的话，直接进行覆盖
			result[key] = val
		}
	}
	for (let i = 0, l = arguments.length; i < l; i++) {
		// console.log(`arguments[i]:${JSON.stringify(arguments[i])}`);
		forEach(arguments[i], assignValue)
		// console.log(`result:${JSON.stringify(result)}`);
	}
	return result
}

export function isUndefined(val) {
	return typeof val === 'undefined'
}

export function getTime(date) {
	var time = (date == null ? new Date() : new Date(date));
	// let y = time.getFullYear();
	// let m = JoinZero(time.getMonth() + 1);
	// let d = JoinZero(time.getDate());
	let h = JoinZero(time.getHours());
	let mi = JoinZero(time.getMinutes());
	let s = JoinZero(time.getSeconds());
	return `${h}:${mi}:${s}`;
}

export function formatTime(time) {
	// console.log(`time:${JSON.stringify(time)}`);

	let date = new Date(time);
	let y = date.getFullYear();
	let m = String(date.getMonth() + 1).padStart(2, '0');
	let d = String(date.getDate()).padStart(2, '0');
	let h = String(date.getHours()).padStart(2, '0');
	let mi = String(date.getMinutes()).padStart(2, '0');
	let s = String(date.getSeconds()).padStart(2, '0');
	return `${y}-${m}-${d} ${h}:${mi}:${s}`
}

function JoinZero(num) {
	return num < 10 ? '0' + num : num;
}
