<template>
	<view class="flex-column-center content">
		<uni-section type="line" title="推荐用法">
			<view class="flex-column-center uni-common-mt">
				<button class="btn" size="mini" type="primary" @click="startScan">蓝牙搜索</button>
				<button v-if="isSearching" class="btn" size="mini" type="warn"
					@click="stopBluetoothDevicesDiscovery">停止搜索</button>
				<button v-if="connected" class="btn" size="mini" type="warn" @click="closeConnection">断开连接</button>
			</view>
		</uni-section>
		<view v-if="!connected">
			<view class="uni-common-pl uni-text uni-common-mt" v-if="devicesList.length">
				点击选择要连接的蓝牙设备:
			</view>
			<scroll-view class="device_list" scroll-y="true" show-scrollbar="true">
				<!-- <radio-group> -->
				<view v-for="(item,index) in devicesList" :key="item.deviceId" class="device_item" v-if="item.name">
					<view class="blueteeth-status" style="flex-grow: 1;">
						<view>{{item.name||'’'}}</view>
						<view style="font-size: 20rpx">信号强度: {{item.RSSI}}dBm ({{Math.max(100+item.RSSI,0)}}%)</view>
						<view style="font-size: 20rpx">deviceId: {{item.deviceId}}</view>
						<view style="font-size: 20rpx">Service数量: {{item.advertisServiceUUIDs.length || 0}}</view>
					</view>
					<view style="width: 30%;">
						<button type="primary" size="mini" @click="connectDevice(item)">连接</button>
					</view>
				</view>
				<!-- </radio-group> -->
			</scroll-view>
		</view>



		<view v-if="isConnected">
			<uni-section  type="line" title="命令测试">
				<view class="uni-flex uni-column uni-common-mb" style="padding: 10rpx 30rpx;">

					<view class="uni-flex uni-row uni-common-ml " style="height: 80rpx;line-height: 80rpx;">
						<view class="">
							参数1:
						</view>
						<view class="">
							<input :disabled="!argOn" :style="{'background-color':argOn?'#fff':'#dcdcdc'}"
								class="uni-common-ml arg-input" type="number" v-model="arg1"><input />
						</view>
						<view style="justify-content: center;">
							<switch class="uni-common-ml" :checked="argOn" @change="argOn=!argOn" />
						</view>
					</view>
					<view class="btn-box" v-if="connected" style="margin-top: 60rpx;">
						<button class="btn" size="mini" type="primary" @tap="testRequest(cmdName)"
							v-for="(cmdName,index) in Object.keys(executor)" :key="cmdName">{{cmdName}}</button>
					</view>
				</view>
			</uni-section>
			<uni-section type="line" title="示例写法">
				<button class="btn" size="mini" type="primary" @click="standardMeasure">标样测量</button>
			</uni-section>
			<uni-section type="line" title="日志" style="margin-bottom: 32rpx;" :icon="{type:'trash-filled'}"
				emitName="clearLogs">
				<uni-list>
					<uni-list-item class="log-line" v-for="log in bleLogs" :key="log.index">
						<template v-slot:header>
							<!-- <view>
								<text
									style="font-size: 24rpx;color:'#999';margin-right: 24rpx;">{{log.createTime}}</text>
							</view> -->
						</template>
						<!-- 自定义 body -->
						<template v-slot:body>
							<view class="content-text">
								<textarea :maxlength="-1" disabled v-if="log.type=='info'" auto-height
									:value="log.createTime+' : '+log.value"
									style="color:#333333;font-size: 24rpx;margin-right: 32rpx;"></textarea>
								<textarea :maxlength="-1" disabled v-if="log.type=='return'" auto-height
									:value="log.createTime+' : '+log.value"
									style="color:#1A9E34;font-size: 24rpx;margin-right: 32rpx;"></textarea>
								<textarea :maxlength="-1" disabled v-if="log.type=='notify'" auto-height
									:value="log.createTime+' : '+log.value"
									style="color:#00A8FF;font-size: 24rpx;margin-right: 32rpx;"></textarea>
								<textarea :maxlength="-1" disabled v-if="log.type=='warn'" auto-height
									:value="log.createTime+' : '+log.value"
									style="color:#FCA60B;font-size: 24rpx;margin-right: 32rpx;"></textarea>
							</view>
						</template>
						<!-- 自定义 footer-->
						<template v-slot:footer>

						</template>
					</uni-list-item>
				</uni-list>

			</uni-section>
		</view>
	</view>
</template>

<script>
	import {
		mapState,
		mapGetters,
		mapMutations,
		mapActions
	} from 'vuex';
	import {
		UUIDS_FILTERS,
	} from '@/common/constant.js';
	import {
		RESPONSE_TYPE
	} from '@/common/ble/static/constant.js'
	let FILTERS = Object.values(UUIDS_FILTERS);
	export default {
		computed: {
			...mapState({
				curDevId: state => state.bluetooth.curDevId,//当前设备id
				isSearching: state => state.bluetooth.isSearching,//蓝牙扫描状态
				// loading: state => state.bluetooth.loading,
				connected: state => state.bluetooth.connected,//蓝牙连接状态
				executor: state => state.bluetooth.executor,//Command执行对象
				bleLogs: state => state.logs.bleLogs //日志数组(测试用)
			}),
			...mapGetters({
				isConnected: 'bluetooth/isConnected',//当前蓝牙连接且获取了所需要的特征值
			}),
		},
		data() {
			return {
				devicesList: [], //设备列表
				userScanFilter: true, //是否对扫描设备的UUID使用过滤
				argOn: true,//开启参数,
				arg1: 0,//参数1的值,

			}
		},
		onLoad() {
			// this.startScan();
			uni.$on('clearLogs', this.CLEARBLELOGS)
		},
		onUnload() {
			uni.$off('clearLogs', this.CLEARBLELOGS)
		},
		onBackPress() {
			if (this.isSearching) {
				this.stopBluetoothDevicesDiscovery();
			}
		},
		methods: {
			...mapMutations({
				SETLOADING: 'bluetooth/SETLOADING',//设置读取状态
				ADDBLELOG: 'logs/ADDBLELOG',
				CLEARBLELOGS: 'logs/CLEARBLELOGS'
			}),
			...mapActions({
				startBleScan: 'bluetooth/startBleScan',
				getConnection: 'bluetooth/getConnection',
				stopBluetoothDevicesDiscovery: 'bluetooth/stopBluetoothDevicesDiscovery',
				openBluetoothAdapter: 'bluetooth/openBluetoothAdapter',
				closeBluetoothAdapter: 'bluetooth/closeBluetoothAdapter',
				writeBLECharacteristic: 'bluetooth/writeBLECharacteristic',
				closeBleConnection: 'bluetooth/closeBleConnection',
				doRequest: 'bluetooth/doRequest',
			}),
			resetList() {
				this.$set(this, 'devicesList', []);
			},
			startScan() {
				this.resetList();
				return this.startBleScan({
					onDeviceFoundCallback: this.onDeviceFoundCallback
				})
			},
			onNotify(res) {
				console.log(`res:${JSON.stringify(res)}`);
				this.ADDBLELOG({
					type: 'notify',
					value: `notify:${JSON.stringify(res.data)}`
				})
			},
			standardMeasure(){
				let cmdName='doMeasure';
				// [0]为标样测量,[1]为试样测量
				let args=[0];
				this.doRequest({
					cmdName,
					args
				}).then(result => {
					this.ADDBLELOG({
						type: 'return',
						value: `return of cmd [${cmdName}]:${JSON.stringify(result.data)}`
					})
				})
			},
			onDeviceFoundCallback(devices) {
				console.log(`发现设备: ${JSON.stringify(devices)}`);
				if (devices && devices.devices && devices.devices[0]) {
					//是否已经扫描过该设备
					let index = this.devicesList.findIndex(item => item.deviceId === devices.devices[0].deviceId);
					if (index > -1) {
						//已经存在则更新当前设备信息
						this.devicesList.splice(index, 1, devices.devices[0]);
					} else {
						//对UUID进行过滤,过滤掉不在FILTERS中的设备
						if (this.userScanFilter && !FILTERS.includes(devices.devices[0].advertisServiceUUIDs[
								0])) {
							return;
						}
						console.log(`识别特征码:${JSON.stringify(devices.devices[0].advertisServiceUUIDs[0])}`);
						this.devicesList.push(devices.devices[0]);
					}
					// 刷新self.devicesList
					this.devicesList = this.devicesList.concat();
				}
			},
			closeConnection() {
				let promise = Promise.resolve();
				if (this.isSearching) {
					promise = promise.then(_ => this.stopBluetoothDevicesDiscovery())
				}
				return promise.then(_ => this.closeBleConnection()).then(_ => {
					this.ADDBLELOG({
						type: 'info',
						value: `连接断开`
					})
					this.resetList();
					return this.closeBluetoothAdapter();
				}).catch(err => {
					console.log(`closeConnection出错:${JSON.stringify(err)}`);
				})
			},
			connectDevice(dev) {
				let deviceId = dev.deviceId;
				let self = this;
				if (deviceId) {
					return this.getConnection({
							deviceId,
							onNotify: self.onNotify
						})
						//返回之前页面
						.catch(err => {
							console.log(`连接并读取设备信息时出错:${JSON.stringify(err)}`);
						})
				}
			},
			testRequest(cmdName) {
				console.log(`cmd:${JSON.stringify(cmdName)}`);
				let args = undefined;
				if (this.argOn) {
					args = [Number(this.arg1)]
				}
				this.doRequest({
					cmdName,
					args
				}).then(result => {
					this.ADDBLELOG({
						type: 'return',
						value: `return of cmd [${cmdName}]:${JSON.stringify(result.data)}`
					})
				})
			},

		}
	}
</script>

<style lang="scss">
	.flex-column-center {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-content: center;
	}

	.arg-input {
		height: 80rpx;
		line-height: 80rpx;
	}

	.btn {
		width: 80%;
		height: 60rpx;
		margin: 20rpx 10%;
		text-align: center;
	}

	.content {
		width: 100%;
		padding: 16rpx;

		.device_list {
			margin: 10rpx 20rpx;
			border: 1rpx solid #ddd;
			border-radius: 15rpx;
			background-color: #FFFFFF;
			min-height: 0rpx;
			max-height: 1200rpx;
			width: 700rpx;

			.device_item {
				display: flex;
				flex-direction: row;
				border-bottom: 1rpx solid #ddd;
				padding: 20rpx;
				color: #666;

				&:hover {
					background-color: rgba(0, 0, 0, .1);
				}

				.blueteeth-status {
					padding-top: 10rpx;
					padding-left: 20rpx;
					flex-direction: column;
				}

			}


		}

		.log-display {
			margin-top: 0 auto;
			width: 60%;
			// width: 100%;
			height: 1000rpx;
			// overflow-y: scroll;

			background-color: $uni-bg-color-grey;
			display: flex;
			flex-direction: column;
			margin-bottom: 40rpx;
			margin-right: 40rpx;

			.log-line {
				text-align: left;

				// padding-left: 32rpx;
				.time-text {
					font-size: 24rpx;
					color: $uni-text-color-grey;
					margin-right: 24rpx;
				}

				.content-text {
					margin-right: 40rpx;
					// padding-right: 48rpx;
					// flex-grow: 1;
					// background-color: red;
				}
			}
		}
	}
</style>
