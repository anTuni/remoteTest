[toc]

### 一、小程序测试地址

#### 1开启测试权限:

- 微信扫描二维码添加好友：

  <img src=".\readme.assets\image-20220728101536139.png" alt="image-20220728101536139" style="zoom: 50%;" />

- 允许通过微信号搜索，并告知微信号

<img src=".\readme.assets\image-20220728101905387.png" alt="image-20220728101905387" style="zoom:50%;" />

#### 2.测试版二维码:

> 该二维码地址平时也会测试其它小程序，如果当前不是此小程序，需要联系开发人员调整测试版本

<img src=".\readme.assets\image-20220811171934392.png" alt="image-20220811171934392" style="zoom:50%;" />

<img src=".\readme.assets\image-20220811172538127.png" alt="image-20220811172538127" style="zoom:33%;" />

### 二、使用说明

> 此小程序是使用[uni-app](https://uniapp.dcloud.net.cn/)平台开发然后编译为小程序的，所以小程序的部分代码受编译的影响，代码阅读性会受限.
>
> 蓝牙状态通过vuex管理

#### 1.目录说明

- `/uni-app/`目录下为此demo的uni-app平台源码
- `/mp-weixin/`目录下为编译为小程序后文件

#### 2.使用说明

- uni-app开发:
  - 在需要引入蓝牙连接功能的页面参考`/uni-app/pages/index/index.vue`中引入vuex属性进行操作即可，方便省事

- 微信小程序引入vuex开发:
  - 参考`/uni-app/store/modules/bluetooth.js` 结合`/uni-app/common/ble/core/Command.js`类构建vuex属性
- 微信小程序原生开发:
  - 页面中引入`/uni-app/common/ble/core/Command.js`，将`/uni-app/store/modules/bluetooth.js`中的方法写入js，连接状态保存在页面/闭包/全局变量中管理即可

#### 3.Command类

- 获取执行器对象

  - ```js
    const executor = Command.getInstance().getExecutor('TS');
    ```

- 获取命令执行器对象

  - ```js
    let cmdExecutor = executor['doMeasure'];
    ```

- 命令执行器对象API

  - **req**:reqExecutor,根据入参获取请求的二进制命令码

    ```js
    //doMeasure入参:  0-标样测量 1-试样测量
    let cmd=cmdExecutor.req(0);
    ```

  - **res**:resExecutor,处理接收响应的方法

    ```js
    /**
    	 * cmdExecutor.res（Object）为读取响应的方法,可接受形如
    	 *			{
    	 *				buffer,//每次新读取的数据
    	 *				reqArgs,//请求的入参
    	 *				success(res),
    	 *				fail(err),
    	 *				complete
    	 *			}的参数;如果回调方法success, fail , complete均没有赋值,则返回promise,可通过promise.then(res=>{},err=>{})方式调用
    	 */
    //wx.onBLECharacteristicValueChange一次回调不一定能读完一整条响应，所以不宜通过promise形式异步调用，而是应该采用同步回调进行调用。cmdExecutor会将没有解析完的响应保存在闭包中，不需要额外处理
    wx.onBLECharacteristicValueChange(chVal => {
    			cmdExecutor.res({
    				buffer: chVal.value,
    				success: result => {
    					//成功读取一条完整响应的回调函数,可以写自己的业务逻辑，result为解析的响应结果
                        //result格式为：resType:0-NOTIFICATION,1-RETURN，data为解析后的结果
                        //     {
    					//			resType, 
    					//			data
    					//		}
                        //CR系列只有部分设备默认支持在设备点击测量时会给蓝牙连接的上位机发送NOTIFICATION的测量数据
                        //可通过升级定制软件版本支持此功能
    					....
    				},
    				fail,
    				complete
    			})
    		})
    ```
    
  - **setResponseType**：设置下一条接收响应的类型
  
    > NOTIFICATION是设备主动通知的消息，RETURN是上位机发送请求以后设备针对请求回复的消息，这两种消息结构上是一样的，NOTIFICATION接收的时机不可预期，可能会和RETURN时机接近。为了正确区分并解析，需要手动设置cmdExecutor的解析类型
  
    ```js
    ...
    const afterReq=function(type = RESPONSE_TYPE.RETURN){
        	commit('SETCMDTYPE', cmdName);
    		setResponseType(type);
    },
    
    const clock = new Promise((resolve, reject) => {
    			timeoutId = setTimeout(() => {
    				timeoutId = null;
    				reject({
    					errMsg: '请求超时了!'
    				})
    			}, timeout);
    		});
    		const req = dispatch('printbuffs', {
    			buffer,
    			deviceId,
    			serviceId,
    			characteristicId
    		}).then(_ => {
    			if (afterReq) {
                    //发送请求以后将cmdExecutor解析状态置为RETURN
    				afterReq()
    			}
    		}).then(_ => dispatch('handlerBLECvChange', {
    			executor: resExecutor
    		}));
    		return Promise.race([clock, req]).then(res => {
    			commit('SETLOADING');
    			//发送并读取成功,清除计时器
    			if (timeoutId) {
    				clearTimeout(timeoutId)
    			}
    			return res;
    		}, msg => {
    			if (afterReq) {
    				//如果请求超时没有收到响应，需要手动将cmdExecutor解析状态置为NOTIFICATION
    				afterReq(RESPONSE_TYPE.NOTIFICATION)
    			}
    			commit('SETLOADING');
    			if (timeoutId) {
    				clearTimeout(timeoutId)
    			}
    			console.log(`writeBLECharacteristic超时/出错:${JSON.stringify(msg)}`);
    			return Promise.reject({
    				errMsg: `writeBLECharacteristic超时/出错:${JSON.stringify(msg)}`
    			});
    		})
    ```

#### 4.Vuex/bluetooth中常用属性

- state

  ```js
  {
  	connected: false,//蓝牙连接状态
  	isSearching: false,//蓝牙搜索状态
  	isOpenBle: false,//蓝牙适配器开启状态
  	scanTimer: '', //用来缓存计时器id
  	curDevId,//当前设备id
  	curBleInfo,//当前设备的蓝牙连接特征值信息
  	loading: false,//方便管理等待状态
  	executor: executor, //蓝牙命令执行器cmdExecutor
  	cmdType: 'getInstrumentModel',//当前蓝牙命令
  	notifyCache: notifyCache,//缓存收到的notify数据的数组
  	onNotify: null //缓存RESPONSE_TYPE.NOTIFICATION的回调
  }
  ```

- getters

  ```js
  //当前蓝牙命令,并确认执行器中有此蓝牙命令
  currentCmd
  //是否蓝牙连接并获取所有蓝牙特征值
  isConnected
  ```

- actions

  ```js
  /**
  * 开启蓝牙扫描
  * @param {Function} onDeviceFoundCallback - 扫描发现设备的回调函数,入参为扫描的设备信息
  * @param {Number} timeout - 蓝牙扫描持续时间
  */
  startBleScan
  
  stopBluetoothDevicesDiscovery
  
  /**
  * 建立蓝牙连接
  * @param {String} deviceId - 设备id,默认会连接state.curDevId
  * @param {Function} onNotify - 接收onNotify的同步回调,入参为解析后的响应结果
  * @param {Number} timeout - 蓝牙连接的超时时间
  */
  getConnection
  
  closeBleConnection
  
  /**
  * 发送请求，命令名称(cmdName)和入参(args)参考'@/common/ble/static/中相关协议的说明'
  * @param {String} cmdName - 命令名称
  * @param {Array} args - 请求的入参,
  * @param {Number} timeout - 该条命令发送到解析完成的超时时间
  */
  doRequest
  
  	/**
  	 * onBLECharacteristicValueChange一次回调不一定能读完一条响应，需要进行封装
  	 * 针对特征值变化回调api的promise的包装方法，不取返回值时可以用于同步回调
  	 * 当用于请求以后要获取RESPONSE_TYPE.RETURN类型响应的时候可以用返回的promise来获取回调状态(因为请求的回复有比较稳定的预期)
  	 * 当用于监视设备发送的RESPONSE_TYPE.NOTIFICATION类型的通知响应的时候，建议不要获取返回值，而是通过success,fail,complete获取回调(因为通知响应不可预期)
  	 * @param {Function} executor - resExecutor
  	 * @param {Function} onNotify - RESPONSE_TYPE.NOTIFICATION的同步回调
  	 * @param {Function} success - 响应解析成功回调
  	 * @param {Function} fail - 响应解析失败回调
  	 * @param {Function} complete- 
  	 */
  	handlerBLECvChange
  ```

#### 5.协议命令

> 详细设定参考`\uni-app\common\ble\static\ts_protocol.js`

```js
//是否校正
isCalibrated
//获取标样总数
getStandardAmount
//获取试样总数
getSampleAmount
//仪器型号
getInstrumentModel
//硬件版本
getHardwareVersion
//软件版本
getSoftwareVersion
//获取白板编号
getWhiteBoardSN
//校正
//入参 0-黑校 1-白校
doCalibrate(TS_CALIBRATE)
//测量
//入参 0-标样测量 1-试样测量
doMeasure(TS_MEASURE_TYPE)
```

