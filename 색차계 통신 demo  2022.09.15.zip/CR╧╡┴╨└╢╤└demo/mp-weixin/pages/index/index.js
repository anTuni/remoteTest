(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
	["pages/index/index"], {
		"0075": function(e, t, n) {},
		1405: function(e, t, n) {
			"use strict";
			(function(e) {
				Object.defineProperty(t, "__esModule", {
					value: !0
				}), t.default = void 0;
				var o = n("26cb"),
					i = n("d537");
				n("8973");

				function c(e, t) {
					var n = Object.keys(e);
					if (Object.getOwnPropertySymbols) {
						var o = Object.getOwnPropertySymbols(e);
						t && (o = o.filter((function(t) {
							return Object.getOwnPropertyDescriptor(e, t).enumerable
						}))), n.push.apply(n, o)
					}
					return n
				}

				function r(e) {
					for (var t = 1; t < arguments.length; t++) {
						var n = null != arguments[t] ? arguments[t] : {};
						t % 2 ? c(Object(n), !0).forEach((function(t) {
							s(e, t, n[t])
						})) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object
							.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach((function(t) {
							Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n,
								t))
						}))
					}
					return e
				}

				function s(e, t, n) {
					return t in e ? Object.defineProperty(e, t, {
						value: n,
						enumerable: !0,
						configurable: !0,
						writable: !0
					}) : e[t] = n, e
				}
				var u = Object.values(i.UUIDS_FILTERS),
					a = {
						computed: r(r({}, (0, o.mapState)({
							curDevId: function(e) {
								return e.bluetooth.curDevId
							},
							isSearching: function(e) {
								return e.bluetooth.isSearching
							},
							connected: function(e) {
								return e.bluetooth.connected
							},
							executor: function(e) {
								return e.bluetooth.executor
							},
							bleLogs: function(e) {
								return e.logs.bleLogs
							}
						})), (0, o.mapGetters)({
							isConnected: "bluetooth/isConnected"
						})),
						data: function() {
							return {
								devicesList: [],
								userScanFilter: !0,
								argOn: !0,
								arg1: 0
							}
						},
						onLoad: function() {
							e.$on("clearLogs", this.CLEARBLELOGS)
						},
						onUnload: function() {
							e.$off("clearLogs", this.CLEARBLELOGS)
						},
						onBackPress: function() {
							this.isSearching && this.stopBluetoothDevicesDiscovery()
						},
						methods: r(r(r({}, (0, o.mapMutations)({
							SETLOADING: "bluetooth/SETLOADING",
							ADDBLELOG: "logs/ADDBLELOG",
							CLEARBLELOGS: "logs/CLEARBLELOGS"
						})), (0, o.mapActions)({
							startBleScan: "bluetooth/startBleScan",
							getConnection: "bluetooth/getConnection",
							stopBluetoothDevicesDiscovery: "bluetooth/stopBluetoothDevicesDiscovery",
							openBluetoothAdapter: "bluetooth/openBluetoothAdapter",
							closeBluetoothAdapter: "bluetooth/closeBluetoothAdapter",
							writeBLECharacteristic: "bluetooth/writeBLECharacteristic",
							closeBleConnection: "bluetooth/closeBleConnection",
							doRequest: "bluetooth/doRequest"
						})), {}, {
							resetList: function() {
								this.$set(this, "devicesList", [])
							},
							startScan: function() {
								return this.resetList(), this.startBleScan({
									onDeviceFoundCallback: this
										.onDeviceFoundCallback
								})
							},
							onNotify: function(e) {
								console.log("res:".concat(JSON.stringify(e))), this
									.ADDBLELOG({
										type: "notify",
										value: "notify:".concat(JSON.stringify(e.data))
									})
							},
							standardMeasure: function() {
								var e = this,
									t = "doMeasure",
									n = [0];
								this.doRequest({
									cmdName: t,
									args: n
								}).then((function(n) {
									e.ADDBLELOG({
										type: "return",
										value: "return of cmd [".concat(
											t, "]:").concat(JSON
											.stringify(n.data))
									})
								}))
							},
							onDeviceFoundCallback: function(e) {
								if (console.log("发现设备: ".concat(JSON.stringify(e))), e && e
									.devices && e.devices[0]) {
									var t = this.devicesList.findIndex((function(t) {
										return t.deviceId === e.devices[0]
											.deviceId
									}));
									if (t > -1) this.devicesList.splice(t, 1, e.devices[0]);
									else {
										if (this.userScanFilter && !u.includes(e.devices[0]
												.advertisServiceUUIDs[0])) return;
										console.log("识别特征码:".concat(JSON.stringify(e
												.devices[0].advertisServiceUUIDs[0]
												))), this.devicesList.push(e.devices[0])
									}
									this.devicesList = this.devicesList.concat()
								}
							},
							closeConnection: function() {
								var e = this,
									t = Promise.resolve();
								return this.isSearching && (t = t.then((function(t) {
									return e.stopBluetoothDevicesDiscovery()
								}))), t.then((function(t) {
									return e.closeBleConnection()
								})).then((function(t) {
									return e.ADDBLELOG({
											type: "info",
											value: "连接断开"
										}), e.resetList(), e
										.closeBluetoothAdapter()
								})).catch((function(e) {
									console.log("closeConnection出错:".concat(JSON
										.stringify(e)))
								}))
							},
							connectDevice: function(e) {
								var t = e.deviceId,
									n = this;
								if (t) return this.getConnection({
									deviceId: t,
									onNotify: n.onNotify
								}).catch((function(e) {
									console.log("连接并读取设备信息时出错:".concat(JSON
										.stringify(e)))
								}))
							},
							testRequest: function(e) {
								var t = this;
								console.log("cmd:".concat(JSON.stringify(e)));
								var n = void 0;
								this.argOn && (n = [Number(this.arg1)]), this.doRequest({
									cmdName: e,
									args: n
								}).then((function(n) {
									t.ADDBLELOG({
										type: "return",
										value: "return of cmd [".concat(
											e, "]:").concat(JSON
											.stringify(n.data))
									})
								}))
							}
						})
					};
				t.default = a
			}).call(this, n("543d")["default"])
		},
		"55d5": function(e, t, n) {
			"use strict";
			(function(e) {
				n("c952");
				o(n("66fd"));
				var t = o(n("b4e6"));

				function o(e) {
					return e && e.__esModule ? e : {
						default: e
					}
				}
				wx.__webpack_require_UNI_MP_PLUGIN__ = n, e(t.default)
			}).call(this, n("543d")["createPage"])
		},
		b4e6: function(e, t, n) {
			"use strict";
			n.r(t);
			var o = n("efe4"),
				i = n("f2ca");
			for (var c in i) "default" !== c && function(e) {
				n.d(t, e, (function() {
					return i[e]
				}))
			}(c);
			n("c4ec");
			var r, s = n("f0c5"),
				u = Object(s["a"])(i["default"], o["b"], o["c"], !1, null, null, null, !1, o["a"], r);
			t["default"] = u.exports
		},
		c4ec: function(e, t, n) {
			"use strict";
			var o = n("0075"),
				i = n.n(o);
			i.a
		},
		efe4: function(e, t, n) {
			"use strict";
			n.d(t, "b", (function() {
				return i
			})), n.d(t, "c", (function() {
				return c
			})), n.d(t, "a", (function() {
				return o
			}));
			var o = {
					uniSection: function() {
						return n.e("uni_modules/uni-section/components/uni-section/uni-section").then(n
							.bind(null, "a9a0"))
					},
					uniList: function() {
						return n.e("uni_modules/uni-list/components/uni-list/uni-list").then(n.bind(
							null, "8f38"))
					},
					uniListItem: function() {
						return n.e("uni_modules/uni-list/components/uni-list-item/uni-list-item").then(n
							.bind(null, "4870"))
					}
				},
				i = function() {
					var e = this,
						t = e.$createElement,
						n = (e._self._c, e.connected ? null : e.__map(e.devicesList, (function(t, n) {
							var o = e.__get_orig(t),
								i = t.name ? Math.max(100 + t.RSSI, 0) : null;
							return {
								$orig: o,
								g0: i
							}
						}))),
						o = e.isConnected && e.connected ? Object.keys(e.executor) : null;
					e._isMounted || (e.e0 = function(t) {
						e.argOn = !e.argOn
					}, e.e1 = function(t, n) {
						var o = arguments[arguments.length - 1].currentTarget.dataset,
							i = o.eventParams || o["event-params"];
						n = i.cmdName;
						return e.testRequest(n)
					}), e.$mp.data = Object.assign({}, {
						$root: {
							l0: n,
							l1: o
						}
					})
				},
				c = []
		},
		f2ca: function(e, t, n) {
			"use strict";
			n.r(t);
			var o = n("1405"),
				i = n.n(o);
			for (var c in o) "default" !== c && function(e) {
				n.d(t, e, (function() {
					return o[e]
				}))
			}(c);
			t["default"] = i.a
		}
	},
	[
		["55d5", "common/runtime", "common/vendor"]
	]
]);
