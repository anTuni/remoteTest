### 颜色转换类示例

```js
import Color from '@/common/color/Color.js'

//@
	standardMeasure() {
				let cmdName = 'doMeasure';
				// [0]为标样测量,[1]为试样测量
				let args = [0];
				this.doRequest({
					cmdName,
					args
				}).then(result => {
					let data = result.data;
					let color = new Color().setSpectrum({
						spectrum: data.dataArr1
					});
					let rgb = color.toRGB();
					let rgbColor = color.toRGBColor();
					let value =
						`return of cmd [${cmdName}]:${JSON.stringify(result.data)}.rgb:${JSON.stringify(rgb)},rgbColor:${rgbColor}.`
					this.ADDBLELOG({
						type: 'return',
						value
					})
				})
			},
```

